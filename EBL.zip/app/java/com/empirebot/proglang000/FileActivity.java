package com.empirebot.proglang000;

import android.widget.Toast;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.preference.PreferenceManager;
import android.app.*;
import android.os.Vibrator;
import android.webkit.*;
import android.content.*;
import android.view.View.*;
import android.view.*;
import android.net.Uri;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintJob;
import android.print.PrintManager;
import java.io.FileOutputStream;
import android.net.wifi.WifiManager;
import android.widget.ShareActionProvider.*;
import org.apache.http.conn.util.*;
import android.os.*;

public class FileActivity extends Activity 
{
	private ValueCallback<Uri> mUploadMessage;
    public ValueCallback<Uri[]> uploadMessage;

	public String ConsD = "";
	public String BePrIn = "";
    public static final int REQUEST_SELECT_FILE = 100;
    private final static int FILECHOOSER_RESULTCODE = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
		//getActionBar().hide();

		final Intent in1 = new Intent(this,SettingActivity.class);
		Intent intent = getIntent();
		String theDatas = intent.getStringExtra(Intent.EXTRA_TEXT);
		Toast.makeText(FileActivity.this,theDatas,Toast.LENGTH_LONG).show();
		final SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

		//alertProm.setView(textProm);


		final WebView webv1 = findViewById(R.id.wv1);
		//webv1.destroy();
		webv1.getSettings().setJavaScriptEnabled(true);
		WebView webview1 = webv1;
    }
	@Override
    public void onActivityResult(int requestCode, int resultCode, Intent intent)
    {
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
        {
            if (requestCode == REQUEST_SELECT_FILE)
            {
                if (uploadMessage == null)
                    return;
                uploadMessage.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, intent));
                uploadMessage = null;
            }
        }
        else if (requestCode == FILECHOOSER_RESULTCODE)
        {
            if (null == mUploadMessage)
                return;
            // Use FileActivity.RESULT_OK if you're implementing WebView inside Fragment
            // Use RESULT_OK only if you're implementing WebView inside an Activity
            Uri result = intent == null || resultCode != FileActivity.RESULT_OK ? null : intent.getData();
            mUploadMessage.onReceiveValue(result);
            mUploadMessage = null;
        }

	}
	public void printPDF(){
		PrintManager printManager = (PrintManager) this.getSystemService(Context.PRINT_SERVICE);
        WebView wv1 = findViewById(R.id.wv1);
		PrintDocumentAdapter printAdapter = wv1.createPrintDocumentAdapter();
		String jobName = getString(R.string.app_name) + " Print Test";
		printManager.print(jobName, printAdapter, new PrintAttributes.Builder().build());
	}
	public class WebAppInterface
	{
		@JavascriptInterface
		public void print()
		{
			Toast.makeText(FileActivity.this, "print called", Toast.LENGTH_SHORT).show(); 
		}
	}

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.stin, menu);
        return true;
    }
	@Override
    public boolean onOptionsItemSelected(MenuItem item) {
        WebView webView = findViewById(R.id.wv1);
		final Intent in1 = new Intent(this,SettingActivity.class);
		final SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this);
        switch (item.getItemId()) {
            case R.id.menu_settings:

                AlertDialog.Builder alertdialogB = new AlertDialog.Builder(FileActivity.this,R.style.MyDialogTheme);
				alertdialogB.setIcon(R.drawable.ic_launcher);
				alertdialogB.setTitle(R.string.rca);
				alertdialogB.setMessage(R.string.rcb);
				Button theBut = new Button(FileActivity.this);
				theBut.setText(R.string.gte);
				theBut.setOnClickListener(new OnClickListener(){
						@Override
						public void onClick(View v){
							startActivity(in1);
						}
					});
				alertdialogB.setView(theBut);
				alertdialogB.setCancelable(false);

				alertdialogB.setNegativeButton(android.R.string.no,null)
					.setPositiveButton(android.R.string.yes,new DialogInterface.OnClickListener(){
						@Override
						public void onClick(DialogInterface dialogInterface,int i){

							ConsD = "";
							// <form method="POST"action= .1. ><textarea name=codes> .2. </textarea> <input type=submit> </form>
							String thecodestr = "<form method='POST'style='display:none;'action='"+sp.getString("webUrl","")+"'><textarea name='codes'>"+sp.getString("codes","")+"</textarea><input type='submit'id='submit'></form><script>document.getElementById('submit').click()</script><h1 style='font-size:96px;color:#4080ff;background-color:#ffd000;'>Loading...</h1>";
							WebView myWebv = findViewById(R.id.wv1);
							myWebv.loadData(thecodestr,"","utf-8");
						}
					})
					.setNeutralButton(R.string.exqu,new DialogInterface.OnClickListener(){
						@Override
						public void onClick(DialogInterface dialogInterface,int i){
							finish();
						}
					});
				alertdialogB.create();
				alertdialogB.show();
                break;
            case R.id.menu_settings2:
                AlertDialog.Builder alertdialogBb = new AlertDialog.Builder(FileActivity.this,R.style.MyDialogTheme);
				alertdialogBb.setIcon(R.drawable.ic_launcher);
				alertdialogBb.setTitle(R.string.coa);
				alertdialogBb.setMessage(R.string.cob);
				String strstr1 = ConsD;
				String strstr2 = "data:text/html,<style>body{white-space:pre}</style>";
				String strstr3 = strstr2+strstr1;
				WebView ConsoleView = new WebView(FileActivity.this);
				ConsoleView.loadUrl(strstr3);
				alertdialogBb.setView(ConsoleView);
				alertdialogBb.setCancelable(false);

				alertdialogBb.setNegativeButton(R.string.clc,null)
					.setPositiveButton(android.R.string.copy,new DialogInterface.OnClickListener(){
						@Override
						public void onClick(DialogInterface dialogInterface,int i){
						}
					})
					.setNeutralButton(R.string.exqu,new DialogInterface.OnClickListener(){
						@Override
						public void onClick(DialogInterface dialogInterface,int i){
							finish();
						}
					});
				alertdialogBb.create();
				alertdialogBb.show();
                break;
            case R.id.menu_settings3:
                webView.loadUrl(webView.getUrl());
                break;
            case R.id.menu_settings4:
				AlertDialog.Builder albalb = new AlertDialog.Builder(FileActivity.this,R.style.MyDialogTheme);
				albalb.setTitle(R.string.exqu);
				albalb.setMessage(R.string.exqu);
				albalb.setCancelable(true);
				albalb.setIcon(R.drawable.ic_launcher);
				albalb.setNegativeButton(android.R.string.cancel,null);
				albalb.setPositiveButton(android.R.string.no,null);
				albalb.setNeutralButton(R.string.exqu,new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialogInterface,int i){
							finish();
						}
					});
                albalb.show();
                break;
		}
        return true;
    }


}



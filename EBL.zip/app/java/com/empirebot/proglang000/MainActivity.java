package com.empirebot.proglang000;

import android.widget.Toast;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.preference.PreferenceManager;
import android.app.*;
import android.os.Vibrator;
import android.webkit.*;
import android.content.*;
import android.view.View.*;
import android.view.*;
import android.net.Uri;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintJob;
import android.print.PrintManager;
import java.io.FileOutputStream;
import android.net.wifi.WifiManager;
import android.widget.ShareActionProvider.*;
import org.apache.http.conn.util.*;
import android.os.*;
import android.graphics.*;

public class MainActivity extends Activity 
{
	private ValueCallback<Uri> mUploadMessage;
    public ValueCallback<Uri[]> uploadMessage;

	public String ConsD = "";
	public String BePrIn = "";
    public static final int REQUEST_SELECT_FILE = 100;
    private final static int FILECHOOSER_RESULTCODE = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
		//getActionBar().hide();

		final Intent in1 = new Intent(this,SettingActivity.class);
		final SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

		//alertProm.setView(textProm);


		final WebView webv1 = findViewById(R.id.wv1);
		//webv1.destroy();
		webv1.getSettings().setJavaScriptEnabled(true);
		webv1.setWebChromeClient(new WebChromeClient(){
			public void onConsoleMessage(String message,int lineNumber,String sourceId){
				if(message.startsWith("Uncaught ")){
					ConsD = ConsD + "ERROR "+sourceId+" : "+lineNumber+" = "+message+"<br>";
				}else{
					ConsD = ConsD + sourceId+" : "+lineNumber+" = "+message+"<br>";
				}
			}
			public boolean onJsPrompt(WebView view,String url,String message,String defaultValue,final JsPromptResult result){
				try{
					if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN FINISH")){
						finish();
					}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN TOAST WITH SIZE AND STRING = ")){
						Toast.makeText(MainActivity.this,defaultValue,1).show();
						result.confirm();
					}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN VIBRATE")){
						Vibrator vib = (Vibrator) getSystemService(MainActivity.VIBRATOR_SERVICE);
						vib.vibrate(Integer.parseInt(defaultValue));
						result.confirm();
					}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN PRINT THIS PAGE")){
						printPDF();
						result.confirm();
					}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN ON WIFI")){
						WifiManager wifi = (WifiManager) getSystemService(Context.WIFI_SERVICE);
						wifi.setWifiEnabled(true);
						result.confirm();
					}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN OFF WIFI")){
						WifiManager wifi = (WifiManager) getSystemService(Context.WIFI_SERVICE);
						wifi.setWifiEnabled(false);
						result.confirm();
					}else{
						AlertDialog.Builder JsPromptDialog = new AlertDialog.Builder(MainActivity.this,R.style.MyDialogTheme);
						JsPromptDialog.setTitle("Prompt "+url);
						JsPromptDialog.setMessage(message);
						final EditText JsPromptInput = new EditText(MainActivity.this);
						JsPromptInput.setText(defaultValue);
						if(defaultValue.startsWith("BePrIn")){
							JsPromptInput.setText(BePrIn);
						}
						JsPromptInput.selectAll();
						JsPromptInput.setBackgroundColor(Color.parseColor("#ff4080ff"));
						JsPromptInput.setTextColor(Color.parseColor("#ffffd000"));
						JsPromptDialog.setView(JsPromptInput);
						JsPromptDialog.setIcon(R.drawable.ic_launcher);
						JsPromptDialog.setPositiveButton(android.R.string.yes,new DialogInterface.OnClickListener(){
								public void onClick(DialogInterface dialogInterface,int i){
									BePrIn = JsPromptInput.getText().toString();
									result.confirm(JsPromptInput.getText().toString());
								}
							})
							.setNegativeButton(android.R.string.cancel,new DialogInterface.OnClickListener(){
								public void onClick(DialogInterface dialogInterface,int i){
									result.cancel();
								}
							})
							.setNeutralButton(R.string.exqu,new DialogInterface.OnClickListener(){
								public void onClick(DialogInterface dialogInterface,int i){
									finish();
								}
							})
							.setCancelable(false)
						.show();
					}
				}catch(Exception errInf){
					ConsD = ConsD + "ERROR iN CALL EBL TO ANDROiD.JAVA : "+String.valueOf(errInf)+"<br>";
					result.confirm("ERROR iN CALL EBL TO ANDROiD.JAVA : "+String.valueOf(errInf));
				}
				return true;
			}
				public boolean onJsConfirm(WebView view,String url,String message,final JsResult result){
					try{
							AlertDialog.Builder JsPromptDialog = new AlertDialog.Builder(MainActivity.this,R.style.MyDialogTheme);
							JsPromptDialog.setTitle("Confirm "+url);
							JsPromptDialog.setMessage(message);
							JsPromptDialog.setIcon(R.drawable.ic_launcher);
							JsPromptDialog.setPositiveButton(android.R.string.yes,new DialogInterface.OnClickListener(){
									public void onClick(DialogInterface dialogInterface,int i){
										result.confirm();
									}
								})
								.setNegativeButton(android.R.string.cancel,new DialogInterface.OnClickListener(){
									public void onClick(DialogInterface dialogInterface,int i){
										result.cancel();
									}
								})
								.setNeutralButton(R.string.exqu,new DialogInterface.OnClickListener(){
									public void onClick(DialogInterface dialogInterface,int i){
										finish();
									}
								})
								.setCancelable(false)
								.show();
					}catch(Exception errInf){
						ConsD = ConsD + "ERROR iN CALL EBL TO ANDROiD.JAVA : "+String.valueOf(errInf)+"<br>";
						result.cancel();
					}
					return true;
				}
				public boolean onJsAlert(WebView view,String url,String message,final JsResult result){
					try{
						AlertDialog.Builder JsPromptDialog = new AlertDialog.Builder(MainActivity.this,R.style.MyDialogTheme);
						JsPromptDialog.setTitle("Alert "+url);
						JsPromptDialog.setMessage(message);
						JsPromptDialog.setIcon(R.drawable.ic_launcher);
						JsPromptDialog.setPositiveButton(android.R.string.yes,new DialogInterface.OnClickListener(){
								public void onClick(DialogInterface dialogInterface,int i){
									result.confirm();
								}
							})
							.setNeutralButton(R.string.exqu,new DialogInterface.OnClickListener(){
								public void onClick(DialogInterface dialogInterface,int i){
									finish();
								}
							})
							.setCancelable(false)
							.show();
					}catch(Exception errInf){
						ConsD = ConsD + "ERROR iN CALL EBL TO ANDROiD.JAVA : "+String.valueOf(errInf)+"<br>";
						result.cancel();
					}
					return true;
				}
			public void onProgressChanged(WebView view,int newProgress){
				Toast.makeText(MainActivity.this,"Loading "+String.valueOf(newProgress)+"%",0).show();
			}
				protected void openFileChooser(ValueCallback uploadMsg, String acceptType)
				{
					mUploadMessage = uploadMsg;
					Intent i = new Intent(Intent.ACTION_GET_CONTENT);
					i.addCategory(Intent.CATEGORY_OPENABLE);
					i.setType("image/*");
					startActivityForResult(Intent.createChooser(i, "File Browser"), FILECHOOSER_RESULTCODE);
				}
				public boolean onShowFileChooser(WebView mWebView, ValueCallback<Uri[]> filePathCallback, WebChromeClient.FileChooserParams fileChooserParams)
				{
					if (uploadMessage != null) {
						uploadMessage.onReceiveValue(null);
						uploadMessage = null;
					}

					uploadMessage = filePathCallback;

					Intent intent = null;
					if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
						intent = fileChooserParams.createIntent();
					}
					try
					{
						startActivityForResult(intent, REQUEST_SELECT_FILE);
					} catch (ActivityNotFoundException e)
					{
						uploadMessage = null;
						return false;
					}
					return true;
				}
			// 
		});
		WebView webView = webv1;
        webView.getSettings().setMinimumFontSize(0);
        webView.getSettings().setMinimumLogicalFontSize(0);
        webView.getSettings().setSaveFormData(true);
        webView.getSettings().setSavePassword(true);
        webView.getSettings().setStandardFontFamily("serif");
        webView.setWebViewClient(new WebViewClient());
        webView.getSettings().setDefaultFontSize(16);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAppCacheEnabled(true);
        webView.getSettings().setGeolocationEnabled(true);
		webv1.getSettings().setAppCacheMaxSize(2147483647); // Max Range size ( 2 GB )
        webView.getSettings().setLoadsImagesAutomatically(true);
        webView.getSettings().setLoadWithOverviewMode(false);
        webv1.getSettings().setUseWideViewPort(true);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setSupportZoom(true);
        webView.getSettings().setDisplayZoomControls(true);
        webView.getSettings().setBuiltInZoomControls(true);
    }
	@Override
    public void onActivityResult(int requestCode, int resultCode, Intent intent)
    {
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
        {
            if (requestCode == REQUEST_SELECT_FILE)
            {
                if (uploadMessage == null)
                    return;
                uploadMessage.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, intent));
                uploadMessage = null;
            }
        }
        else if (requestCode == FILECHOOSER_RESULTCODE)
        {
            if (null == mUploadMessage)
                return;
            // Use MainActivity.RESULT_OK if you're implementing WebView inside Fragment
            // Use RESULT_OK only if you're implementing WebView inside an Activity
            Uri result = intent == null || resultCode != MainActivity.RESULT_OK ? null : intent.getData();
            mUploadMessage.onReceiveValue(result);
            mUploadMessage = null;
        }

	}
	public void printPDF(){
		PrintManager printManager = (PrintManager) this.getSystemService(Context.PRINT_SERVICE);
        WebView wv1 = findViewById(R.id.wv1);
		PrintDocumentAdapter printAdapter = wv1.createPrintDocumentAdapter();
		String jobName = getString(R.string.app_name) + " Print Test";
		printManager.print(jobName, printAdapter, new PrintAttributes.Builder().build());
	}
	public class WebAppInterface
	{
		@JavascriptInterface
		public void print()
		{
			Toast.makeText(MainActivity.this, "print called", Toast.LENGTH_SHORT).show(); 
		}
	}

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.stin, menu);
        return true;
    }
	@Override
    public boolean onOptionsItemSelected(MenuItem item) {
        WebView webView = findViewById(R.id.wv1);
		final Intent in1 = new Intent(this,SettingActivity.class);
		final SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this);
        switch (item.getItemId()) {
            case R.id.menu_settings:

                AlertDialog.Builder alertdialogB = new AlertDialog.Builder(MainActivity.this,R.style.MyDialogTheme);
				alertdialogB.setIcon(R.drawable.ic_launcher);
				alertdialogB.setTitle(R.string.rca);
				alertdialogB.setMessage(R.string.rcb);
				Button theBut = new Button(MainActivity.this);
				theBut.setText(R.string.gte);
				theBut.setOnClickListener(new OnClickListener(){
						@Override
						public void onClick(View v){
							startActivity(in1);
						}
					});
				alertdialogB.setView(theBut);
				alertdialogB.setCancelable(false);

				alertdialogB.setNegativeButton(android.R.string.no,null)
					.setPositiveButton(android.R.string.yes,new DialogInterface.OnClickListener(){
						@Override
						public void onClick(DialogInterface dialogInterface,int i){

							ConsD = "";
							// <form method="POST"action= .1. ><textarea name=codes> .2. </textarea> <input type=submit> </form>
							String thecodestr = "<form method='POST'style='display:none;'action='"+sp.getString("webUrl","")+"'><textarea name='codes'>"+sp.getString("codes","")+"</textarea><input type='submit'id='submit'></form><script>document.getElementById('submit').click()</script><h1 style='font-size:96px;color:#4080ff;background-color:#ffd000;'>Loading...</h1>";
							WebView myWebv = findViewById(R.id.wv1);
							myWebv.loadData(thecodestr,"","utf-8");
						}
					})
					.setNeutralButton(R.string.exqu,new DialogInterface.OnClickListener(){
						@Override
						public void onClick(DialogInterface dialogInterface,int i){
							finish();
						}
					});
				alertdialogB.create();
				alertdialogB.show();
                break;
            case R.id.menu_settings2:
                AlertDialog.Builder alertdialogBb = new AlertDialog.Builder(MainActivity.this,R.style.MyDialogTheme);
				alertdialogBb.setIcon(R.drawable.ic_launcher);
				alertdialogBb.setTitle(R.string.coa);
				alertdialogBb.setMessage(R.string.cob);
				String strstr1 = ConsD;
				String strstr2 = "data:text/html,<style>body{white-space:pre}</style>";
				String strstr3 = strstr2+strstr1;
				WebView ConsoleView = new WebView(MainActivity.this);
				ConsoleView.loadUrl(strstr3);
				alertdialogBb.setView(ConsoleView);
				alertdialogBb.setCancelable(false);

				alertdialogBb.setNegativeButton(R.string.clc,null)
					.setPositiveButton(android.R.string.copy,new DialogInterface.OnClickListener(){
						@Override
						public void onClick(DialogInterface dialogInterface,int i){
						}
					})
					.setNeutralButton(R.string.exqu,new DialogInterface.OnClickListener(){
						@Override
						public void onClick(DialogInterface dialogInterface,int i){
							finish();
						}
					});
				alertdialogBb.create();
				alertdialogBb.show();
                break;
            case R.id.menu_settings3:
                webView.loadUrl(webView.getUrl());
                break;
            case R.id.menu_settings4:
				AlertDialog.Builder albalb = new AlertDialog.Builder(MainActivity.this,R.style.MyDialogTheme);
				albalb.setTitle(R.string.exqu);
				albalb.setMessage(R.string.exqu);
				albalb.setCancelable(true);
				albalb.setIcon(R.drawable.ic_launcher);
				albalb.setNegativeButton(android.R.string.cancel,null);
				albalb.setPositiveButton(android.R.string.no,null);
				albalb.setNeutralButton(R.string.exqu,new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialogInterface,int i){
							finish();
						}
					});
                albalb.show();
                break;
		}
        return true;
    }


}



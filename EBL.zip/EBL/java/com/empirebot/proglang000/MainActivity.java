package com.empirebot.proglang000;

import android.widget.Toast;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.preference.PreferenceManager;
import android.app.*;
import android.os.Vibrator;
import android.webkit.*;
import android.content.*;
import android.view.View.*;
import android.view.*;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.net.wifi.WifiManager;

public class MainActivity extends Activity 
{
	private ValueCallback<Uri> mUploadMessage;
    public ValueCallback<Uri[]> uploadMessage;
    public static final int REQUEST_SELECT_FILE = 100;
    private final static int FILECHOOSER_RESULTCODE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
		getActionBar().hide();
		final TextView ConsoleData = new TextView(MainActivity.this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		//alertProm.setView(textProm);
		final SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this);
		final Intent in1 = new Intent(this,SettingActivity.class);
		final WebView webv1 = findViewById(R.id.wv1);
		webv1.getSettings().setJavaScriptEnabled(true);
		webv1.setWebChromeClient(new WebChromeClient(){
			public void onProgressChanged(WebView view,int progress){
				String loading = "Loading "+progress+"%";
				Toast.makeText(MainActivity.this,loading, Toast.LENGTH_SHORT).show();
			};
			@Override
			public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
				String newTitle = "Alert "+view.getUrl();
				AlertDialog.Builder alb = new AlertDialog.Builder(MainActivity.this);
				alb.setTitle(newTitle).setMessage(message).setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {

						@Override
						public void onClick(DialogInterface dialog, int which) {
							result.confirm();
						}
					});
				alb.setCancelable(false);
				alb.setIcon(R.drawable.ebllogo);
				alb.setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
							result.cancel();
						}
					});
				alb.setNeutralButton("EXiT", new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
							finish();
						}
					});
				alb.create();
				alb.show();
				return true;
				// return super.onJsAlert(view, url, message, result);
			}

			@Override
			public boolean onJsConfirm(WebView view, String url,String message, final JsResult result) {
				if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN FINISH")){
					finish();
				}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN TOAST WITH SIZE SHORT AND STRING = ")){
					String str1totoast = message.substring(80,message.length());
					Toast.makeText(MainActivity.this,str1totoast, Toast.LENGTH_SHORT).show();
					result.confirm();
				}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN TOAST WITH SIZE LONG AND STRING = ")){
					String str1totoast = message.substring(79,message.length());
					Toast.makeText(MainActivity.this,str1totoast, Toast.LENGTH_LONG).show();
					result.confirm();
				}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN VIBRATE ")){
					Vibrator vib = (Vibrator) getSystemService(MainActivity.VIBRATOR_SERVICE);
					String str1totoast = message.substring(53,message.length());
					long vibratetime = Integer.parseInt(str1totoast);
					vib.vibrate(vibratetime);
					result.confirm();
				}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN PRINT THIS PAGE")){
					printPDF();
					result.confirm();
				}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN SHOW ACTION BAR")){
					getActionBar().show();
					result.confirm();
				}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN HIDE ACTION BAR")){
					getActionBar().hide();
					result.confirm();
				}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN ON WIFI")){
					WifiManager wifimanager1 = (WifiManager) getSystemService(Context.WIFI_SERVICE);
					wifimanager1.setWifiEnabled(true);
					result.confirm();
				}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN OFF WIFI")){
					WifiManager wifimanager1 = (WifiManager) getSystemService(Context.WIFI_SERVICE);
					wifimanager1.setWifiEnabled(false);
					result.confirm();
				}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN SEND NOTIFICATION")){
					String str1totoast = message.substring(69,message.length());
					String str2totoast = str1totoast.substring(0,str1totoast.indexOf(" &&&02 "));
					String str3totoast = str1totoast.substring(str1totoast.indexOf(" &&&02 ")+7,str1totoast.length());
					Notification.Builder notif = new Notification.Builder(MainActivity.this);
					notif.setContentTitle(str2totoast).setContentText(str3totoast);
					notif.setSmallIcon(R.drawable.ebllogo);
					NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
					nm.notify(1,notif.build());
					result.confirm();
				}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN CUSTOM DIALOG")){
					String str1totoast = message.substring(65,message.length());
					String str2totoast = str1totoast.substring(0,str1totoast.indexOf(" &&&02 "));
					String str3totoast = str1totoast.substring(str1totoast.indexOf(" &&&02 ")+7,str1totoast.indexOf(" &&&03 "));
					String str4totoast = str1totoast.substring(str1totoast.indexOf(" &&&03 ")+7,str1totoast.indexOf(" &&&04 "));
					String str5totoast = str1totoast.substring(str1totoast.indexOf(" &&&04 ")+7,str1totoast.indexOf(" &&&05 "));
					String str6totoast = str1totoast.substring(str1totoast.indexOf(" &&&05 ")+7,str1totoast.indexOf(" &&&06 "));
					String str7totoast = str1totoast.substring(str1totoast.indexOf(" &&&06 ")+7,str1totoast.indexOf(" &&&07 "));
					//String str3totoast = str1totoast.substring(str1totoast.indexOf(" &&&02 ")+7,str1totoast.indexOf(" &&&03 "));
					AlertDialog.Builder alrbui = new AlertDialog.Builder(MainActivity.this);
					if(str7totoast.startsWith("true")){
						alrbui.setCancelable(true);
					}else{
						alrbui.setCancelable(false);
					}
				    alrbui.setTitle(str2totoast);
				    alrbui.setMessage(str3totoast);
					alrbui.setIcon(R.drawable.ebllogo);
				    alrbui.setPositiveButton(str4totoast, new DialogInterface.OnClickListener() {
						    @Override
						    public void onClick(DialogInterface dialog, int which) {
							    result.confirm();
						    }
					    });
				    alrbui.setNegativeButton(str5totoast, new DialogInterface.OnClickListener() {
						    public void onClick(DialogInterface dialog, int which) {
							    result.cancel();
						    }
					    });
				    alrbui.setNeutralButton(str6totoast,new DialogInterface.OnClickListener(){
						    @Override
				    		public void onClick(DialogInterface dialogInterface,int i){
				    			finish();
					        }
					    });
				    alrbui.create();
				    alrbui.show();
				}else{
				    String newTitle = "Confirm "+view.getUrl();
				    AlertDialog.Builder alrbui = new AlertDialog.Builder(MainActivity.this);
				    alrbui.setTitle(newTitle);
				    alrbui.setMessage(message);
					alrbui.setIcon(R.drawable.ebllogo);
				    alrbui.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
						    @Override
						    public void onClick(DialogInterface dialog, int which) {
							    result.confirm();
						    }
					    });
				    alrbui.setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
						    public void onClick(DialogInterface dialog, int which) {
							    result.cancel();
						    }
					    });
				    alrbui.setNeutralButton("EXiT",new DialogInterface.OnClickListener(){
						    @Override
				    		public void onClick(DialogInterface dialogInterface,int i){
				    			finish();
					        }
					    });
				    alrbui.setCancelable(false);
				    alrbui.create();
				    alrbui.show();
				}
				return true;
				// return super.onJsConfirm(view, url, message, result);
			}
			@Override
			public void onConsoleMessage(String message,int lineNumber,String sourceId){
				if(message.startsWith("Uncaught")){
					String mystr = ConsoleData.getText().toString() +"ERROR "+ sourceId + ":"+lineNumber + "="+message+"\n";
					ConsoleData.setText(mystr);
				}else{
					String mystr = ConsoleData.getText().toString() + sourceId + ":"+lineNumber + "="+message+"\n";
					ConsoleData.setText(mystr);
				}
			}
				protected void openFileChooser(ValueCallback uploadMsg, String acceptType)
				{
					mUploadMessage = uploadMsg;
					Intent i = new Intent(Intent.ACTION_GET_CONTENT);
					i.addCategory(Intent.CATEGORY_OPENABLE);
					i.setType("image/*");
					startActivityForResult(Intent.createChooser(i, "File Browser"), FILECHOOSER_RESULTCODE);
				}
				public boolean onShowFileChooser(WebView mWebView, ValueCallback<Uri[]> filePathCallback, WebChromeClient.FileChooserParams fileChooserParams)
				{
					if (uploadMessage != null) {
						uploadMessage.onReceiveValue(null);
						uploadMessage = null;
					}

					uploadMessage = filePathCallback;

					Intent intent = null;
					if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
						intent = fileChooserParams.createIntent();
					}
					try
					{
						startActivityForResult(intent, REQUEST_SELECT_FILE);
					} catch (ActivityNotFoundException e)
					{
						uploadMessage = null;
						return false;
					}
					return true;
				}
			    /*@Override
				public boolean onJsPrompt(WebView view,String url,String message,String defaultValue,final JsPromptResult result){
				AlertDialog.Builder alertProm = new AlertDialog.Builder(MainActivity.this);
				LayoutInflater aInflater = getLayoutInflater();
				View alertLayout = aInflater.inflate(R.layout.prompt, null);
				EditText prpet = findViewById(R.id.aaa);
				alertProm.setView(new EditText(MainActivity.this));
				alertProm.setPositiveButton("ok",new DialogInterface.OnClickListener(){
					@Override
					public void onClick(DialogInterface dialogInterface,int i){
						EditText prpet = findViewById(R.id.aaa);
						result.confirm(prpet.getText().toString());
					}
				});
				alertProm.setNeutralButton("no",new DialogInterface.OnClickListener(){
						@Override
						public void onClick(DialogInterface dialogInterface,int i){
							result.cancel();
						}
					});
				alertProm.show();
				//final EditText textProm = new EditText(MainActivity.this);
					return true;
				}*/
			
			//String mesaage,int lineNumber,String sourceId
			//WebView view,String url,String message,String defaultValue,Japromptresult
		});
		webv1.getSettings().setAllowFileAccess(true);
		webv1.getSettings().setAllowContentAccess(true);
		webv1.getSettings().setAllowFileAccessFromFileURLs(true);
		webv1.getSettings().setAllowUniversalAccessFromFileURLs(true);
		webv1.getSettings().setMinimumFontSize(0);
        webv1.getSettings().setMinimumLogicalFontSize(0);
        webv1.getSettings().setSaveFormData(true);
        webv1.getSettings().setSavePassword(true);
        webv1.getSettings().setStandardFontFamily("serif");
        webv1.getSettings().setDefaultFontSize(16);
        webv1.getSettings().setDatabaseEnabled(true);
        webv1.getSettings().setDomStorageEnabled(true);
        webv1.getSettings().setAppCacheEnabled(true);
        webv1.getSettings().setGeolocationEnabled(true);
        webv1.getSettings().setLoadsImagesAutomatically(true);
        webv1.getSettings().setLoadWithOverviewMode(false);
        webv1.getSettings().setUseWideViewPort(true);
        webv1.getSettings().setJavaScriptEnabled(true);
        webv1.getSettings().setSupportZoom(true);
        webv1.getSettings().setDisplayZoomControls(true);
        webv1.getSettings().setBuiltInZoomControls(true);
		webv1.setNetworkAvailable(true);
		webv1.setWebViewClient(new WebViewClient() {
				@Override
				public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
					return false;
				}
			});
		Button bb1 = findViewById(R.id.bb1);
		Button bb2 = findViewById(R.id.bb2);
		bb1.setOnClickListener(new View.OnClickListener(){
			@Override
			public void onClick(View v){
				AlertDialog.Builder alertdialogB = new AlertDialog.Builder(MainActivity.this);
				alertdialogB.setIcon(R.drawable.ebllogo);
				alertdialogB.setTitle("Run Codes");
				alertdialogB.setMessage("confirm to Run Codes");
				Button theBut = new Button(MainActivity.this);
				theBut.setText("Go to editor");
				theBut.setOnClickListener(new OnClickListener(){
						@Override
						public void onClick(View v){
							startActivity(in1);
						}
					});
				alertdialogB.setView(theBut);
				alertdialogB.setCancelable(false);
				
				alertdialogB.setPositiveButton(android.R.string.no,null)
					.setNegativeButton(android.R.string.yes,new DialogInterface.OnClickListener(){
						@Override
						public void onClick(DialogInterface dialogInterface,int i){
							
							ConsoleData.setText("");
							// <form method="POST"action= .1. ><textarea name=codes> .2. </textarea> <input type=submit> </form>
							String thecodestr = "<form method='POST'style='display:none;'action='"+sp.getString("webUrl","")+"'><textarea name='codes'>"+sp.getString("codes","")+"</textarea><input type='submit'id='submit'></form><script>document.getElementById('submit').click()</script><h1 style='font-size:96px;color:#4080ff;background-color:#ffd000;'>Loading...</h1>";
							webv1.loadData(thecodestr,"","utf-8");
						}
					})
					.setNeutralButton("EXiT",new DialogInterface.OnClickListener(){
						@Override
						public void onClick(DialogInterface dialogInterface,int i){
							finish();
						}
					});
				alertdialogB.create();
				alertdialogB.show();
			};
		});
		bb2.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				AlertDialog.Builder alertdialogB = new AlertDialog.Builder(MainActivity.this);
				alertdialogB.setIcon(R.drawable.ebllogo);
				alertdialogB.setTitle("Console");
				alertdialogB.setMessage("Console Output");
				String strstr1 = ConsoleData.getText().toString();
				String strstr2 = "data:text/html,<style>body{white-space:pre}</style>";
				String strstr3 = strstr2+strstr1;
				WebView ConsoleView = new WebView(MainActivity.this);
				ConsoleView.loadUrl(strstr3);
				alertdialogB.setView(ConsoleView);
				alertdialogB.setCancelable(false);

				alertdialogB.setPositiveButton("CLOSE",null)
					.setNegativeButton(android.R.string.copy,new DialogInterface.OnClickListener(){
						@Override
						public void onClick(DialogInterface dialogInterface,int i){
						}
					})
					.setNeutralButton("EXiT",new DialogInterface.OnClickListener(){
						@Override
						public void onClick(DialogInterface dialogInterface,int i){
							finish();
						}
					});
				alertdialogB.create();
				alertdialogB.show();
			}
		});
		Toast.makeText(MainActivity.this,"Loaded", Toast.LENGTH_LONG).show();
    }
	@Override
    public void onActivityResult(int requestCode, int resultCode, Intent intent)
    {
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
        {
            if (requestCode == REQUEST_SELECT_FILE)
            {
                if (uploadMessage == null)
                    return;
                uploadMessage.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, intent));
                uploadMessage = null;
            }
        }
        else if (requestCode == FILECHOOSER_RESULTCODE)
        {
            if (null == mUploadMessage)
                return;
            // Use MainActivity.RESULT_OK if you're implementing WebView inside Fragment
            // Use RESULT_OK only if you're implementing WebView inside an Activity
            Uri result = intent == null || resultCode != MainActivity.RESULT_OK ? null : intent.getData();
            mUploadMessage.onReceiveValue(result);
            mUploadMessage = null;
        }
	}
	public void printPDF(){
		PrintManager printManager = (PrintManager) this.getSystemService(Context.PRINT_SERVICE);
        WebView wv1 = findViewById(R.id.wv1);
		PrintDocumentAdapter printAdapter = wv1.createPrintDocumentAdapter();
		String jobName = getString(R.string.app_name) + " Print Test";
		printManager.print(jobName, printAdapter, new PrintAttributes.Builder().build());
	}
}

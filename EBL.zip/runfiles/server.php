<?php
    function filesrcget($input){
        $fillop = "";
        $a = 0;
        $b = 0;
        $c = "";
        while($a<strlen($input)){
            if($input[$a]=="<" && $input[$a+1]=="f" && $input[$a+2]=="i" && $input[$a+3]=="l" && $input[$a+4]=="e" && $input[$a+5]==">"){
                $len = strlen($input);
                $b = 6;
                while($b<$len){
                    if($input[$a+$b]=="<" && $input[$a+$b+1]=="/" && $input[$a+$b+2]=="f" && $input[$a+$b+3]=="i" && $input[$a+$b+4]=="l" && $input[$a+$b+5]=="e" && $input[$a+$b+6]==">"){
                        $a = $a + $b + 7;
                        $b = 0;
                        $datb = fopen($c,"r");
                        
                        $fillop = $fillop . fread($datb,filesize($c));
                        fclose($datb);
                        $c = "";
                        break;
                    }
                    $c = $c . $input[$a+$b];
                    $b = $b + 1;
                }
            }else{
                $fillop = $fillop . $input[$a];
            }
            $a = $a + 1;
        }
        return $fillop;
    }
    $file2 = fopen("start.php","r");
    $file3 = fopen("end.php","r");
    $dat2 = fread($file2,filesize("start.php"));
    $dat3 = fread($file3,filesize("end.php"));
    $file = fopen("view.php","w");
    $rqcd = $_REQUEST["codes"];
    $runerlopfile = 0;
    while($runerlopfile<strlen($rqcd)){
        $rqcd = filesrcget($rqcd);
        $runerlopfile = $runerlopfile + 1;
    }
    $rqcd = str_replace("loop{","while(true){",$rqcd);
    $rqcd = str_replace("##","//",$rqcd);
    $rqcd = str_replace("###","//",$rqcd);
    $rqcd = str_replace("dim ","",$rqcd);
    $rqcd = str_replace("for ","for(",$rqcd);
    $rqcd = str_replace("el if","else if",$rqcd);
    $rqcd = str_replace("el-if","elseif",$rqcd);
    $rqcd = str_replace("val ","const ",$rqcd);
    $rqcd = str_replace("XHR","= new XMLHttpRequest()",$rqcd);
    $rqcd = str_replace("-len",".length",$rqcd);
    $rqcd = str_replace("&#12298;","/"."*COMMENT<!--",$rqcd);
    $rqcd = str_replace("&#12299;","-->*"."/",$rqcd);
    $rqcd = str_replace("<css>","<style>",$rqcd);
    $rqcd = str_replace("</css>","</style>",$rqcd);
    $rqcd = str_replace("<js>","<script>",$rqcd);
    $rqcd = str_replace("</js>","</script>",$rqcd);
    $rqcd = str_replace("<python>",'<script type="text/python3">',$rqcd);
    $rqcd = str_replace("</python>",'</script>',$rqcd);
    $rqcd = str_replace("<Python>",'<script type="text/python3">',$rqcd);
    $rqcd = str_replace("</Python>",'</script>',$rqcd);
    $rqcd = str_replace("<PYTHON>",'<script type="text/python3">',$rqcd);
    $rqcd = str_replace("</PYTHON>",'</script>',$rqcd);
    $rqcd = str_replace("<py>",'<script type="text/python3">',$rqcd);
    $rqcd = str_replace("</py>",'</script>',$rqcd);
    $rqcd = str_replace("<Py>",'<script type="text/python3">',$rqcd);
    $rqcd = str_replace("</Py>",'</script>',$rqcd);
    $rqcd = str_replace("<PY>",'<script type="text/python3">',$rqcd);
    $rqcd = str_replace("</PY>",'</script>',$rqcd);
    $rqcd = str_replace("<hbp>",'<script type="text/python3">',$rqcd);
    $rqcd = str_replace("</hbp>",'</script>',$rqcd);
    $rqcd = str_replace("&a","+''+",$rqcd);
    $rqcd = str_replace("&A","+''+",$rqcd);
    $rqcd = str_replace("&t32;","                                                                                                                                ",$rqcd);
    $rqcd = str_replace("&t31;","                                                                                                                            ",$rqcd);
    $rqcd = str_replace("&t30;","                                                                                                                        ",$rqcd);
    $rqcd = str_replace("&t30;","                                                                                                                        ",$rqcd);
    $rqcd = str_replace("&t29;","                                                                                                                    ",$rqcd);
    $rqcd = str_replace("&t28;","                                                                                                                ",$rqcd);
    $rqcd = str_replace("&t27;","                                                                                                            ",$rqcd);
    $rqcd = str_replace("&t26;","                                                                                                         ",$rqcd);
    $rqcd = str_replace("&t25;","                                                                                                    ",$rqcd);
    $rqcd = str_replace("&t24;","                                                                                                 ",$rqcd);
    $rqcd = str_replace("&t23;","                                                                                            ",$rqcd);
    $rqcd = str_replace("&t22;","                                                                                        ",$rqcd);
    $rqcd = str_replace("&t21;","                                                                                    ",$rqcd);
    $rqcd = str_replace("&t20;","                                                                                ",$rqcd);
    $rqcd = str_replace("&t19;","                                                                            ",$rqcd);
    $rqcd = str_replace("&t18;","                                                                        ",$rqcd);
    $rqcd = str_replace("&t18;","                                                                    ",$rqcd);
    $rqcd = str_replace("&t17;","                                                                    ",$rqcd);
    $rqcd = str_replace("&t16;","                                                                ",$rqcd);
    $rqcd = str_replace("&t15;","                                                            ",$rqcd);
    $rqcd = str_replace("&t14;","                                                        ",$rqcd);
    $rqcd = str_replace("&t13;","                                                    ",$rqcd);
    $rqcd = str_replace("&t12;","                                                ",$rqcd);
    $rqcd = str_replace("&t11;","                                            ",$rqcd);
    $rqcd = str_replace("&t10;","                                         ",$rqcd);
    $rqcd = str_replace("&t9;","                                     ",$rqcd);
    $rqcd = str_replace("&t8;","                                ",$rqcd);
    $rqcd = str_replace("&t7;","                            ",$rqcd);
    $rqcd = str_replace("&t6;","                        ",$rqcd);
    $rqcd = str_replace("&t5;","                    ",$rqcd);
    $rqcd = str_replace("&t4;","                ",$rqcd);
    $rqcd = str_replace("&t3;","            ",$rqcd);
    $rqcd = str_replace("&t2;","        ",$rqcd);
    $rqcd = str_replace("&t1;","    ",$rqcd);
    $rqcd = str_replace("&t0;","",$rqcd);
    $rqcd = str_replace("<haj>","<script>",$rqcd);
    $rqcd = str_replace("</haj>","</script>",$rqcd);
    $rqcd = str_replace("<hap>","<?php ",$rqcd);
    $rqcd = str_replace("</hap>"," ?>",$rqcd);
    fwrite($file,$dat2);
    fwrite($file,$rqcd);
    fwrite($file,$dat3);
?>
<script>
    location.href="view.php";
</script>
<meta charset="UTF-8"><script src="./libjs/eruda.min.js"></script><script src="./libjs/eustia.min.js"></script><script src="./libjs/sweetalert.min.js"></script><script src="./libjs/jquery.js"></script><script src="./libjs/brython.min.js"></script><script src="./libjs/three.js"></script><script src="./libjs/brython_stdlib.js"></script><script>eruda.init(), eruda.get("console").config.set("displayGetterVal", !0);console.clear()</script><script src="./fun.js"></script><?php include "fun.php" ?>
<input type="file"><div id="eblhaa"></div><script>brython();
var eblhaaCodessss = ""
var eblhaaTagssss = document.querySelectorAll("haa")
for(eblhaaaddnigstrcodessss in eblhaaTagssss){
    if(eblhaaTagssss[eblhaaaddnigstrcodessss]["innerHTML"]===undefined){
        break
    }
    eblhaaCodessss+=eblhaaTagssss[eblhaaaddnigstrcodessss]["innerHTML"]
}
eval(translateEblHaaToJs(eblhaaCodessss))
</script>
<style>
haa{
    display:none;
}
</style>
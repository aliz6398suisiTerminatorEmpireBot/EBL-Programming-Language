<meta charset="UTF-8"><script src="./libjs/eruda.min.js"></script><script src="./libjs/eustia.min.js"></script><script src="./libjs/sweetalert.min.js"></script><script src="./libjs/jquery.js"></script><script src="./libjs/brython.min.js"></script><script src="./libjs/three.js"></script><script src="./libjs/brython_stdlib.js"></script><script>eruda.init(), eruda.get("console").config.set("displayGetterVal", !0);console.clear()</script><script src="./fun.js"></script><?php include "fun.php" ?>
<script>
prompt(2,5)
prompt(5,2)
</script><script>brython()</script>
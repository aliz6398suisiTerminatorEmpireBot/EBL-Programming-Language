<div id="eblhaa"></div><script>brython();
var eblhaaCodessss = ""
var eblhaaTagssss = document.querySelectorAll("haa")
for(eblhaaaddnigstrcodessss in eblhaaTagssss){
    if(eblhaaTagssss[eblhaaaddnigstrcodessss]["innerHTML"]===undefined){
        break
    }
    eblhaaCodessss+=eblhaaTagssss[eblhaaaddnigstrcodessss]["innerHTML"]
}
eval(translateEblHaaToJs(eblhaaCodessss))
</script>
<style>
haa{
    display:none;
}
</style>
var fmt = {"print":function (g){console.log(g)},"PrintLn":function (g){console.log(g)},"Print":function (g){console.log(g)}};var System = {"out":{"print":function (g){console.log(g)},"println":function (g){console.log(g)}}};var lcd = {"print":function (g){console.log(g)}};var alr = function (g){h = alert(g)};var cnf = function (g){confirm(g)};var prp = function prp(g,i){prompt(g,i)};var printf = function (g){document.write(g)};var println = function (g){console.log(g)};var fie = function (g){document.write("<fieldset>"+g+"</fieldset>")};var hl = function (hrcolor,hrwidth,hrloop){if(hrcolor==undefined){hrcolor="#000000"};if(hrwidth==undefined){hrcolor="100"};if(hrloop==undefined){hrcolor="1"};for(var inloop=0;inloop<hrloop;inloop++){document.write(`<hr color="`+hrcolor+`"width="`+hrwidth+`"></hr>`)}};var bl = function (loops){if(loops==undefined){loops=1};for(var inloop=0;inloop<loops;inloop++);{document.write("<br>")}};var text = function (textb,style){document.write(`<text style="${style}">${textb}</text>`);console.log(`%c${textb}`,style);console.warn(`%c${textb}`,style);console.error(textb)};function a(text,href){document.write(`<a href="${href}">${text}</a>`)}function i(text){document.write("<i>"+text+"</i>")};function input(type,id,style,value,placeholder,min,max,step){if(type != "multiLine"){document.write(`<input id="${id}"type="${type}"style="${style}"placeholder="${placeholder}"value="${value}">`)};if(type=="multiLine"){document.write(`<textarea id="${id}"style="${style}"placeholder="${placeholder}">${value}</textarea>`)}};function file(type,address,id,text){if(type=="sel"||type=="select"||type=="change"){document.write(`<input type="file"id="${id}"></input>`)};if(type=="img"){document.write(`<img src="${address}"></img>`)};if(type=="audio"){document.write(`<audio src="${address}"></audio>`)};if(type=="video"){document.write(`<video src="${address}"></video>`)}};var iframe = function (addtype,address,id){document.write(`<iframe ${addtype?"srcdoc":"src"}="${address}"id="${id}"></iframe>`)};function progress(id,min,max,value){document.write(`<progress id="${id}"min="${min}"max="${max}"value="value">`)};function getFullObject(value){var ret = "";for(var i in value){ret = ret + `${i} : ${value[i]} , `};return ret};function getFullArray(value){var ret="";for(i of value){ret = ret + `${i} , `};return ret};var print_r = function (value){document.write(value)};var cat = function(value){console.log(cat)};var writeHTML = function (value){documentw.rite(value)};var col = function (val){console.log(val)};var dow = function (val){console.log(val)};var cat = function (val){console.log(val)};var showMe = function (val){console.log(val)};function rand(i,a){return Math.random()*(a-i)+i};function Print(val){console.log(val+"\n")};function PRINT(val){console.log(val+"\n")};function ctArray(a,b){return Array(a+","+b)};function nicePrint(val){document.write(val+"\n")};function echo(val){document.write(val+"\n")};function cout(val){console.log(val+"\n")};var Printer = {"printIn":function printIn(g){console.log(g)}};var BS = {"WL":function WL(g){console.log(g)}};
function printc(val){console.log(val+"\n")};
function puts(val){console.log(val+"\n")};
function out(val){console.log(val+"\n")};
console["Write"] = console.log
console["WriteLine"] = console.log
console["Read"] = prompt
console["ReadLine"] = prompt

var loop = (s,e,f) => {
    r = s
    if(e>s){
        b = true
    }else if(s>e){
        b = false
    }
    if(b == true){
        while(e>r){
            eval(f)
            r = r + 1
        }
    }else if(b == false){
        while(r>e){
            eval(f)
            r = r - 1
        }
    }
    rt = r
    r = 0
    return rt
}
var crvar = (name,val,nums) => {
    var running = 0
    while(running < nums){
        var h = name + running + " = " + val
        eval(h)
        running = running + 1
    }
}
Math["hypow"] = {}
Math["hypow"]["l1"] = function (a,b){
    var c = a
    for(var d=1;d<b;d++){
        var c = c ** a
    }
    return c
}
Math["hypow"]["l2"] = function (a,b){
    var c = a
    for(var d=1;d<b;d++){
        var c = Math.hypow.l1(c,a);
    }
    return c
}
Math["hypow"]["l3"] = function (a,b){
    var c = a
    for(var d=1;d<b;d++){
        var c = Math.hypow.l2(c,a);
    }
    return c
}
function dota(ad1,ad2){
    var xxx1 = ad1
    for(var xxx2=0;xxx2<ad2;xxx2++){
        xxx1 = xxx1 / ad1
    }
    return xxx1
}
function sortBubble(arr){
    if(arr == undefined){
        throw new TypeError("Array is not defined");
    }
    if(typeof arr != "object"){
        throw new TypeError("input not a Array")
    }
    var len = arr.length
    var temp;
    for(var i=0;i<len;i++){
        for(var j=0;j<len;j++){
            if(arr[j] > arr[j+1]){
                temp = arr[j]
                arr[j] = arr[j+1]
                arr[j+1] = temp
            }
        }
    }
    return arr;
}
var eblStringHasher1 = {
    "hide":function (i){
        var a = btoa(i);
        var b = ""
        for(var c=0;c<a.length;c++){
            b = b + (Math.round(Math.random()*36)).toString(36) + a.charAt(c)
        }
        return b
    },
    "show":function hideBawfln(i){
        var a = ""
        var c = i
        for(var b=0;b<i.length;b++){
            if(b % 2 == 0){
                
            }else{
                a = a + c.charAt(b)
            }
        }
        return atob(a)
    }

}
function removeStr(str,dis){
    if(dis==undefined){dis=" "}
    return str.replaceAll(dis,"");
};
function last(str1){
    return str1.substr(str1.length-1,1);
};
function first(str1){
    return str1.substr(0,1);
};
function plus(str1,str2){
    return str1 + str2;
};
function compareTo(str1,str2){
    if(str1==str2){
        return true
    }
    var text = 0
    var co = str1.length>str2.length ? str1.length : str2.length
    for(var i=0;i<co;i++){
        if(str1.charCodeAt(i)==str2.charCodeAt(i)){
            text += 1
        }
    }
    return text;
};
function isDigit(text){
    for(var i=0;i<text.length;i++){
        if(text.charAt(i)!="0"&&text.charAt(i)!="1"&&text.charAt(i)!="2"&&text.charAt(i)!="3"&&text.charAt(i)!="4"&&text.charAt(i)!="5"&&text.charAt(i)!="6"&&text.charAt(i)!="7"&&text.charAt(i)!="8"&&text.charAt(i)!="9"){
            return false
        }
    }
    return true
}
function isSpace(text){
    for(var i=0;i<text.length;i++){
        if(text.charAt(i)!=" "){
            return false
        }
    }
    return true
}
function isLower(text){
    for(var i=0;i<text.length;i++){
        if(text.charAt(i)!="a"&&text.charAt(i)!="b"&&text.charAt(i)!="c"&&text.charAt(i)!="d"&&text.charAt(i)!="e"&&text.charAt(i)!="f"&&text.charAt(i)!="g"&&text.charAt(i)!="h"&&text.charAt(i)!="i"&&text.charAt(i)!="j"&&text.charAt(i)!="k"&&text.charAt(i)!="l"&&text.charAt(i)!="m"&&text.charAt(i)!="n"&&text.charAt(i)!="o"&&text.charAt(i)!="p"&&text.charAt(i)!="q"&&text.charAt(i)!="r"&&text.charAt(i)!="s"&&text.charAt(i)!="t"&&text.charAt(i)!="u"&&text.charAt(i)!="v"&&text.charAt(i)!="w"&&text.charAt(i)!="x"&&text.charAt(i)!="y"&&text.charAt(i)!="z"){
            return false
        }
    }
    return true
}
function isUpper(text){
    for(var i=0;i<text.length;i++){
        if(text.charAt(i)!="A"&&text.charAt(i)!="B"&&text.charAt(i)!="C"&&text.charAt(i)!="D"&&text.charAt(i)!="E"&&text.charAt(i)!="F"&&text.charAt(i)!="G"&&text.charAt(i)!="H"&&text.charAt(i)!="I"&&text.charAt(i)!="J"&&text.charAt(i)!="K"&&text.charAt(i)!="L"&&text.charAt(i)!="M"&&text.charAt(i)!="N"&&text.charAt(i)!="O"&&text.charAt(i)!="P"&&text.charAt(i)!="Q"&&text.charAt(i)!="R"&&text.charAt(i)!="Q"&&text.charAt(i)!="T"&&text.charAt(i)!="U"&&text.charAt(i)!="V"&&text.charAt(i)!="W"&&text.charAt(i)!="X"&&text.charAt(i)!="Y"&&text.charAt(i)!="Z"){
            return false
        }
    }
    return true
}
function contains(text,search){
    return text.search(search) == -1?false:true
}
function reserved(text){
    var textb = ""
    for(i=text.length;i>=0;i--){
        textb = textb + text.charAt(i)
    }
    return textb
}
function str_bit(input){
    var bit = ""
    for(var i=0;i<input.length;i++){
        bit = bit + input.charCodeAt(i).toString(2).padStart(8,0)
    }
    return bit
}
function str_hex(input){
    var bit = ""
    for(var i=0;i<input.length;i++){
        bit = bit + input.charCodeAt(i).toString(16).padStart(2,0)
    }
    return bit
}
function str_num(input){
    var bit = ""
    for(var i=0;i<input.length;i++){
        bit = bit + input.charCodeAt(i).toString(10).padStart(3,0)
    }
    return bit
}
function str_more(mobno,input){
    var x = (255).toString(mobno).length
    var bit = ""
    var lent = input.length
    for(var i=0;i<lent;i++){
        bit = bit + input.charCodeAt(i).toString(mobno).padStart(x,0)
    }
    return bit
}
function bit_str(input){
    var string = ""
    var str = ""
    for(i=0;i<input.length;i++){
        str = str + input.charAt(i)
        if(str.length==8){
            n = 0;
            bchn = parseInt(str);
            for (let j = 0; j<str.length; j++){
                n = n + (bchn%10)*(Math.pow(2, j) | 0);
                bchn = ((bchn/10) | 0);
            }
            string = string + String.fromCharCode(n);
            var n = 0;
            var str = ""
        }
    }
    return string
}
function hex_str(input){
    var string = ""
    var str = ""
    for(i=0;i<input.length;i++){
        str = str + input.charAt(i)
        if(str.length==2){
            n = 0;
            bchn = parseInt(str);
            for (let j = 0; j<str.length; j++){
                n = n + (bchn%10)*(Math.pow(16, j) | 0);
                bchn = ((bchn/10) | 0);
            }
            string = string + String.fromCharCode(n);
            var n = 0;
            var str = ""
        }
    }
    return string
}
function num_str(input){
    var string = ""
    var str = ""
    for(i=0;i<input.length;i++){
        str = str + input.charAt(i)
        if(str.length==3){
            n = 0;
            bchn = parseInt(str);
            for (let j = 0; j<str.length; j++){
                n = n + (bchn%10)*(Math.pow(10, j) | 0);
                bchn = ((bchn/10) | 0);
            }
            string = string + String.fromCharCode(n);
            var n = 0;
            var str = ""
        }
    }
    return string
}
function more_str(mobno,input){
    var x = (255).toString(mobno).length
    var string = ""
    var str = ""
    for(i=0;i<input.length;i++){
        str = str + input.charAt(i)
        if(str.length==x){
            n = 0;
            bchn = parseInt(str);
            for (let j = 0; j<str.length; j++){
                n = n + (bchn%10)*(Math.pow(mobno, j) | 0);
                bchn = ((bchn/10) | 0);
            }
            string = string + String.fromCharCode(n);
            var n = 0;
            var str = ""
        }
    }
    return string
}
function bit_num(input){
    var string = ""
    var str = ""
    for(i=0;i<input.length;i++){
        str = str + eval(input.charAt(i))
        if(str.length==input.length){
            n = 0;
            bchn = parseInt(str);
            for (let j = 0; j<str.length; j++){
                n = n + (bchn%10)*(Math.pow(2, j) | 0);
                bchn = ((bchn/10) | 0);
            }
            string = string + n;
            var n = 0;
            var str = ""
        }
    }
    return string
}
function num_bit(input){
    return input.toString(2)
}
function hex_num(input){
    eval(`var myhex = 0x${data}`)
    return myhex
}
function num_hex(input){
    return input.toString(16)
}
function more_num(mobno,input){
    var string = ""
    var str = ""
    for(i=0;i<input.length;i++){
        str = str + eval(input.charAt(i))
        if(str.length==input.length){
            n = 0;
            bchn = parseInt(str);
            for (let j = 0; j<str.length; j++){
                n = n + (bchn%10)*(Math.pow(mobno, j) | 0);
                bchn = ((bchn/10) | 0);
            }
            string = string + n;
            var n = 0;
            var str = ""
        }
    }
    return string
}
function num_more(mobno,input){
    return input.toString(mobno)
}
function bit_hex(input){
    var string = ""
    var str = ""
    for(i=0;i<input.length;i++){
        str = str + eval(input.charAt(i))
        if(str.length==4){
            n = 0;
            bchn = parseInt(str);
            for (let j = 0; j<str.length; j++){
                n = n + (bchn%10)*(Math.pow(2, j) | 0);
                bchn = ((bchn/10) | 0);
            }
            string = string + n.toString(16);
            var n = 0;
            var str = ""
        }
    }
    return string
}
function hex_bit(input){
    eval(`var myhex = 0x${input}`)
    return myhex.toString(2)
}
function hex_more(mobno,data){
    eval(`var myhex = 0x${data}`)
    return myhex.toString(mobno)
}
function Byte(firstNumber){
    if(typeof firstNumber == "number"){
        firstNumber = Math.round(firstNumber)
        firstNumber = eval(firstNumber+"n")
    }
    if(firstNumber < (0n-(2n**8n/2n)) || firstNumber > (2n**8n/2n-1n)){
            throw new RangeError(`Variable Outed in Byte Range : ${0n-(2n**8n/2n)} ~ ${2n**8n/2n-1n}`)
        }else{
            this.value = firstNumber
        }
    this.set = function (updateValue){
        if(typeof firstNumber == "number"){
            firstNumber = Math.round(firstNumber)
            firstNumber = eval(firstNumber+"n")
        }
        if(updateValue < (0n-(2n**8n/2n)) || updateValue > (2n**8n/2n-1n)){
            throw new RangeError(`Variable Outed in Byte Range : ${0n-(2n**8n/2n)} ~ ${2n**8n/2n-1n}`)
        }else{
            this.value = updateValue
        }
    }
}
function UnsignedByte(firstNumber){
    if(typeof firstNumber == "number"){
        firstNumber = Math.round(firstNumber)
        firstNumber = eval(firstNumber+"n")
    }
    if(firstNumber < 0 || firstNumber > (2n**8n-1n)){
            throw new RangeError(`Variable Outed in Byte Range : 0 ~ ${2n**8n-1n}`)
        }else{
            this.value = firstNumber
        }
    this.set = function (updateValue){
        if(typeof firstNumber == "number"){
            firstNumber = Math.round(firstNumber)
            firstNumber = eval(firstNumber+"n")
        }
        if(updateValue < 0 || updateValue > (2n**8n-1n)){
            throw new RangeError(`Variable Outed in Byte Range : 0 ~ ${2n**8n-1n}`)
        }else{
            this.value = updateValue
        }
    }
}
function Short(firstNumber){
    if(typeof firstNumber == "number"){
        firstNumber = Math.round(firstNumber)
        firstNumber = eval(firstNumber+"n")
    }
    if(firstNumber < (0n-(2n**16n/2n)) || firstNumber > (2n**16n/2n-1n)){
            throw new RangeError(`Variable Outed in Short Range : ${0n-(2n**16n/2n)} ~ ${2n**16n/2n-1n}`)
        }else{
            this.value = firstNumber
        }
    this.set = function (updateValue){
        if(typeof firstNumber == "number"){
            firstNumber = Math.round(firstNumber)
            firstNumber = eval(firstNumber+"n")
        }
        if(updateValue < (0n-(2n**16n/2n)) || updateValue > (2n**16n/2n-1n)){
            throw new RangeError(`Variable Outed in Short Range : ${0n-(2n**16n/2n)} ~ ${2n**16n/2n-1n}`)
        }else{
            this.value = updateValue
        }
    }
}
function UnsignedShort(firstNumber){
    if(typeof firstNumber == "number"){
        firstNumber = Math.round(firstNumber)
        firstNumber = eval(firstNumber+"n")
    }
    if(firstNumber < 0 || firstNumber > (2n**16n-1n)){
            throw new RangeError(`Variable Outed in Short Range : 0 ~ ${2n**16n-1n}`)
        }else{
            this.value = firstNumber
        }
    this.set = function (updateValue){
        if(typeof firstNumber == "number"){
            firstNumber = Math.round(firstNumber)
            firstNumber = eval(firstNumber+"n")
        }
        if(updateValue < 0 || updateValue > (2n**16n-1n)){
            throw new RangeError(`Variable Outed in Short Range : 0 ~ ${2n**16n-1n}`)
        }else{
            this.value = updateValue
        }
    }
}
function Int(firstNumber){
    if(typeof firstNumber == "number"){
        firstNumber = Math.round(firstNumber)
        firstNumber = eval(firstNumber+"n")
    }
    if(firstNumber < (0n-(2n**32n/2n)) || firstNumber > (2n**32n/2n-1n)){
            throw new RangeError(`Variable Outed in Int Range : ${0n-(2n**32n/2n)} ~ ${2n**32n/2n-1n}`)
        }else{
            this.value = firstNumber
        }
    this.set = function (updateValue){
        if(typeof firstNumber == "number"){
            firstNumber = Math.round(firstNumber)
            firstNumber = eval(firstNumber+"n")
        }
        if(updateValue < (0n-(2n**32n/2n)) || updateValue > (2n**32n/2n-1n)){
            throw new RangeError(`Variable Outed in Int Range : ${0n-(2n**32n/2n)} ~ ${2n**32n/2n-1n}`)
        }else{
            this.value = updateValue
        }
    }
}
function UnsignedInt(firstNumber){
    if(typeof firstNumber == "number"){
        firstNumber = Math.round(firstNumber)
        firstNumber = eval(firstNumber+"n")
    }
    if(firstNumber < 0 || firstNumber > (2n**32n-1n)){
            throw new RangeError(`Variable Outed in Int Range : 0 ~ ${2n**32n-1n}`)
        }else{
            this.value = firstNumber
        }
    this.set = function (updateValue){
        if(typeof firstNumber == "number"){
            firstNumber = Math.round(firstNumber)
            firstNumber = eval(firstNumber+"n")
        }
        if(updateValue < 0 || updateValue > (2n**32n-1n)){
            throw new RangeError(`Variable Outed in Int Range : 0 ~ ${2n**32n-1n}`)
        }else{
            this.value = updateValue
        }
    }
}
function Long(firstNumber){
    if(typeof firstNumber == "number"){
        firstNumber = Math.round(firstNumber)
        firstNumber = eval(firstNumber+"n")
    }
    if(firstNumber < (0n-(2n**64n/2n)) || firstNumber > (2n**64n/2n-1n)){
            throw new RangeError(`Variable Outed in Long Range : ${0n-(2n**64n/2n)} ~ ${2n**64n/2n-1n}`)
        }else{
            this.value = firstNumber
        }
    this.set = function (updateValue){
        if(typeof firstNumber == "number"){
            firstNumber = Math.round(firstNumber)
            firstNumber = eval(firstNumber+"n")
        }
        if(updateValue < (0n-(2n**64n/2n)) || updateValue > (2n**64n/2n-1n)){
            throw new RangeError(`Variable Outed in Long Range : ${0n-(2n**64n/2n)} ~ ${2n**64n/2n-1n}`)
        }else{
            this.value = updateValue
        }
    }
}
function UnsignedLong(firstNumber){
    if(typeof firstNumber == "number"){
        firstNumber = Math.round(firstNumber)
        firstNumber = eval(firstNumber+"n")
    }
    if(firstNumber < 0 || firstNumber > (2n**64n-1n)){
            throw new RangeError(`Variable Outed in Long Range : 0 ~ ${2n**64n-1n}`)
        }else{
            this.value = firstNumber
        }
    this.set = function (updateValue){
        if(typeof firstNumber == "number"){
            firstNumber = Math.round(firstNumber)
            firstNumber = eval(firstNumber+"n")
        }
        if(updateValue < 0 || updateValue > (2n**64n-1n)){
            throw new RangeError(`Variable Outed in Long Range : 0 ~ ${2n**64n-1n}`)
        }else{
            this.value = updateValue
        }
    }
}
function Int8(firstNumber){
    if(typeof firstNumber == "number"){
        firstNumber = Math.round(firstNumber)
        firstNumber = eval(firstNumber+"n")
    }
    if(firstNumber < (0n-(2n**8n/2n)) || firstNumber > (2n**8n/2n-1n)){
            throw new RangeError(`Variable Outed in Int8 Range : ${0n-(2n**8n/2n)} ~ ${2n**8n/2n-1n}`)
        }else{
            this.value = firstNumber
        }
    this.set = function (updateValue){
        if(typeof firstNumber == "number"){
            firstNumber = Math.round(firstNumber)
            firstNumber = eval(firstNumber+"n")
        }
        if(updateValue < (0n-(2n**8n/2n)) || updateValue > (2n**8n/2n-1n)){
            throw new RangeError(`Variable Outed in Int8 Range : ${0n-(2n**8n/2n)} ~ ${2n**8n/2n-1n}`)
        }else{
            this.value = updateValue
        }
    }
}
function UInt8(firstNumber){
    if(typeof firstNumber == "number"){
        firstNumber = Math.round(firstNumber)
        firstNumber = eval(firstNumber+"n")
    }
    if(firstNumber < 0 || firstNumber > (2n**8n-1n)){
            throw new RangeError(`Variable Outed in Int8 Range : 0 ~ ${2n**8n-1n}`)
        }else{
            this.value = firstNumber
        }
    this.set = function (updateValue){
        if(typeof firstNumber == "number"){
            firstNumber = Math.round(firstNumber)
            firstNumber = eval(firstNumber+"n")
        }
        if(updateValue < 0 || updateValue > (2n**8n-1n)){
            throw new RangeError(`Variable Outed in Int8 Range : 0 ~ ${2n**8n-1n}`)
        }else{
            this.value = updateValue
        }
    }
}
function Int16(firstNumber){
    if(typeof firstNumber == "number"){
        firstNumber = Math.round(firstNumber)
        firstNumber = eval(firstNumber+"n")
    }
    if(firstNumber < (0n-(2n**16n/2n)) || firstNumber > (2n**16n/2n-1n)){
            throw new RangeError(`Variable Outed in Int16 Range : ${0n-(2n**16n/2n)} ~ ${2n**16n/2n-1n}`)
        }else{
            this.value = firstNumber
        }
    this.set = function (updateValue){
        if(typeof firstNumber == "number"){
            firstNumber = Math.round(firstNumber)
            firstNumber = eval(firstNumber+"n")
        }
        if(updateValue < (0n-(2n**16n/2n)) || updateValue > (2n**16n/2n-1n)){
            throw new RangeError(`Variable Outed in Int16 Range : ${0n-(2n**16n/2n)} ~ ${2n**16n/2n-1n}`)
        }else{
            this.value = updateValue
        }
    }
}
function UInt16(firstNumber){
    if(typeof firstNumber == "number"){
        firstNumber = Math.round(firstNumber)
        firstNumber = eval(firstNumber+"n")
    }
    if(firstNumber < 0 || firstNumber > (2n**16n-1n)){
            throw new RangeError(`Variable Outed in Int16 Range : 0 ~ ${2n**16n-1n}`)
        }else{
            this.value = firstNumber
        }
    this.set = function (updateValue){
        if(typeof firstNumber == "number"){
            firstNumber = Math.round(firstNumber)
            firstNumber = eval(firstNumber+"n")
        }
        if(updateValue < 0 || updateValue > (2n**16n-1n)){
            throw new RangeError(`Variable Outed in Int16 Range : 0 ~ ${2n**16n-1n}`)
        }else{
            this.value = updateValue
        }
    }
}
function Int32(firstNumber){
    if(typeof firstNumber == "number"){
        firstNumber = Math.round(firstNumber)
        firstNumber = eval(firstNumber+"n")
    }
    if(firstNumber < (0n-(2n**32n/2n)) || firstNumber > (2n**32n/2n-1n)){
            throw new RangeError(`Variable Outed in Int32 Range : ${0n-(2n**32n/2n)} ~ ${2n**32n/2n-1n}`)
        }else{
            this.value = firstNumber
        }
    this.set = function (updateValue){
        if(typeof firstNumber == "number"){
            firstNumber = Math.round(firstNumber)
            firstNumber = eval(firstNumber+"n")
        }
        if(updateValue < (0n-(2n**32n/2n)) || updateValue > (2n**32n/2n-1n)){
            throw new RangeError(`Variable Outed in Int32 Range : ${0n-(2n**32n/2n)} ~ ${2n**32n/2n-1n}`)
        }else{
            this.value = updateValue
        }
    }
}
function UInt32(firstNumber){
    if(typeof firstNumber == "number"){
        firstNumber = Math.round(firstNumber)
        firstNumber = eval(firstNumber+"n")
    }
    if(firstNumber < 0 || firstNumber > (2n**32n-1n)){
            throw new RangeError(`Variable Outed in Int32 Range : 0 ~ ${2n**32n-1n}`)
        }else{
            this.value = firstNumber
        }
    this.set = function (updateValue){
        if(typeof firstNumber == "number"){
            firstNumber = Math.round(firstNumber)
            firstNumber = eval(firstNumber+"n")
        }
        if(updateValue < 0 || updateValue > (2n**32n-1n)){
            throw new RangeError(`Variable Outed in Int32 Range : 0 ~ ${2n**32n-1n}`)
        }else{
            this.value = updateValue
        }
    }
}
function Int64(firstNumber){
    if(typeof firstNumber == "number"){
        firstNumber = Math.round(firstNumber)
        firstNumber = eval(firstNumber+"n")
    }
    if(firstNumber < (0n-(2n**64n/2n)) || firstNumber > (2n**64n/2n-1n)){
            throw new RangeError(`Variable Outed in Int64 Range : ${0n-(2n**64n/2n)} ~ ${2n**64n/2n-1n}`)
        }else{
            this.value = firstNumber
        }
    this.set = function (updateValue){
        if(typeof firstNumber == "number"){
            firstNumber = Math.round(firstNumber)
            firstNumber = eval(firstNumber+"n")
        }
        if(updateValue < (0n-(2n**64n/2n)) || updateValue > (2n**64n/2n-1n)){
            throw new RangeError(`Variable Outed in Int64 Range : ${0n-(2n**64n/2n)} ~ ${2n**64n/2n-1n}`)
        }else{
            this.value = updateValue
        }
    }
}
function UInt64(firstNumber){
    if(typeof firstNumber == "number"){
        firstNumber = Math.round(firstNumber)
        firstNumber = eval(firstNumber+"n")
    }
    if(firstNumber < 0 || firstNumber > (2n**64n-1n)){
            throw new RangeError(`Variable Outed in Int64 Range : 0 ~ ${2n**64n-1n}`)
        }else{
            this.value = firstNumber
        }
    this.set = function (updateValue){
        if(typeof firstNumber == "number"){
            firstNumber = Math.round(firstNumber)
            firstNumber = eval(firstNumber+"n")
        }
        if(updateValue < 0 || updateValue > (2n**64n-1n)){
            throw new RangeError(`Variable Outed in Int64 Range : 0 ~ ${2n**64n-1n}`)
        }else{
            this.value = updateValue
        }
    }
}
function Int128(firstNumber){
    if(typeof firstNumber == "number"){
        firstNumber = Math.round(firstNumber)
        firstNumber = eval(firstNumber+"n")
    }
    if(firstNumber < (0n-(2n**128n/2n)) || firstNumber > (2n**128n/2n-1n)){
            throw new RangeError(`Variable Outed in Int128 Range : ${0n-(2n**128n/2n)} ~ ${2n**128n/2n-1n}`)
        }else{
            this.value = firstNumber
        }
    this.set = function (updateValue){
        if(typeof firstNumber == "number"){
            firstNumber = Math.round(firstNumber)
            firstNumber = eval(firstNumber+"n")
        }
        if(updateValue < (0n-(2n**128n/2n)) || updateValue > (2n**128n/2n-1n)){
            throw new RangeError(`Variable Outed in Int128 Range : ${0n-(2n**128n/2n)} ~ ${2n**128n/2n-1n}`)
        }else{
            this.value = updateValue
        }
    }
}
function UInt128(firstNumber){
    if(typeof firstNumber == "number"){
        firstNumber = Math.round(firstNumber)
        firstNumber = eval(firstNumber+"n")
    }
    if(firstNumber < 0 || firstNumber > (2n**128n-1n)){
            throw new RangeError(`Variable Outed in Int128 Range : 0 ~ ${2n**128n-1n}`)
        }else{
            this.value = firstNumber
        }
    this.set = function (updateValue){
        if(typeof firstNumber == "number"){
            firstNumber = Math.round(firstNumber)
            firstNumber = eval(firstNumber+"n")
        }
        if(updateValue < 0 || updateValue > (2n**128n-1n)){
            throw new RangeError(`Variable Outed in Int128 Range : 0 ~ ${2n**128n-1n}`)
        }else{
            this.value = updateValue
        }
    }
}
function Int256(firstNumber){
    if(typeof firstNumber == "number"){
        firstNumber = Math.round(firstNumber)
        firstNumber = eval(firstNumber+"n")
    }
    if(firstNumber < (0n-(2n**256n/2n)) || firstNumber > (2n**256n/2n-1n)){
            throw new RangeError(`Variable Outed in Int256 Range : ${0n-(2n**256n/2n)} ~ ${2n**256n/2n-1n}`)
        }else{
            this.value = firstNumber
        }
    this.set = function (updateValue){
        if(typeof firstNumber == "number"){
            firstNumber = Math.round(firstNumber)
            firstNumber = eval(firstNumber+"n")
        }
        if(updateValue < (0n-(2n**256n/2n)) || updateValue > (2n**256n/2n-1n)){
            throw new RangeError(`Variable Outed in Int256 Range : ${0n-(2n**256n/2n)} ~ ${2n**256n/2n-1n}`)
        }else{
            this.value = updateValue
        }
    }
}
function UInt256(firstNumber){
    if(typeof firstNumber == "number"){
        firstNumber = Math.round(firstNumber)
        firstNumber = eval(firstNumber+"n")
    }
    if(firstNumber < 0 || firstNumber > (2n**256n-1n)){
            throw new RangeError(`Variable Outed in Int256 Range : 0 ~ ${2n**256n-1n}`)
        }else{
            this.value = firstNumber
        }
    this.set = function (updateValue){
        if(typeof firstNumber == "number"){
            firstNumber = Math.round(firstNumber)
            firstNumber = eval(firstNumber+"n")
        }
        if(updateValue < 0 || updateValue > (2n**256n-1n)){
            throw new RangeError(`Variable Outed in Int256 Range : 0 ~ ${2n**256n-1n}`)
        }else{
            this.value = updateValue
        }
    }
}
function MInt(bits,firstNumber){
    if(typeof bits == "bigint"){
        bits = Number(bits)
        bits = Math.round(bits)
    }
    if(typeof firstNumber == "number"){
        firstNumber = Math.round(firstNumber)
        firstNumber = eval(firstNumber+"n")
    }
    this.bits = bits
        if(firstNumber < (0-(2**this.bits/2)) || firstNumber > (2**this.bits/2-1)){
            throw new RangeError(`Variable Outed in Int${this.bits} Range : ${0-(2**this.bits/2)} ~ ${2**this.bits/2-1}`)
        }else{
            this.value = eval(firstNumber+"n")
        }
    this.set = function (updateValue){
        if(typeof updateValue == "number"){
            updateValue = Math.round(updateValue)
            updateValue = eval(updateValue+"n")
        }
        if(updateValue < (0-(2**this.bits/2)) || updateValue > (2**this.bits/2-1)){
            throw new RangeError(`Variable Outed in Int${this.bits} Range : ${0-(2**this.bits/2)} ~ ${2**this.bits/2-1}`)
        }else{
            this.value = eval(updateValue+"n")
        }
    }
}
function UMInt(bits,firstNumber){
    if(typeof bits == "bigint"){
        bits = Number(bits)
        bits = Math.round(bits)
    }
    if(typeof firstNumber == "number"){
        firstNumber = Math.round(firstNumber)
        firstNumber = eval(firstNumber+"n")
    }
    this.bits = bits
        if(firstNumber < 0 || firstNumber > (2**this.bits-1)){
            throw new RangeError(`Variable Outed in U Int256 Range : ${0} ~ ${2**this.bits-1}`)
        }else{
            this.value = eval(firstNumber+"n")
        }
    this.set = function (updateValue){
        if(typeof firstNumber == "number"){
            firstNumber = Math.round(firstNumber)
            firstNumber = eval(firstNumber+"n")
        }
        if(updateValue < 0 || updateValue > (2**this.bits-1)){
            throw new RangeError(`Variable Outed in U Int256 Range : ${0} ~ ${2**this.bits-1}`)
        }else{
            this.value = eval(updateValue+"n")
        }
    }
}
function sizeof(varname){
    switch(typeof varname){
        case "boolean":
            return 1
        case "number":
            return 64
        case "string":
            return varname.length*8
        case "function":
            return String(varname).length*8
        case "object":
            var x = 0
            for(y in varname){
                var x = x + 1
            }
            return x
        case "bigint":
            if(varname > 0n){
                var y = varname*2n
                for(var x=0;y>1;x++){
                    var y = y / 2n
                    if(y==1){
                        var x = x + 1
                    }
                }
                return x
            }else{
                var y = varname
                for(var x=0;y<=-1;x++){
                    var y = y / 2n
                }
                return x+1
            }
    }
}
function ets(str,st1=",",st2="\n"){
    if(str.substr(str.length-st2.length,st2.length)!=st2){
        var str = str + st2
    }
    var x = '["'+str.substr(0,str.search(st2))+'"]'
    var x = x.replaceAll(st1,'","')
    var x = eval(x)
    // ret = {[data:val,,,],,,}
    var y = []
    var str = str.substr(str.search(st2)+st2.length,str.length)
    for(var i=0;i<str.length;i++){
        var z = '["'+str.substr(0,str.search(st2))+'"]'
        var z = z.replaceAll(st1,'","')
        var z = eval(z)
        var str = str.substr(str.search(st2)+st2.length,str.length)
        var w = '{'
        for(j=0;j<z.length;j++){
            var w = w + '"' + x[j] + '":"' + z[j] + '",'
            if(z[j]==undefined){
                break
            }
        }
        var w = w.substr(0,w.length-st2.length)+"}"
        eval("var w = "+w)
        y.push(w)
    }
    return y
}
function Decimal(val){
    if(val >= (2**96) || val <= (0-(2**96))){
        throw new RangeError("Variable outed in range : -"+2n**96n+" ~ "+2n**96n)
    }
    if(val<=(2**52)||val>=(0-(2**52))){
        var val = Number(val).toFixed(32)
    }else{
        var val = BigInt(val)
    }
    this.value = val
    this.set = function (updateValue){
        if(updateValue >= (2**96) || updateValue <= (0-(2**96))){
            throw new RangeError("Variable outed in range : -"+2n**96n+" ~ "+2n**96n)
        }
        if(updateValue<=(2**52)||updateValue>=(0-(2**52))){
            var updateValue = Number(updateValue).toFixed(32)
        }else{
            var updateValue = BigInt(updateValue)
        }
        this.value = updateValue
    }
}
function LongDouble(val){
    if(val<=(2**52)||val>=(0-(2**52))){
        var val = Number(val).toFixed(5)
    }else{
        var val = BigInt(val)
    }
    if(val > (2n**16384n)){
        var val = Infinity
    }
    if(val < (0n-(2n**16384n))){
        var val = -Infinity
    }
    this.value = val
    this.set = function (upv){
        if(upv<=(2**52)||upv>=(0-(2**52))){
            var upv = Number(upv).toFixed(5)
        }else{
            var upv = BigInt(upv)
        }
        if(upv > (2n**16384n)){
            var upv = Infinity
        }
        if(upv < (0n-(2n**16384n))){
            var upv = -Infinity
        }
        this.value = upv
    }
}
function Double(val){
    this.value = Number(val)
    this.set = function (upv){
        this.val(Number(val))
    }
}
function Float(val){
    val = Number(val)
    if(val >= (2**128)){val = Infinity}else if(val <= (0-(2**128))){val = -Infinity}else if(val >= (2**24)||val <= (0-(2**24))){val = val.toFixed(0)}else if(val >= (2**22)||val <= (0-(2**22))){val = val.toFixed(1)}else if(val >= (2**19)||val <= (0-(2**19))){val = val.toFixed(2)}else if(val >= (2**16)||val <= (0-(2**16))){val = val.toFixed(3)}else if(val >= (2**13)||val <= (0-(2**13))){val = val.toFixed(4)}else if(val >= (2**10)||val <= (0-(2**10))){val = val.toFixed(5)}else if(val >= (2**7)||val <= (0-(2**7))){val = val.toFixed(6)}else if(val >= (2**4)||val <= (0-(2**4))){val = val.toFixed(7)}else if(val >= (2**1)||val <= (0-(2**1))){val = val.toFixed(8)}
    this.value = val
    this.set = function (val){
        val = Number(val)
        if(val >= (2**128)){val = Infinity}else if(val <= (0-(2**128))){val = -Infinity}else if(val >= (2**24)||val <= (0-(2**24))){val = val.toFixed(0)}else if(val >= (2**22)||val <= (0-(2**22))){val = val.toFixed(1)}else if(val >= (2**19)||val <= (0-(2**19))){val = val.toFixed(2)}else if(val >= (2**16)||val <= (0-(2**16))){val = val.toFixed(3)}else if(val >= (2**13)||val <= (0-(2**13))){val = val.toFixed(4)}else if(val >= (2**10)||val <= (0-(2**10))){val = val.toFixed(5)}else if(val >= (2**7)||val <= (0-(2**7))){val = val.toFixed(6)}else if(val >= (2**4)||val <= (0-(2**4))){val = val.toFixed(7)}else if(val >= (2**1)||val <= (0-(2**1))){val = val.toFixed(8)}
        this.value = val
    }
}
function count(str1,str2){
    var tekrared = 0
    for(var inloop=0;inloop<str1.length;inloop++){
        if(str1.substr(inloop,str2.length)==str2){
            var tekrared = tekrared + 1
        }
    }
    return tekrared
}
function finish(){
    confirm("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN FINISH");
}
function Toast_short(str){
    confirm("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN TOAST WITH SIZE SHORT AND STRING = "+str);
}
function Toast_long(str){
    confirm("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN TOAST WITH SIZE LONG AND STRING = "+str);
}
function Vibrate(ms){
    confirm("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN VIBRATE "+ms)
}
function PrintPDF(){
    confirm("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN PRINT THIS PAGE")
}
function showActionBar(){
    confirm("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN SHOW ACTION BAR")
}
function hideActionBar(){
    confirm("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN HIDE ACTION BAR")
}
function wifiOn(){
    confirm("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN ON WIFI")
}
function wifiOff(){
    confirm("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN OFF WIFI")
}
function sendNotification(title,text){
    confirm("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN SEND NOTIFICATION &&&01 "+title+" &&&02 "+text);
}
function customDialog(title,text,but1txt,but2txt,but3txt,cancelabe){

    // DEFAULT = EditText , TextView , Progress
    confirm("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN CUSTOM DIALOG &&&01 "+ title+" &&&02 "+text+" &&&03 "+but1txt+" &&&04 "+but2txt+" &&&05 "+but3txt+" &&&06 "+cancelabe+" &&&07 ");
}
// EditText,TextView,DatePicker,TimePicker,NumberPicker,DateTimePicker
all = window
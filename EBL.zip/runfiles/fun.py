from browser import *
def alr(g):
    alert(g)
def cnf(g):
    confirm(g)
def prp(g):
    prompt(g)
def printf(g):
    document.write(g)
def println(g):
    console.log(g)
def print_r(g):
    document.write(g)
def cat(g):
    console.log(g)
def writeHTML(g):
    document.write(g)
def col(g):
    console.log(g)
def dow(g):
    document.write(g)
def showMe(g):
    console.log(g)
def Print(g):
    console.log(g)
def PRINT(g):
    console.log(g)
def printc(g):
    console.log(g)
def puts(g):
    console.log(g)
def out(g):
    console.log(g)
def cout(g):
    console.log(g)
def echo(g):
    document.write(g)
def fie(g):
    document.write("<fieldset>"+g+"</fieldset>")
def hl(hrcolor,hrwidth,hrloop):
    if hrcolor==undefined:
        hrcolor="#000000"
    if hrwidth==undefined:
        hrcolor="100"
    if hrloop==undefined:
        hrcolor="1"
    inloop=0
    for inloop in range(hrloop):
        document.write('<hr color="'+hrcolor+'"width="'+hrwidth+'"></hr>')
def bl(loops):
    if loops==undefined:
        loops=1
    inloop = 0
    for inloop in range(loops):
        document.write("<br>")
def text(textb,style):
    document.write('<text style="'+style+'">'+textb+'</text>');
    console.log('%c'+'textb}',style);
    console.warn('%c'+textb,style);
    console.error(textb)
def a(text,href):
    document.write('<a href="'+href+'">'+'text'+'</a>')
def i(text):
    document.write("<i>"+text+"</i>")
def input(type,id,style,value,placeholder,min,max,step):
    if type != "multiLine":
        document.write('<input id="'+id}+'"type="'+type+'"style="'+style+'"placeholder="'+placeholder+'"value="'+value+'">')
        if type=="multiLine":
            document.write('<textarea id="'+id+'"style="'+style+'"placeholder="'+placeholder+'">'+value+'</textarea>')
def file(type,address,id,text):
    if type=="sel"||type=="select"||type=="change":
        document.write('<input type="file"id="'+id+'"></input>')};
    if type=="img":
        document.write('<img src="'+address+'"></img>')
    if type=="audio":
        document.write('<audio src="'+'address'+'"></audio>')
    if type=="video":
        document.write('<video src="'+address+'"></video>')
def iframe(addtype,address,id):
    if addtype==false:
        addtype = "src"
    else:
        addtype = "srcdoc"
    document.write('<iframe '+addtype+'="'+address+'"id="'+id+'"></iframe>')
def progress(id,min,max,value):
    document.write('<progress id='+id+'"min="'+min+'"max="'+max+'"value="'+value+'">')
def loop(s,e,f):
    r = s
    if e>s:
        b = true
    elif s>e:
        b = false
    if b == true:
        while e>r:
            eval(f)
            r = r + 1
    elif b == false:
        while r>e:
            exec(f)
            r = r - 1
    rt = r
    r = 0
    return rt
def sortBubble(arr):
    leng = len(arr)
    temp;
    i=0
    for i in range(leng):
        j = 0
        for j in range(leng):
            if arr[j] > arr[j+1]):
                temp = arr[j]
                arr[j] = arr[j+1]
                arr[j+1] = temp
    return arr;
def hypow1(a,b):
    c = a
    d = 1
    for d in range(b):
        c = c ** a
    return c
def finish():
    prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN FINISH");
def Toast(str):
    prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN TOAST WITH SIZE AND STRING = ",str);
def Vibrate(ms):
    prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN VIBRATE ",ms)
def PrintPDF():
    prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN PRINT THIS PAGE")
def wifiOn():
    prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN ON WIFI")
def wifiOff():
    prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN OFF WIFI")

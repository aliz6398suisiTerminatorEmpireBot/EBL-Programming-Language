
var fmt = {"print":function (g){console.log(g)},"PrintLn":function (g){console.log(g)},"Print":function (g){console.log(g)}};var System = {"out":{"print":function (g){console.log(g)},"println":function (g){console.log(g)}}};var lcd = {"print":function (g){console.log(g)}};var alr = function (g){h = alert(g)};var cnf = function (g){confirm(g)};var prp = function prp(g,i){prompt(g,i)};var printf = function (g){document.write(g)};var println = function (g){console.log(g)};function getFullObject(value){var ret = "";for(var i in value){ret = ret + `${i} : ${value[i]} , `};return ret};function getFullArray(value){var ret="";for(i of value){ret = ret + `${i} , `};return ret};var print_r = function (value){document.write(value)};var cat = function(value){console.log(cat)};var writeHTML = function (value){documentw.rite(value)};var col = function (val){console.log(val)};var dow = function (val){console.log(val)};var cat = function (val){console.log(val)};var showMe = function (val){console.log(val)};function rand(i,a){return Math.random()*(a-i)+i};function Print(val){console.log(val+"\n")};function PRINT(val){console.log(val+"\n")};function ctArray(a,b){return Array(a+","+b)};function nicePrint(val){document.write(val+"\n")};function echo(val){document.write(val+"\n")};function cout(val){console.log(val+"\n")};var Printer = {"printIn":function printIn(g){console.log(g)}};var BS = {"WL":function WL(g){console.log(g)}};
function printc(val){console.log(val+"\n")};
function puts(val){console.log(val+"\n")};
function out(val){console.log(val+"\n")};
console["Write"] = console.log
console["WriteLine"] = console.log
console["Read"] = prompt
console["ReadLine"] = prompt

class str extends String{
    value = this
    typeof = "String"
    len = this.length
    sizeof = this.length * 8
    s = function (s=0,e=this.length){
        return this.substr(s,e)
    }
    substring = function (s=0,e=this.length){
        return this.slice(s,e)
    }
    subString = function (s=0,e=this.length){
        return this.slice(s,e)
    }
    splice = function (s=0,e=this.length){
        return this.substr(s,e)
    }
    count = function(str2){
        var str1 = this
        var tekrared = 0
        for(var inloop=0;inloop<str1.length;inloop++){
            if(str1.substr(inloop,str2.length)==str2){
                tekrared = tekrared + 1
            }
        }
        return tekrared
    }
    reserved = function(){
        var textb = ""
        for(var i=this.length;i>=0;i--){
            textb = textb + this.charAt(i)
        }
        return textb
    }
    negative = function(){
        var textb = ""
        for(var i=this.length;i>=0;i--){
            textb = textb + this.charAt(i)
        }
        return textb
    }
    contains=function(search){
        return this.search(search) == -1?false:true
    }
    found=function(search){
        return this.indexOf(search) == -1?false:true
    }
    find= function(ser){
        return this[ser]
    }
    isUpper=function(){
        let text=this
        for(var i=0;i<text.length;i++){
            if(text.charAt(i)!="A"&&text.charAt(i)!="B"&&text.charAt(i)!="C"&&text.charAt(i)!="D"&&text.charAt(i)!="E"&&text.charAt(i)!="F"&&text.charAt(i)!="G"&&text.charAt(i)!="H"&&text.charAt(i)!="I"&&text.charAt(i)!="J"&&text.charAt(i)!="K"&&text.charAt(i)!="L"&&text.charAt(i)!="M"&&text.charAt(i)!="N"&&text.charAt(i)!="O"&&text.charAt(i)!="P"&&text.charAt(i)!="Q"&&text.charAt(i)!="R"&&text.charAt(i)!="Q"&&text.charAt(i)!="T"&&text.charAt(i)!="U"&&text.charAt(i)!="V"&&text.charAt(i)!="W"&&text.charAt(i)!="X"&&text.charAt(i)!="Y"&&text.charAt(i)!="Z"){
                return false
            }
        }
        return true
    }
    isLower=function(){
        let text=this
        for(var i=0;i<text.length;i++){
            if(text.charAt(i)!="a"&&text.charAt(i)!="b"&&text.charAt(i)!="c"&&text.charAt(i)!="d"&&text.charAt(i)!="e"&&text.charAt(i)!="f"&&text.charAt(i)!="g"&&text.charAt(i)!="h"&&text.charAt(i)!="i"&&text.charAt(i)!="j"&&text.charAt(i)!="k"&&text.charAt(i)!="l"&&text.charAt(i)!="m"&&text.charAt(i)!="n"&&text.charAt(i)!="o"&&text.charAt(i)!="p"&&text.charAt(i)!="q"&&text.charAt(i)!="r"&&text.charAt(i)!="s"&&text.charAt(i)!="t"&&text.charAt(i)!="u"&&text.charAt(i)!="v"&&text.charAt(i)!="w"&&text.charAt(i)!="x"&&text.charAt(i)!="y"&&text.charAt(i)!="z"){
                return false
            }
        }
        return true
     }
     isDigit=function(){
        let text=this
        for(var i=0;i<text.length;i++){
            if(text.charAt(i)!="0"&&text.charAt(i)!="1"&&text.charAt(i)!="2"&&text.charAt(i)!="3"&&text.charAt(i)!="4"&&text.charAt(i)!="5"&&text.charAt(i)!="6"&&text.charAt(i)!="7"&&text.charAt(i)!="8"&&text.charAt(i)!="9"){
               return false
            }
        }
        return true
    }
    isNumber=function(){
        let text=this
        for(var i=0;i<text.length;i++){
           if(text.charAt(i)!="0"&&text.charAt(i)!="1"&&text.charAt(i)!="2"&&text.charAt(i)!="3"&&text.charAt(i)!="4"&&text.charAt(i)!="5"&&text.charAt(i)!="6"&&text.charAt(i)!="7"&&text.charAt(i)!="8"&&text.charAt(i)!="9"&&text.charAt(i)!="."){
                return false
            }
        }
        return true
    }
    isSpace=function(){
        let text=this
        for(var i=0;i<text.length;i++){
            if(text.charAt(i)!=" "){
                return false
            }
        }
        return true
    }
    IsUpper=function(){
        let text=this
        for(var i=0;i<text.length;i++){
            if(text.charAt(i)!="A"&&text.charAt(i)!="B"&&text.charAt(i)!="C"&&text.charAt(i)!="D"&&text.charAt(i)!="E"&&text.charAt(i)!="F"&&text.charAt(i)!="G"&&text.charAt(i)!="H"&&text.charAt(i)!="I"&&text.charAt(i)!="J"&&text.charAt(i)!="K"&&text.charAt(i)!="L"&&text.charAt(i)!="M"&&text.charAt(i)!="N"&&text.charAt(i)!="O"&&text.charAt(i)!="P"&&text.charAt(i)!="Q"&&text.charAt(i)!="R"&&text.charAt(i)!="Q"&&text.charAt(i)!="T"&&text.charAt(i)!="U"&&text.charAt(i)!="V"&&text.charAt(i)!="W"&&text.charAt(i)!="X"&&text.charAt(i)!="Y"&&text.charAt(i)!="Z"){
                return false
            }
        }
        return true
    }
    IsLower=function(){
        let text=this
        for(var i=0;i<text.length;i++){
            if(text.charAt(i)!="a"&&text.charAt(i)!="b"&&text.charAt(i)!="c"&&text.charAt(i)!="d"&&text.charAt(i)!="e"&&text.charAt(i)!="f"&&text.charAt(i)!="g"&&text.charAt(i)!="h"&&text.charAt(i)!="i"&&text.charAt(i)!="j"&&text.charAt(i)!="k"&&text.charAt(i)!="l"&&text.charAt(i)!="m"&&text.charAt(i)!="n"&&text.charAt(i)!="o"&&text.charAt(i)!="p"&&text.charAt(i)!="q"&&text.charAt(i)!="r"&&text.charAt(i)!="s"&&text.charAt(i)!="t"&&text.charAt(i)!="u"&&text.charAt(i)!="v"&&text.charAt(i)!="w"&&text.charAt(i)!="x"&&text.charAt(i)!="y"&&text.charAt(i)!="z"){
                return false
            }
        }
        return true
     }
     IsDigit=function(){
        let text=this
        for(var i=0;i<text.length;i++){
            if(text.charAt(i)!="0"&&text.charAt(i)!="1"&&text.charAt(i)!="2"&&text.charAt(i)!="3"&&text.charAt(i)!="4"&&text.charAt(i)!="5"&&text.charAt(i)!="6"&&text.charAt(i)!="7"&&text.charAt(i)!="8"&&text.charAt(i)!="9"){
               return false
            }
        }
        return true
    }
    IsNumber=function(){
        let text=this
        for(var i=0;i<text.length;i++){
           if(text.charAt(i)!="0"&&text.charAt(i)!="1"&&text.charAt(i)!="2"&&text.charAt(i)!="3"&&text.charAt(i)!="4"&&text.charAt(i)!="5"&&text.charAt(i)!="6"&&text.charAt(i)!="7"&&text.charAt(i)!="8"&&text.charAt(i)!="9"&&text.charAt(i)!="."){
                return false
            }
        }
        return true
    }
    IsSpace=function(){
        let text=this
        for(var i=0;i<text.length;i++){
            if(text.charAt(i)!=" "){
                return false
            }
        }
        return true
    }
    compareTo=function(str2){
        let str1 = this
        if(str1==str2){
            return true
        }
        var text = 0
        var co = str1.length>str2.length ? str1.length : str2.length
        for(var i=0;i<co;i++){
           if(str1.charCodeAt(i)==str2.charCodeAt(i)){
                text += 1
            }
        }
        return text;
     }
     CompareTo=function(str2){
        let str1 = this
        if(str1==str2){
            return true
        }
        var text = 0
        var co = str1.length>str2.length ? str1.length : str2.length
        for(var i=0;i<co;i++){
           if(str1.charCodeAt(i)==str2.charCodeAt(i)){
                text += 1
            }
        }
        return text;
     }
     removeStr=function(dis=" "){
         return this.replaceAll(dis,"");
     };
     trim=function(dis=" "){
         return this.replaceAll(dis,"");
     };
     last=function(){
         return this.substr(this.length-1,1);
     };
     first=function(){
         return this.substr(0,1);
     };
     plus=function(str2){
         return this + str2;
     };
     atob=function(){
         return atob(this)
     }
     btoa=function(){
         return btoa(this)
     }
     binary=function(){
         var bit = ""
         for(var i=0;i<this.length;i++){
            bit = bit + this.charCodeAt(i).toString(2).padStart(8,0)
         }
         return bit
     }
    bit=function(){
         var bit = ""
         for(var i=0;i<this.length;i++){
            bit = bit + this.charCodeAt(i).toString(2).padStart(8,0)
         }
         return bit
     }
     hexadecmial=function(){
         var bit = ""
         for(var i=0;i<this.length;i++){
            bit = bit + this.charCodeAt(i).toString(16).padStart(2,0)
         }
         return bit
     }
     hex=function(){
         var bit = ""
         for(var i=0;i<this.length;i++){
            bit = bit + this.charCodeAt(i).toString(16).padStart(2,0)
         }
         return bit
     }
     codeInt=function(){
         let str = this
         let result = 0n
         let y = BigInt(str.length)
         y--
         for(x=0n;x<str.length;x++){
             result = result + (BigInt(str.charCodeAt(Number(y)))*(256n**x))
             y -= 1n
         }
         return result
     }
     num=function(){
         let input = this
         var bit = ""
         for(var i=0;i<input.length;i++){
             bit = bit + input.charCodeAt(i).toString(10).padStart(3,0)
         }
         return bit
     }
     Binary=function(){
         var bit = ""
         for(var i=0;i<this.length;i++){
            bit = bit + this.charCodeAt(i).toString(2).padStart(8,0)
         }
         return bit
     }
    Bit=function(){
         var bit = ""
         for(var i=0;i<this.length;i++){
            bit = bit + this.charCodeAt(i).toString(2).padStart(8,0)
         }
         return bit
     }
     Hexadecmial=function(){
         var bit = ""
         for(var i=0;i<this.length;i++){
            bit = bit + this.charCodeAt(i).toString(16).padStart(2,0)
         }
         return bit
     }
     Hex=function(){
         var bit = ""
         for(var i=0;i<this.length;i++){
            bit = bit + this.charCodeAt(i).toString(16).padStart(2,0)
         }
         return bit
     }
     CodeInt=function(){
         let str = this
         let result = 0n
         let y = BigInt(str.length)
         y--
         for(x=0n;x<str.length;x++){
             result = result + (BigInt(str.charCodeAt(Number(y)))*(256n**x))
             y -= 1n
         }
         return result
     }
     Num=function(){
         let input = this
         var bit = ""
         for(var i=0;i<input.length;i++){
             bit = bit + input.charCodeAt(i).toString(10).padStart(3,0)
         }
         return bit
     }
     upper=function(){
         return this.toUpperCase()
     }
     toUpper=function(){
         return this.toUpperCase()
     }
     upperCase=function(){
         return this.toUpperCase()
     }
     lower=function(){
         return this.toLowerCase()
     }
     toLower=function(){
         return this.toLowerCase()
     }
     lowerCase=function(){
         return this.toLowerCase()
     }
     TrimStart=function(){
         return this.trimStart()
     }
     LrimLeft=function(){
         return this.trimLeft()
     }
     TrimRight=function(){
         return this.trimRight()
     }
     TrimEnd=function(){
        return this.trimEnd()
     }
     Upper=function(){
        return this.toUpperCase()
     }
     ToUpper=function(){
         return this.toUpperCase()
     }
     UpperCase=function(){
         return this.toUpperCase()
     }
     ToUpperCase=function(){
         return this.toUpperCase()
     }
     Lower=function(){
         return this.toLowerCase()
     }
     ToLower=function(){
         return this.toLowerCase()
     }
     LowerCase=function(){
         return this.toLowerCase()
     }
     ToLowerCase=function(){
         return this.toLowerCase()
     }
     Contains=function(search){
         return this.search(search) == -1?false:true
     }
     Found=function(search){
         return this.indexOf(search) == -1?false:true
     }
     Search=function(ser){
         return this.search(ser)
     }
     IndexOf=function(ser){
         return this.indexOf(ser)
     }
     Find= function(ser){
         return this[ser]
     }
     RemoveStr=function(dis=" "){
         return this.replaceAll(dis,"");
     };
     Trim=function(dis=" "){
         return this.replaceAll(dis,"");
     };
     Last=function(){
         return this.substr(this.length-1,1);
     };
     First=function(){
         return this.substr(0,1);
     };
     Plus=function(str2){
         return this + str2;
     };
     Atob=function(){
         return atob(this)
     }
     Btoa=function(){
         return btoa(value)
     }
     PadStart = this.padStart
     PadEnd = this.padEnd
     PadLeft = this.padStart
     PadRight = this.padEnd
     Length = this.length
     Repeat = this.repeat
     Replace = this.replace
     ReplaceAll = this.replaceAll
}
class arr extends Array{
    typeof="Array"
    value = this
    len = this.length
    Length = this.length
    negative = this.reserve
    sub = function(s=0,e=this.length){
        return this.slice(s,e)
    }
    s=function(s=0,e=this.length){
        return this.splice(s,e)
    }
    sortBubble=function(){
        let arr=this
        var len = arr.length
        var temp;
        for(var i=0;i<len;i++){
            for(var j=0;j<len;j++){
                if(arr[j] > arr[j+1]){
                    temp = arr[j]
                    arr[j] = arr[j+1]
                    arr[j+1] = temp
                 }
             }
         }
         return arr;
    }
}
class num extends Number{
    value = this
    typeof="Number"
    strCode=function(){
        let inr=this
        let result = ""
        let y = BigInt(inr)
        let z = 0
        for(let i=0;y>1;i++){
            z = y % 256n
            result += String.fromCharCode(Number(z))
            y -= y % 256n
            y /= 256n
        }
        let resb = ""
        for(let wo=result.length-1;wo>=0;wo--){
            resb+=result[wo]
        }
        result = resb
        return result
    }
}
class int extends BigInt{
    value = this
    typeof="Number"
    strCode=function(){
        let inr=this
        let result = ""
        let y = BigInt(inr)
        let z = 0
        for(let i=0;y>1;i++){
            z = y % 256n
            result += String.fromCharCode(Number(z))
            y -= y % 256n
            y /= 256n
        }
        let resb = ""
        for(let wo=result.length-1;wo>=0;wo--){
            resb+=result[wo]
        }
        result = resb
        return result
    }
}
class obj extends Object{
    typeof = "Object"
    value = this
}

function bluetoothOn(){
    prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND ENABLE BLUETOOTH")
}
function bluetoothOff(){
    prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND DISABLE BLUETOOTH")
}
var crvar = (name,val,nums) => {
    var running = 0
    while(running < nums){
        var h = name + running + " = " + val
        eval(h)
        running = running + 1
    }
}
function dota(ad1,ad2){
    var xxx1 = ad1
    for(var xxx2=0;xxx2<ad2;xxx2++){
        xxx1 = xxx1 / ad1
    }
    return xxx1
}
var eblStringHasher1 = {
    "hide":function (i){
        var a = btoa(i);
        var b = ""
        for(var c=0;c<a.length;c++){
            b = b + (Math.round(Math.random()*36)).toString(36) + a.charAt(c)
        }
        return b
    },
    "show":function hideBawfln(i){
        var a = ""
        var c = i
        for(var b=0;b<i.length;b++){
            if(b % 2 == 0){
                
            }else{
                a = a + c.charAt(b)
            }
        }
        return atob(a)
    }

}
function bit_str(input){
    var string = ""
    var str = ""
    for(i=0;i<input.length;i++){
        str = str + input.charAt(i)
        if(str.length==8){
            n = 0;
            bchn = parseInt(str);
            for (let j = 0; j<str.length; j++){
                n = n + (bchn%10)*(Math.pow(2, j) | 0);
                bchn = ((bchn/10) | 0);
            }
            string = string + String.fromCharCode(n);
            var n = 0;
            var str = ""
        }
    }
    return string
}
function hex_str(input){
    var string = ""
    var str = ""
    for(i=0;i<input.length;i++){
        str = str + input.charAt(i)
        if(str.length==2){
            n = 0;
            bchn = parseInt(str);
            for (let j = 0; j<str.length; j++){
                n = n + (bchn%10)*(Math.pow(16, j) | 0);
                bchn = ((bchn/10) | 0);
            }
            string = string + String.fromCharCode(n);
            var n = 0;
            var str = ""
        }
    }
    return string
}
function num_str(input){
    var string = ""
    var str = ""
    for(i=0;i<input.length;i++){
        str = str + input.charAt(i)
        if(str.length==3){
            n = 0;
            bchn = parseInt(str);
            for (let j = 0; j<str.length; j++){
                n = n + (bchn%10)*(Math.pow(10, j) | 0);
                bchn = ((bchn/10) | 0);
            }
            string = string + String.fromCharCode(n);
            var n = 0;
            var str = ""
        }
    }
    return string
}
function more_str(mobno,input){
    var x = (255).toString(mobno).length
    var string = ""
    var str = ""
    for(i=0;i<input.length;i++){
        str = str + input.charAt(i)
        if(str.length==x){
            n = 0;
            bchn = parseInt(str);
            for (let j = 0; j<str.length; j++){
                n = n + (bchn%10)*(Math.pow(mobno, j) | 0);
                bchn = ((bchn/10) | 0);
            }
            string = string + String.fromCharCode(n);
            var n = 0;
            var str = ""
        }
    }
    return string
}
function bit_num(input){
    var string = ""
    var str = ""
    for(i=0;i<input.length;i++){
        str = str + eval(input.charAt(i))
        if(str.length==input.length){
            n = 0;
            bchn = parseInt(str);
            for (let j = 0; j<str.length; j++){
                n = n + (bchn%10)*(Math.pow(2, j) | 0);
                bchn = ((bchn/10) | 0);
            }
            string = string + n;
            var n = 0;
            var str = ""
        }
    }
    return string
}
function num_bit(input){
    return input.toString(2)
}
function hex_num(input){
    eval(`var myhex = 0x${data}`)
    return myhex
}
function num_hex(input){
    return input.toString(16)
}
function more_num(mobno,input){
    var string = ""
    var str = ""
    for(i=0;i<input.length;i++){
        str = str + eval(input.charAt(i))
        if(str.length==input.length){
            n = 0;
            bchn = parseInt(str);
            for (let j = 0; j<str.length; j++){
                n = n + (bchn%10)*(Math.pow(mobno, j) | 0);
                bchn = ((bchn/10) | 0);
            }
            string = string + n;
            var n = 0;
            var str = ""
        }
    }
    return string
}
function num_more(mobno,input){
    return input.toString(mobno)
}
function bit_hex(input){
    var string = ""
    var str = ""
    for(i=0;i<input.length;i++){
        str = str + eval(input.charAt(i))
        if(str.length==4){
            n = 0;
            bchn = parseInt(str);
            for (let j = 0; j<str.length; j++){
                n = n + (bchn%10)*(Math.pow(2, j) | 0);
                bchn = ((bchn/10) | 0);
            }
            string = string + n.toString(16);
            var n = 0;
            var str = ""
        }
    }
    return string
}
function hex_bit(input){
    eval(`var myhex = 0x${input}`)
    return myhex.toString(2)
}
function hex_more(mobno,data){
    eval(`var myhex = 0x${data}`)
    return myhex.toString(mobno)
}
function ets(str,st1=",",st2="\n"){
    if(str.substr(str.length-st2.length,st2.length)!=st2){
        var str = str + st2
    }
    var x = '["'+str.substr(0,str.search(st2))+'"]'
    var x = x.replaceAll(st1,'","')
    var x = eval(x)
    // ret = {[data:val,,,],,,}
    var y = []
    var str = str.substr(str.search(st2)+st2.length,str.length)
    for(var i=0;i<str.length;i++){
        var z = '["'+str.substr(0,str.search(st2))+'"]'
        var z = z.replaceAll(st1,'","')
        var z = eval(z)
        var str = str.substr(str.search(st2)+st2.length,str.length)
        var w = '{'
        for(j=0;j<z.length;j++){
            var w = w + '"' + x[j] + '":"' + z[j] + '",'
            if(z[j]==undefined){
                break
            }
        }
        var w = w.substr(0,w.length-st2.length)+"}"
        eval("var w = "+w)
        y.push(w)
    }
    return y
}
function finish(){
    prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN FINISH");
}
function Toast(str){
    prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN TOAST WITH SIZE AND STRING = ",str);
}
function Vibrate(ms){
    prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN VIBRATE ",ms)
}
function PrintPDF(){
    prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN PRINT THIS PAGE")
}
function wifiOn(){
    prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN ON WIFI")
}
function wifiOff(){
    prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN OFF WIFI")
}
function translateEblToJs(str){
    str = str.replaceAll("<>","!=")
    str = str.replaceAll(":\n    ","\n    ")
    str = str.replaceAll("in range(","in range((")
    str = str.replaceAll("val ","const ")
    str = str.replaceAll("static ","const ")
    str = str.replaceAll("local ","let ")
    str = str.replaceAll("private ","let ")
    str = str.replaceAll("public ","")
    str = str.replaceAll("global ","")
    str = str.replaceAll("__init__","constructor")
    str = str.replaceAll("onCreate","constructor")
    str = str.replaceAll("self","this")
    str = str.replaceAll("《","/"+"*COMMENT<!--")
    str = str.replaceAll("》","-->*"+"/")
    str = str.replaceAll("&t32;","                                                                                                                                ")
    str = str.replaceAll("&t31;","                                                                                                                            ")
    str = str.replaceAll("&t30;","                                                                                                                        ")
    str = str.replaceAll("&t30;","                                                                                                                        ")
    str = str.replaceAll("&t29;","                                                                                                                    ")
    str = str.replaceAll("&t28;","                                                                                                                ")
    str = str.replaceAll("&t27;","                                                                                                            ")
    str = str.replaceAll("&t26;","                                                                                                         ")
    str = str.replaceAll("&t25;","                                                                                                    ")
    str = str.replaceAll("&t24;","                                                                                                 ")
    str = str.replaceAll("&t23;","                                                                                            ")
    str = str.replaceAll("&t22;","                                                                                        ")
    str = str.replaceAll("&t21;","                                                                                    ")
    str = str.replaceAll("&t20;","                                                                                ")
    str = str.replaceAll("&t19;","                                                                            ")
    str = str.replaceAll("&t18;","                                                                        ")
    str = str.replaceAll("&t18;","                                                                    ")
    str = str.replaceAll("&t17;","                                                                    ")
    str = str.replaceAll("&t16;","                                                                ")
    str = str.replaceAll("&t15;","                                                            ")
    str = str.replaceAll("&t14;","                                                        ")
    str = str.replaceAll("&t13;","                                                    ")
    str = str.replaceAll("&t12;","                                                ")
    str = str.replaceAll("&t11;","                                            ")
    str = str.replaceAll("&t10;","                                         ")
    str = str.replaceAll("&t9;","                                     ")
    str = str.replaceAll("&t8;","                                ")
    str = str.replaceAll("&t7;","                            ")
    str = str.replaceAll("&t6;","                        ")
    str = str.replaceAll("&t5;","                    ")
    str = str.replaceAll("&t4;","                ")
    str = str.replaceAll("&t3;","            ")
    str = str.replaceAll("&t2;","        ")
    let unkstr = ""
    let result = ""
    
    for(let i=0;i<str.length;i++){
        if(str.substr(i,6)=="print "){
            let printstr = ""
            for(i=i+6;i<str.length;i++){
                if(str.substr(i,1)=="\n") break
                printstr += str.substr(i,1)
            }
            result += 'document.getElementById("eblhaa").innerHTML+='+printstr+';\n'
            unkstr = ""
            printstr = ""
            printstr2 = ""
        }if(str.substr(i,4)=="out "){
            let printstr = ""
            for(i=i+4;i<str.length;i++){
                if(str.substr(i,1)=="\n") break
                printstr += str.substr(i,1)
            }
            result += 'document.getElementById("eblhaa").innerHTML+='+printstr+';\n'
            unkstr = ""
            printstr = ""
            printstr2 = ""
        }else if(str.substr(i,5)=="puts "){
            let printstr = ""
            for(i=i+5;i<str.length;i++){
                if(str.substr(i,1)=="\n") break
                printstr += str.substr(i,1)
            }
            result += 'document.getElementById("eblhaa").innerHTML+='+printstr+';\n'
            unkstr = ""
            printstr = ""
            printstr2 = ""
        }else if(str.substr(i,5)=="echo "){
            let printstr = ""
            for(i=i+5;i<str.length;i++){
                if(str.substr(i,1)=="\n") break
                printstr += str.substr(i,1)
            }
            result += 'document.getElementById("eblhaa").innerHTML+='+printstr+';\n'
            unkstr = ""
            printstr = ""
            printstr2 = ""
        }else if(str.substr(i,5)=="cout "){
            let printstr = ""
            for(i=i+5;i<str.length;i++){
                if(str.substr(i,1)=="\n") break
                printstr += str.substr(i,1)
            }
            result += 'document.getElementById("eblhaa").innerHTML+='+printstr+';\n'
            unkstr = ""
            printstr = ""
            printstr2 = ""
        }else if(str.substr(i,12)=="console.log "){
            let printstr = ""
            for(i=i+12;i<str.length;i++){
                if(str.substr(i,1)=="\n") break
                printstr += str.substr(i,1)
            }
            result += 'console.log('+printstr+');\n'
            unkstr = ""
            printstr = ""
            printstr2 = ""
        }else if(str.substr(i,1)=="("){
            if(unkstr.startsWith("def ")){
                unkstr = unkstr.substr(4,unkstr.length)
            }
            let printstr = ""
            for(i=i+1;i<str.length;i++){
                if(str.substr(i,1)=="\n") break
                printstr += str.substr(i,1)
            }
            if(str.substr(i,5)=="\n    "){
                for(i=i;i<str.length;i++){
                    if(str.substr(i,1)=="\n"&&str.substr(i,5)!="\n    ") break
                    printstr2 += str.substr(i,1)
                }
                printstr2 = printstr2.replaceAll("\n    ","\n")
                printstr2 = translateEblToJs(printstr2)
                printstr = printstr+"{\n"+printstr2+"\n}"
                unkstr = unkstr.substr(0,unkstr.length)
                
                unkstr = "\nfunction "+unkstr
            }
            result += unkstr+'('+printstr+';\n\n'
            unkstr = ""
            printstr = ""
            printstr2 = ""
        }else if(str.substr(i,6)=="input "){
            let printstr = ""
            for(i=i+6;i<str.length;i++){
                if(str.substr(i,1)=="\n") break
                printstr += str.substr(i,1)
            }
            result += printstr+"=prompt();\n"
            unkstr = ""
            printstr = ""
            printstr2 = ""
        }else if(str.substr(i,3)=="in "){
            let printstr = ""
            for(i=i+3;i<str.length;i++){
                if(str.substr(i,1)=="\n") break
                printstr += str.substr(i,1)
            }
            result += printstr+"=prompt();\n"
            unkstr = ""
            printstr = ""
            printstr2 = ""
        }else if(str.substr(i,4)=="cin "){
            let printstr = ""
            for(i=i+4;i<str.length;i++){
                if(str.substr(i,1)=="\n") break
                printstr += str.substr(i,1)
            }
            result += printstr+"=prompt();\n"
            unkstr = ""
            printstr = ""
            printstr2 = ""
        }else if(str.substr(i,1)=="="){
            let printstr = ""
            for(i=i+1;i<str.length;i++){
                if(str.substr(i,1)=="\n") break
                printstr += str.substr(i,1)
            }
            if(printstr.trim().startsWith("(")){
                printstr2 = ""
                for(i=i;i<str.length;i++){
                    if(str.substr(i,1)=="\n"&&str.substr(i,5)!="\n    ") break
                    printstr2 += str.substr(i,1)
                }
                printstr2 = printstr2.replaceAll("\n    ","\n")
                
                printstr = "function "+printstr+"{\n"+translateEblToJs(printstr2)+"\n}\n"
            }
            if(unkstr.search(":")!=-1){
                let unkstr2 = unkstr
                let variabletypes = unkstr.substr(unkstr.indexOf(":")+1,unkstr.length)
                let variabletypes2 = variabletypes
                unkstr = unkstr2
                unkstr = unkstr.substr(0,unkstr.indexOf(":"))
                variabletypes2=variabletypes2.replaceAll(" ","_")
                while(variabletypes2.endsWith("_")){
                    variabletypes2 = variabletypes2.substr(0,variabletypes2.length-1)
                }
                while(printstr.startsWith(" ")){
                    printstr = printstr.substr(1,printstr.length)
                }
                printstr = "new "+variabletypes2+"("+printstr+")"
            }
            if(unkstr.startsWith("0")||unkstr.startsWith("1")||unkstr.startsWith("2")||unkstr.startsWith("3")||unkstr.startsWith("4")||unkstr.startsWith("5")||unkstr.startsWith("6")||unkstr.startsWith("7")||unkstr.startsWith("8")||unkstr.startsWith("9")){
                arrrmode = false
                if(unkstr.endsWith("[]")){
                    unkstr = unkstr.substr(0,unkstr.length-2)
                    arrrmode = true
                }
                unkstr2 = unkstr
                unkstr3 = unkstr.substr(0,unkstr.indexOf(" "))
                unkstr = unkstr2.substr(unkstr2.indexOf(" ")+1,unkstr2.length)
                unkstr2 = unkstr
                if(unkstr.startsWith("const")){
                    unkstr4 = unkstr.substr(6,unkstr.length)+"time"
                }else if(unkstr.startsWith("var")){
                    unkstr4 = unkstr.substr(4,unkstr.length)+"time"
                }else if(unkstr.startsWith("let")){
                    unkstr4 = unkstr.substr(4,unkstr.length)+"time"
                }else{
                    unkstr4 = unkstr+"time"
                }
                unkstr4 = unkstr4.replaceAll(" ","_")
                //for unkstr+"time"=0;unkti<unkstr3;unkti++
                if(arrrmode){
                    result += "\nfor("+unkstr4+"=0;"+unkstr4+"<"+unkstr3+";"+unkstr4+"++){\neval('"+unkstr2+"['+"+unkstr4+"+']="+printstr+"')\n}\n"
                }else{
                    result += "\nfor("+unkstr4+"=0;"+unkstr4+"<"+unkstr3+";"+unkstr4+"++){\neval('"+unkstr2+"'+"+unkstr4+"+'="+printstr+"')\n}\n"
                }
                
            }else{
                result += unkstr+"="+(printstr)+';\n'
            }
            unkstr=""
            printstr = ""
            printstr2 = ""
        }else if(str.substr(i,3)=="if "){
            let printstr = ""
            for(i=i+3;i<str.length;i++){
                if(str.substr(i,1)=="\n") break
                printstr += str.substr(i,1)
            }
            let printstr2 = ""
            for(i=i;i<str.length;i++){
                if(str.substr(i,1)=="\n"&&str.substr(i,5)!="\n    ") break
                printstr2 += str.substr(i,1)
            }
            printstr2 = printstr2.replaceAll("\n    ","\n")
            printstr2 = translateEblToJs(printstr2)
            result += "if("+printstr+'){\n'+printstr2+"\n}"
            unkstr=""
            printstr = ""
            printstr2 = ""
        }else if(str.substr(i,3)=="do "){
            let printstr = ""
            for(i=i+3;i<str.length;i++){
                if(str.substr(i,1)=="\n") break
                printstr += str.substr(i,1)
            }
            let printstr2 = ""
            for(i=i;i<str.length;i++){
                if(str.substr(i,1)=="\n"&&str.substr(i,5)!="\n    ") break
                printstr2 += str.substr(i,1)
            }
            printstr2 = printstr2.replaceAll("\n    ","\n")
            printstr2 = translateEblToJs(printstr2)
            result += "\ndo{\n"+printstr2+"\n}while("+printstr+");\n"
            unkstr=""
            printstr = ""
            printstr2 = ""
        }else if(str.substr(i,6)=="while "){
            let printstr = ""
            for(i=i+6;i<str.length;i++){
                if(str.substr(i,1)=="\n") break
                printstr += str.substr(i,1)
            }
            let printstr2 = ""
            for(i=i;i<str.length;i++){
                if(str.substr(i,1)=="\n"&&str.substr(i,5)!="\n    ") break
                printstr2 += str.substr(i,1)
            }
            printstr2 = printstr2.replaceAll("\n    ","\n")
            printstr2 = translateEblToJs(printstr2)
            result += "\nwhile("+printstr+"){\n"+printstr2+"\n}\n"
            unkstr=""
            printstr = ""
            printstr2 = ""
        }else if(str.substr(i,7)=="switch "){
            let printstr = ""
            for(i=i+7;i<str.length;i++){
                if(str.substr(i,1)=="\n") break
                printstr += str.substr(i,1)
            }
            let printstr2 = ""
            for(i=i;i<str.length;i++){
                if(str.substr(i,1)=="\n"&&str.substr(i,5)!="\n    ") break
                printstr2 += str.substr(i,1)
            }
            printstr2 = printstr2.replaceAll("\n    ","\n")
            printstr2 = translateEblToJs(printstr2)
            result += "\nswitch("+printstr+'){\n'+printstr2+"\n};\n"
            unkstr=""
            printstr = ""
            printstr2 = ""
        }else if(str.substr(i,5)=="else\n"){
            let printstr = ""
            let printstr2 = ""
            for(i=i;i<str.length;i++){
                if(str.substr(i,1)=="\n"&&str.substr(i,5)!="\n    ") break
                printstr2 += str.substr(i,1)
            }
            printstr2 = printstr2.replaceAll("\n    ","\n")
            printstr2 = printstr2.substr(5,printstr2.length-5)
            printstr2 = translateEblToJs(printstr2)
            result += 'else{\n'+printstr2+'\n}'
            unkstr=""
            printstr = ""
            printstr2 = ""
        }else if(str.substr(i,3)=="el\n"){
            let printstr = ""
            let printstr2 = ""
            for(i=i;i<str.length;i++){
                if(str.substr(i,1)=="\n"&&str.substr(i,5)!="\n    ") break
                printstr2 += str.substr(i,1)
            }
            printstr2 = printstr2.replaceAll("\n    ","\n")
            printstr2 = printstr2.substr(3,printstr2.length-3)
            printstr2 = translateEblToJs(printstr2)
            result += 'else{\n'+printstr2+'\n}'
            unkstr=""
            printstr = ""
            printstr2 = ""
        }else if(str.substr(i,5)=="case "){
            let printstr = ""
            for(i=i+5;i<str.length;i++){
                if(str.substr(i,1)=="\n") break
                printstr += str.substr(i,1)
            }
            let printstr2 = ""
            for(i=i;i<str.length;i++){
                if(str.substr(i,1)=="\n"&&str.substr(i,5)!="\n    ") break
                printstr2 += str.substr(i,1)
            }
            printstr2 = translateEblToJs(printstr2)
            result += "case "+printstr+':\n    '+printstr2+"\n    break\n"
            unkstr=""
            printstr = ""
            printstr2 = ""
        }else if(str.substr(i,8)=="default\n"){
            let printstr = ""
            for(i=i+8;i<str.length;i++){
                if(str.substr(i,1)=="\n") break
                printstr += str.substr(i,1)
            }
            let printstr2 = ""
            for(i=i;i<str.length;i++){
                if(str.substr(i,1)=="\n"&&str.substr(i,5)!="\n    ") break
                printstr2 += str.substr(i,1)
            }
            printstr2 = translateEblToJs(printstr2)
            result += "default:"+'\n    '+printstr2+"\n    break\n"
            unkstr=""
            printstr = ""
            printstr2 = ""
        }else if(str.substr(i,4)=="for "){
            let printstr = ""
            for(i=i+4;i<str.length;i++){
                if(str.substr(i,1)=="\n") break
                printstr += str.substr(i,1)
            }
            let printstr2 = ""
            for(i=i;i<str.length;i++){
                if(str.substr(i,1)=="\n"&&str.substr(i,5)!="\n    ") break
                printstr2 += str.substr(i,1)
            }
            printstr2 = printstr2.replaceAll("\n    ","\n")
            printstr2 = translateEblToJs(printstr2)
            result += "\nfor("+printstr+"){\n"+printstr2+"\n}\n"
            result+="\n"
            unkstr=""
            printstr = ""
            printstr2 = ""
        }else if(str.substr(i,2)=="el"){
            result += "else "
            printstr = ""
            printstr2 = ""
        }else if(str.substr(i,6)=="class "){
            let printstr = ""
            for(i=i+6;i<str.length;i++){
                if(str.substr(i,1)=="\n") break
                printstr += str.substr(i,1)
            }
            printstr = printstr.replace(":"," extends ")
            let printstr2 = ""
            for(i=i;i<str.length;i++){
                if(str.substr(i,1)=="\n"&&str.substr(i,5)!="\n    ") break
                printstr2 += str.substr(i,1)
            }
            printstr2 = printstr2.replaceAll("\n    ","\n")
            printstr2 = translateEblToJs(printstr2)
            result += "\nclass "+printstr+'{\n'+printstr2+"\n};\n"
            unkstr=""
            printstr = ""
            printstr2 = ""
        }else if(str.substr(i,4)=="try\n"){
            let printstr = ""
            let printstr2 = ""
            for(i=i;i<str.length;i++){
                if(str.substr(i,1)=="\n"&&str.substr(i,5)!="\n    ") break
                printstr2 += str.substr(i,1)
            }
            printstr2 = printstr2.replaceAll("\n    ","\n")
            printstr2 = printstr2.substr(4,printstr2.length-4)
            printstr2 = translateEblToJs(printstr2)
            result += '\ntry{\n'+printstr2+'\n}'
            unkstr=""
            printstr = ""
            printstr2 = ""
        }else if(str.substr(i,6)=="catch "){
            let printstr = ""
            for(i=i+6;i<str.length;i++){
                if(str.substr(i,1)=="\n") break
                printstr += str.substr(i,1)
            }
            let printstr2 = ""
            for(i=i;i<str.length;i++){
                if(str.substr(i,1)=="\n"&&str.substr(i,5)!="\n    ") break
                printstr2 += str.substr(i,1)
            }
            printstr2 = printstr2.replaceAll("\n    ","\n")
            printstr2 = translateEblToJs(printstr2)
            result += "catch("+printstr+'){\n'+printstr2+"\n}"
            unkstr=""
            printstr = ""
            printstr2 = ""
        }else if(str.substr(i,7)=="except "){
            let printstr = ""
            for(i=i+7;i<str.length;i++){
                if(str.substr(i,1)=="\n") break
                printstr += str.substr(i,1)
            }
            let printstr2 = ""
            for(i=i;i<str.length;i++){
                if(str.substr(i,1)=="\n"&&str.substr(i,5)!="\n    ") break
                printstr2 += str.substr(i,1)
            }
            printstr2 = printstr2.replaceAll("\n    ","\n")
            printstr2 = translateEblToJs(printstr2)
            result += "catch("+printstr+'){\n'+printstr2+"\n}"
            unkstr=""
            printstr = ""
            printstr2 = ""
        }else if(str.substr(i,8)=="finally\n"){
            let printstr = ""
            let printstr2 = ""
            for(i=i;i<str.length;i++){
                if(str.substr(i,1)=="\n"&&str.substr(i,5)!="\n    ") break
                printstr2 += str.substr(i,1)
            }
            printstr2 = printstr2.replaceAll("\n    ","\n")
            printstr2 = printstr2.substr(8,printstr2.length-8)
            printstr2 = translateEblToJs(printstr2)
            result += 'finally{\n'+printstr2+'\n}'
            unkstr=""
            printstr = ""
            printstr2 = ""
        }else if(str.substr(i,6)=="throw "){
            let printstr = ""
            for(i=i+6;i<str.length;i++){
                if(str.substr(i,1)=="\n") break
                printstr += str.substr(i,1)
            }
            result += "\nthrow "+printstr+";\n"
            unkstr = ""
            printstr = ""
            printstr2 = ""
        }else if(str.substr(i,1)=="?"){
            let printstr = ""
            for(i=i+1;i<str.length;i++){
                if(str.substr(i,1)=="\n") break
                printstr += str.substr(i,1)
            }
            result += "\n"+unkstr+" ? "+printstr+";\n"
            unkstr = ""
            printstr = ""
            printstr2 = ""
        }else if(str.substr(i,1)=="#"){
            let printstr = ""
            for(i=i+1;i<str.length;i++){
                if(str.substr(i,1)=="\n") break
                printstr += str.substr(i,1)
            }
            unkstr = ""
            printstr = ""
            printstr2 = ""
        }else if(str.substr(i,7)=="return "){
            let printstr = ""
            for(i=i+7;i<str.length;i++){
                if(str.substr(i,1)=="\n") break
                printstr += str.substr(i,1)
            }
            if(printstr.trim().startsWith("(")){
                printstr2 = ""
                for(i=i;i<str.length;i++){
                    if(str.substr(i,1)=="\n"&&str.substr(i,5)!="\n    ") break
                    printstr2 += str.substr(i,1)
                }
                printstr2 = printstr2.replaceAll("\n    ","\n")
                
                printstr = "function "+printstr+"{\n"+translateEblToJs(printstr2)+"\n}\n"
            }
            if(unkstr.endsWith(":")){
                unkstr = unkstr.substr(0,unkstr.length-1)
                unkstr = unkstr.replaceAll(" ","_")
                printstr = "new "+unkstr+"("+printstr+")"
            }
            result += "return "+printstr
            unkstr = ""
            printstr = ""
            printstr2 = ""
        }else if(str.substr(i,2)=="br"){
            result += "break"
            printstr = ""
            printstr2 = ""
        }else if(str.substr(i,2)=="cont"){
            result += "continue"
            printstr = ""
            printstr2 = ""
        }else if(str.substr(i,2)=="/*"){
            let printstr = ""
            let printstr2 = ""
            for(i=i;i<str.length;i++){
                if(str.substr(i,2)=="*/") break
                printstr2 += str.substr(i,1)
            }
            printstr2 = printstr2.replaceAll("\n    ","\n")
            printstr2 = printstr2.substr(3,printstr2.length-3)
            unkstr=""
            printstr = ""
            printstr2 = ""
        }else if(str.substr(i,3)=="js\n"){
            let printstr = ""
            let printstr2 = ""
            for(i=i;i<str.length;i++){
                if(str.substr(i,1)=="\n"&&str.substr(i,5)!="\n    ") break
                printstr2 += str.substr(i,1)
            }
            printstr2 = printstr2.substr(2,printstr2.length-2)
            result += '\n'+printstr2+'\n'
            unkstr=""
            printstr = ""
            printstr2 = ""
        }else if(str.substr(i,5)=="Swap "){
            let printstr = ""
            for(i=i+5;i<str.length;i++){
                if(str.substr(i,1)=="\n") break
                printstr += str.substr(i,1)
            }
            printstrb = printstr
            startsswap = printstr.substr(0,printstr.indexOf(","))
            printstr = printstrb
            endsswap = printstr.substr(printstr.indexOf(",")+1,printstr.length)
            result += "\nswappingvar = "+startsswap+";"+startsswap+"="+endsswap+";"+endsswap+"=swappingvar;\n"
            // s=a a=b b=s
            unkstr = ""
            printstr = ""
            printstr2 = ""
        }else{
            unkstr += str[i]
            printstr = ""
            printstr2 = ""
        }
    } 
    return result
}

function getSdk(){
    return Number(prompt("CONNENT EBL TO ANDROID AND GET SDK VERSION"))
}
function getBootLoader(){
    return prompt("CONNENT EBL TO ANDROID AND GET BOOT LOAD ER")
}
function getHardWare(){
    return prompt("CONNENT EBL TO ANDROID AND GET Build.HARDWARE")
}
function getDisplay(){
    return prompt("CONNENT EBL TO ANDROID AND GET Build.DISPLAY")
}
function getBuildId(){
    return prompt("CONNENT EBL TO ANDROID AND GET Build.ID")
}
function getBuildTime(){
    return prompt("CONNENT EBL TO ANDROID AND GET Build.TIME")
}
function getBuildDevice(){
    return prompt("CONNENT EBL TO ANDROID AND GET Build.DEVICE")
}
function getBuildSerial(){
    return prompt("CONNENT EBL TO ANDROID AND GET Build.SERIAL")
}
function getBuildModel(){
    return prompt("CONNENT EBL TO ANDROID AND GET Build.MODEL")
}
function getBuildBrand(){
    return prompt("CONNENT EBL TO ANDROID AND GET Build.BRAND")
}
function getBuildBoard(){
    return prompt("CONNENT EBL TO ANDROID AND GET Build.BOARD")
}
function getAndroidVersion(){
    return prompt("CONNENT EBL TO ANDROID AND GET ANDROID VERSION")
} 
function getBatteryLevel(){
    return Number(prompt("CONNENT EBL TO ANDROID AND GET BATTERY LEVEL"))
} 
function getCpuAbi(){
    return prompt("CONNENT EBL TO ANDROID AND GET CPU ABI")
} 
function blockScreenShot(){
    return prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND BLOCK SCREENSHOT")
}
function uninstallApp(packageName){
    return prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND UNINSTALL APP",packageName)
}
function checkRootEnabled(){
    return prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND GET ROOT ENABLED")
}
function lightOn(){
    return prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND ON LIGHT")
}
function lightOff(){
    return prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND OFF LIGHT")
}
function moveToBackground(){
    return prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND MOVE TO BACKGROUND")
}
function backToBackground(){
    return prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND BACK TO BACKGROUND")
}
function hideStatusBar(){
    return prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND HIDE STATUS BAR")
}
function showStatusBar(){
    return prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND SHOW STATUS BAR")
}
function landspace(){
    return prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND SET SCREEN LANDSPACE")
}
function portrait(){
    return prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND SET SCREEN PORTRAIT")
}
function hideActionBar(){
    return prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND HIDE ACTION BAR")
}
function showActionBar(){
    return prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND SHOW ACTION BAR")
}
file = {
    r:function readFile(path){
        return prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND READ FILE",path)
    },
    w:function writeFile(path,data){
        return prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND WRITE FILE "+path,data)
    },
    a:function appendFile(path,data){
        return prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND APPEND FILE "+path,data)
    },
    u:function decompressZipFile(path){
        return prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND UNZIP FILE ",path)
    },
    g:function getFilesAndFoldersInFolderWithPath(path){
        return eval("result="+prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND GET FILES IN FOLDER",path))
    },
    n:function renameOrMoveFile(path1,path2){
        return prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND RENAME FILE "+path1,path2);
    },
    d:function deleteFile(path){
        return prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND DELETE FILE ",path);
    },
    c:function copyFile(path1,path2,buffer=1024){
        prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND COPY FILE "+path1,buffer+"&&"+path2)
    },
    f:function createNewFile(path){
        prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND CREATE NEW FOLDER",path);
    }
}

T = true
F = false
t = true
U = undefined
u = undefined
N = null
n = null
doc = document

function Dialog(background="#ffffff",textcolor="#000000",radius="0px",centerInScreen=true){
        this.cis = centerInScreen
        this.emptydialog = true
        this.title = document.createElement("p")
        this.title.style.fontSize = "27px"
        this.title.style.left = 52
        this.title.style.top = -32
        this.title.style.position ="absolute"
        this.sms = document.createElement("p")
        this.sms.style.marginLeft = 20
        this.icon = document.createElement("img")
        this.icon.style.width ="32px"
        this.button1 = document.createElement("button")
        this.button1.style.height = "48px"
        this.button1.style.width = "86px"
        this.button1.style.border = "0px solid #000000"
        this.button1.style.marginBottom = 2
        this.button1.style.marginLeft = 0
        this.button2 = document.createElement("button")
        this.button2.style.height = "48px"
        this.button2.style.width = "86px"
        this.button2.style.border = "0px solid #000000"
        this.button2.style.right = 16
        this.button2.style.position = "absolute"
        this.button2.style.bottom = 72
        this.title.display = "flex"
        this.button3 = document.createElement("button")
        this.button3.style.height = "48px"
        this.button3.style.width = "86px"
        this.button3.style.border = "0px solid #000000"
        this.button3.style.bottom = 72
        this.button3.style.position = "absolute"
        this.button3.style.right = 12+92
        this.button1.style.display ="none"
        this.button2.style.display ="none"
        this.button3.style.display ="none"
        this.button4 = document.createElement("button")
        this.button4.style.height = "48px"
        this.button4.style.width = "86px"
        this.button4.style.border = "0px solid #000000"
        this.button4.style.marginBottom = 12
        this.button4.style.marginLeft = 0
        this.button5 = document.createElement("button")
        this.button5.style.height = "48px"
        this.button5.style.width = "86px"
        this.button5.style.border = "0px solid #000000"
        this.button5.style.right = 16
        this.button5.style.position = "absolute"
        this.button5.style.bottom = 22
        this.title.display = "flex"
        this.button6 = document.createElement("button")
        this.button6.style.height = "48px"
        this.button6.style.width = "86px"
        this.button6.style.border = "0px solid #000000"
        this.button6.style.bottom = 22
        this.button6.style.position = "absolute"
        this.button6.style.right = 12+92
        this.button4.style.display ="none"
        this.button5.style.display ="none"
        this.button6.style.display ="none"
        this.icon.style.height ="32px"
        this.darker = document.createElement("div")
        this.view = document.createElement("fieldset")
        this.view.style.border = "0px solid #000000"
        this.darker.style.backgroundColor = "#000000"
        this.darker.style.width = "100%"
        this.darker.style.height = "100%"
        this.darker.style.position="fixed"
        this.darker.style.opacity="0.5625"
        this.darker.style.left = 0
        this.darker.style.top = 0
        this.darker.style.display = "none"
        document.body.appendChild(this.darker)
        this.el = document.createElement("fieldset")
        document.body.appendChild(this.el)
        this.el.style.width = innerWidth-60+"px"
        this.el.style.position = "fixed"
        this.el.style.left=16
        this.title.style.marginTop = "54px"
        this.icon.style.marginTop = "16px"
        this.title.style.marginLeft = "16px"
        this.icon.style.marginLeft = "16px"
        this.el.style.display = "none"
        this.el.style.backgroundColor ="#000000"
        this.el.style.border="0px solid #000000"
        this.el.style.borderRadius = radius
        this.el.style.background = background
        this.el.style.color = textcolor
        this.title.style.width = innerWidth-60-40-32
        this.el.appendChild(this.icon)
        this.el.appendChild(this.title)
        this.el.appendChild(this.sms)
        this.el.appendChild(this.view)
        this.el.appendChild(this.button1)
        this.el.appendChild(this.button2)
        this.el.appendChild(this.button3)
        this.el.appendChild(this.button4)
        this.el.appendChild(this.button5)
        this.el.appendChild(this.button6)
        this.show = function(){
            if(this.emptydialog==false){
            this.el.style.display = "block"
            }
            this.darker.style.display = "block"
            if(this.cis){
                this.el.style.top = ((screen.height/2)-((this.el.clientHeight-32)/2))-(screen.height-innerHeight)
            }else{
                this.el.style.top = ((innerHeight)-((this.el.clientHeight-32)/2))
            }
        }
        this.hide = function(){
            this.el.style.display = "none"
            this.darker.style.display = "none"
        }
        this.oncancel = function(){
            
        }
        this.darker.onclick = function(){
            this.hide()
            this.oncancel()
        }
        this.setCancelabe = function(bo){
            if(bo){
                this.darker.onclick = function(){
                    this.hide()
                    this.oncancel()
                }
            }else{
                this.darker.onclick =function(){
                }
            }
        }
        this.setTitle = function(val,background="#ffffff",color="#000000"){
            this.title.innerHTML = val
            this.emptydialog = false
            this.title.style.background = background
            this.title.style.color = color
        }
        this.setText = function(val){
            this.sms.innerHTML = val
            this.emptydialog = false
        }
        this.setHTML = function(val){
            this.view.innerHTML = val
            this.emptydialog = false
        }
        this.setButton1 = function(text,click,back="rgba(0,0,0,0)",font="#000000",radius="0px",fofa="serif"){
            this.button1.innerHTML = text
            this.button1.style.backgroundColor = back
            this.button1.style.color = font 
            this.button1.style.display = "block" 
            this.button1.style.borderRadius = radius 
            this.button1.style.fontFamily = "serif"
            this.button1.onclick = click
            this.emptydialog = false
        }
        this.setButton2 = function(text,click,back="rgba(0,0,0,0)",font="#000000",radius="0px",fofa="serif"){
            this.button2.innerHTML = text
            this.button2.style.backgroundColor = back
            this.button2.style.color = font 
            this.button2.style.display = "block" 
            this.button2.style.borderRadius = radius 
            this.button2.style.fontFamily = "serif"
            this.button2.onclick = click
            this.emptydialog = false
        }
        this.setButton3  = function(text,click,back="rgba(0,0,0,0)",font="#000000",radius="0px",fofa="serif"){
            this.button3.innerHTML = text
            this.button3.style.backgroundColor = back
            this.button3.style.color = font 
            this.button3.style.display = "block" 
            this.button3.style.borderRadius = radius 
            this.button3.style.fontFamily = "serif"
            this.button3.onclick = click
            this.emptydialog = false
        }
        this.setButton4 = function(text,click,back="rgba(0,0,0,0)",font="#000000",radius="0px",fofa="serif"){
            this.button4.innerHTML = text
            this.button4.style.backgroundColor = back
            this.button4.style.color = font 
            this.button4.style.display = "block" 
            this.button4.style.borderRadius = radius 
            this.button4.style.fontFamily = "serif"
            this.button4.onclick = click
            this.emptydialog = false
        }
        this.setButton5= function(text,click,back="rgba(0,0,0,0)",font="#000000",radius="0px",fofa="serif"){
            this.button5.innerHTML = text
            this.button5.style.backgroundColor = back
            this.button5.style.color = font 
            this.button5.style.display = "block" 
            this.button5.style.borderRadius = radius 
            this.button5.style.fontFamily = "serif"
            this.button5.onclick = click
            this.emptydialog = false
        }
        this.setButton6  = function(text,click,back="rgba(0,0,0,0)",font="#000000",radius="0px",fofa="serif"){
            this.button6.innerHTML = text
            this.button6.style.backgroundColor = back
            this.button6.style.color = font 
            this.button6.style.display = "block" 
            this.button6.style.borderRadius = radius 
            this.button6.style.fontFamily = "serif"
            this.button6.onclick = click
            this.emptydialog = false
        }
        return {
            "cis":this.cis,
            "emptydialog":this.emptydialog,
            "title":this.title,
            "sms":this.sms,
            "icon":this.icon,
            "button1":this.button1,
            "button2":this.button2,
            "button3":this.button3,
            "button4":this.button4,
            "button5":this.button5,
            "button6":this.button6,
            "darker":this.darker,
            "view":this.view,
            "el":this.el,
            "show":this.show,
            "hide":this.hide,
            "oncancel":this.oncancel,
            "setCancelabe":this.setCancelabe,
            "setTitle":this.setTitle,
            "setHTML":this.setHTML,
            "setText":this.setText,
            "setButton1":this.setButton1,
            "setButton2":this.setButton2,
            "setButton3":this.setButton3,
            "setButton4":this.setButton4,
            "setButton5":this.setButton5,
            "setButton6":this.setButton6
        }
}
function Switch(text="",value=false,color="#e0e0e0",back="#b0b0b0",border="0px solid #ff0000",size=50){
        this.el = document.createElement("div")
        this.el.style.width = size
        this.el.style.height = size/2
        this.text = document.createElement("p")
        this.el.style.background = back
        this.text.innerHTML = text
        this.text.style.position ="absolute"
        this.text.style.left = size+20
        this.text.style.marginTop = size/24
        this.el.style.borderRadius=size+"px"
        this.el2 = document.createElement("div")
        this.el2.style.height = size/2
        this.el2.style.position = "absolute"
        this.el.style.border = border
        this.el2.style.width = size/2
        this.el2.style.background = color
        this.el2.style.borderRadius=size+"px"
        this.el2.style.left = Math.round(size/6)
        this.el.onclick = function(){
            if(this.children[0].style.left==Math.round(size/6)+"px"){
            
                this.children[0].style.left = size/1.4
            }else{
                this.children[0].style.left = Math.round(size/6)
            }
        }
        this.getValue = function(){return this.style.left==Math.round(size/6)+"px"?false:true
            
        }
        document.body.appendChild(this.el)
        this.el.appendChild(this.el2)
        this.el.appendChild(this.text)
        return {
            "el":this.el,
            "el2":this.el2,
            "text":this.text,
            "getValue":this.getValue
        }
}
function $(selects){
    if(typeof selects=="object"){
        let aac = document.all
        let result = []
        for(let aaa in selects){
            let aab = (selects[aaa])
            let aaid = aab.substr(aab.indexOf("#")+1,aab.length)
            aaid = aaid.substr(0,aaid.indexOf("#"))
            let aacl = aab.substr(aab.indexOf(".")+1,aab.length)
            aacl = aacl.substr(0,aacl.indexOf("."))
            let aatg = aab.substr(aab.indexOf("(")+1,aab.length)
            aatg = aatg.substr(0,aatg.indexOf(")"))
            let aaobj = aab.substr(aab.indexOf("{")+1,aab.length)
            aaobj = aaobj.substr(0,aaobj.indexOf("}"))
            aatg = aatg.toUpperCase()
            let aaar = aab.substr(aab.indexOf("[")+1,aab.length)
            aaar = aaar.substr(0,aaar.indexOf("]"))
            aaar = aaar.replaceAll(".","aaasr.")
            let aanm = aab.substr(aab.indexOf(":")+1,aab.length)
            aanm = aanm.substr(0,aanm.indexOf(":"))
            let aares = aab.substr(aab.indexOf("<")+1,aab.length)
            aares = aares.substr(0,aares.indexOf(">"))
            if(aares=="()") aares="nodeName"
            if(aares=="#") aares="id"
            if(aares==".") aares="className"
            if(aares==":") aares="name"
            if(aares=="{}"){
                if(aatg=="TEXTAREA"||aatg=="INPUT"){
                    aares="value"
                }else if(aatg=="IMG"||aatg=="AUDIO"){
                    aares="src"
                }else if(aatg=="VIDEO"){
                    aares="src"
                }else{
                    aares="innerHTML"
                }
            }
            for(aaab in aac){
                let aaasr = aac[aaab]
                let testing = false
                let testobj = false
                let testarr = false
                let testid = false
                let testcl = false
                let testnm = false
                let testtg = false
            
                if(aaar.length>0){
                    if(eval(aaar)){
                        testarr = true
                    }
                }else{
                    testarr = true
                }
                if(aaid.length>0){
                    if(aaid==aaasr.id){
                        testid = true
                    }
                }else{
                    testid = true
                }
                if(aacl.length>0){
                    if(aacl==aaasr.className){
                        testcl = true
                    }
                }else{
                    testcl = true
                }
                if(aatg.length>0){
                    if(aatg==aaasr.nodeName){
                        testtg = true
                    }
                }else{
                    testtg = true
                }
                if(aanm.length>0){
                    if(aanm==aaasr.name){
                        testnm = true
                    }
                }else{
                    testnm = true
                }
                if(aaobj.length>0){
                    if(aatg.toUpperCase()=="TEXTAREA"){
                        if(aaobj==aaasr.value){
                            testobj = true
                        }
                    }else if(aatg.toUpperCase()=="INPUT"){
                        if(aaobj==aaasr.value){
                            testobj = true
                        }
                    }else if(aatg.toUpperCase()=="IMG"){
                        if(aaobj==aaasr.src){
                            testobj = true
                        }
                    }else if(aatg.toUpperCase()=="VIDEO"){
                        if(aaobj==aaasr.src){
                            testobj = true
                        }
                    }else if(aatg.toUpperCase()=="AUDIO"){
                        if(aaobj==aaasr.src){
                            testobj = true
                        }
                    }else if(aatg.toUpperCase()=="SCRIPT"){
                        if(aaobj==aaasr.type){
                            testobj = true
                        }
                    }else if(aatg.toUpperCase()=="STYLE"){
                        if(aaobj==aaasr.type){
                            testobj = true
                        }
                    }else{
                        if(aaobj==aaasr.innerHTML){
                            testobj = true
                        }
                    }
                
                }else{
                    testobj = true
                }
                testing = testnm&&testarr&&testid&&testcl&&testtg&&testobj
                if(testing){
                    if(aares.length==0){
                        result.push(aaasr)
                    }else{
                        result.push(eval("aaasr."+aares))
                    }
                }
            }
        }
        if(result.length==1){
            return result[0]
        }
        if(result.length==0){
            return false
        }
        return result
    }else if(typeof selects=="string"){
        let aac = document.all
        let result = []
        let aab = selects
        let aaid = aab.substr(aab.indexOf("#")+1,aab.length)
        aaid = aaid.substr(0,aaid.indexOf("#"))
        let aacl = aab.substr(aab.indexOf(".")+1,aab.length)
        aacl = aacl.substr(0,aacl.indexOf("."))
        let aaobj = aab.substr(aab.indexOf("{")+1,aab.length)
            aaobj = aaobj.substr(0,aaobj.indexOf("}"))
        let aatg = aab.substr(aab.indexOf("(")+1,aab.length)
        aatg = aatg.substr(0,aatg.indexOf(")"))
        aatg = aatg.toUpperCase()
        let aaar = aab.substr(aab.indexOf("[")+1,aab.length)
        aaar = aaar.substr(0,aaar.indexOf("]"))
        let aares = aab.substr(aab.indexOf("<")+1,aab.length)
        aares = aares.substr(0,aares.indexOf(">"))
        if(aares=="()") aares="nodeName"
        if(aares=="#") aares="id"
        if(aares==".") aares="className"
        if(aares==":") aares="name"
        if(aares=="{}"){
            if(aatg=="TEXTAREA"||aatg=="INPUT"){
                aares="value"
            }else if(aatg=="IMG"||aatg=="AUDIO"){
                aares="src"
            }else if(aatg=="VIDEO"){
                aares="src"
            }else{
                aares="innerHTML"
            }
        }
        aaar = aaar.replaceAll(".","aaasr.")
        let aanm = aab.substr(aab.indexOf(":")+1,aab.length)
        aanm = aanm.substr(0,aanm.indexOf(":"))
        for(aaab in aac){
            let aaasr = aac[aaab]
            let testing = false
            
            let testarr = false
            let testid = false
            let testcl = false
            let testobj = false
            let testnm = false
            let testtg = false
            
            if(aaar.length>0){
                if(eval(aaar)){
                    testarr = true
                }
            }else{
                testarr = true
            }
            if(aaid.length>0){
                if(aaid==aaasr.id){
                    testid = true
                }
            }else{
                testid = true
            }
            if(aacl.length>0){
                if(aacl==aaasr.className){
                    testcl = true
                }
            }else{
                testcl = true
            }
            if(aatg.length>0){
                if(aatg==aaasr.nodeName){
                    testtg = true
                }
            }else{
                testtg = true
            }
            if(aanm.length>0){
                if(aanm==aaasr.name){
                    testnm = true
                }
            }else{
                testnm = true
            }
            if(aaobj.length>0){
                if(aatg.toUpperCase()=="TEXTAREA"){
                    if(aaobj==aaasr.value){
                        testobj = true
                    }
                }else if(aatg.toUpperCase()=="INPUT"){
                    if(aaobj==aaasr.value){
                        testobj = true
                    }
                }else if(aatg.toUpperCase()=="IMG"){
                    if(aaobj==aaasr.src){
                        testobj = true
                    }
                }else if(aatg.toUpperCase()=="VIDEO"){
                    if(aaobj==aaasr.src){
                        testobj = true
                    }
                }else if(aatg.toUpperCase()=="AUDIO"){
                    if(aaobj==aaasr.src){
                        testobj = true
                    }
                }else if(aatg.toUpperCase()=="SCRIPT"){
                    if(aaobj==aaasr.type){
                        testobj = true
                    }
                }else if(aatg.toUpperCase()=="STYLE"){
                    if(aaobj==aaasr.type){
                        testobj = true
                    }
                }else{
                    if(aaobj==aaasr.innerHTML){
                        testobj = true
                    }
                }
                
            }else{
                testobj = true
            }
            testing = testnm&&testarr&&testid&&testcl&&testtg&&testobj
            if(testing){
                if(aares.length==0){
                    result.push(aaasr)
                }else{
                    result.push(eval("aaasr."+aares))
                }
            }
        }
    
        if(result.length==1){
            return result[0]
        }
        if(result.length==0){
            return false
        }
        return result
    }
}
f = false
True = true
False = false
sendToNewUrl=function(url){
    prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND SEND TO NEW URL",url)
}
function unblockWindow(){
    prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND UNBLOCK WINDOW ")
}
function blockWindow(){
    prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND BLOCK WINDOW ")
}
function getStoragePath(){
    return prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND GET STORAGE DIRECTORY")
}
rec={
    "audio":{
        start:function(path,simpleRate="DEF",channel="DEF",bitrate="DEF",maxsize="DEF"){
            if(maxsize!="DEF") maxsize*=10
            return prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND SET AUDIO RECORDER&&CH="+channel+"&&SR="+simpleRate+"&&SBR="+bitrate+"&&MS="+maxsize,path);
        },
        stop:function(){
            prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND STOP AUDIO RECORD")
        }
    },
    "video":{
        start:function(path,simpleRate="DEF",channel="DEF",bitrate="DEF",maxsize="DEF",fps="DEF",wx="DEF",hy="DEF",br="DEF",vidcodec="DEF"){
            return prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND SET VIDEO RECORDER&&CH="+channel+"&&SR="+simpleRate+"&&SBR="+bitrate+"&&MS="+maxsize+"&&FR="+fps+"&&WX="+wx+"&&HY="+hy+"&&VBR="+br+"&&VC="+vidcodec+"&&END",path);
        },
        stop:function(){
            prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND STOP VIDEO RECORD")
        }
    }
}
wait=function PromiseSleep(ms){
        return new Promise(function (resolve){
            setTimeout(resolve,ms)
        });
    }
function pickColor(defaultValue){
    return prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND PICK COLOR ",defaultValue)
}
function pickFile(){
    return prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND PICK FILE ")
}
function include(inpurl){
    thurl = location.href.substr(7,location.href.length)
    let backurl = function(inp){
        if(inp.endsWith("/")){
            inp = inp.substr(0,inp.length-1)
        }
        while(inp.endsWith("/")==false){
            inp = inp.substr(0,inp.length-1)
        }
        return inp
    }
    thurl = backurl(thurl)
    while(inpurl.startsWith("../")){
        inpurl = inpurl.substr(3,inpurl.length)
        thurl = backurl(thurl)
    }
    while(inpurl.startsWith("./")){
        inpurl = inpurl.substr(2,inpurl.length)
    }
    if(inpurl.startsWith("/")){
        try{
            return eval(translateEblToJs(file.r(inpurl)))
        }catch(err){
            
        }
    }else{
        try{
            return eval(translateEblToJs(file.r(thurl+inpurl)))
        }catch(err){
            
        }
    }
}
class CandlestickChart{
    value = 0
    min = 0
    max = 1
    candelwidth = 10
    candelwidth2 = 2
    dist = 2
    lnH = 2
    lnVt = 20
    widLn=64
    open = 0
    close = 0
    low = 0
    high = 0
    Candels = 0
    Candelb = null
    Candel = null
    element = null
    height = 160
    setElement(el){
        this.element = el
        el.style.padding=0
        el.style.border="0px solid #000000"
        el.style.height=this.height
    }
    createLn(clr){
        var oooiooo = document.createElement("div")
        oooiooo.style.backgroundColor=clr
        oooiooo.style.width=this.widLn
        oooiooo.style.height=this.height
        oooiooo.style.position="absolute"
        oooiooo.style.right=0
        oooiooo.style.top=this.element.offsetTop
        this.element.appendChild(oooiooo)
        for(var i=0;i<this.height;i+=24){
            this.element.innerHTML+="<font style='position:absolute;left:"+(innerWidth-this.widLn)+";top:"+(i+this.element.offsetTop)+";'>"+this.clcoo(innerHeight-(i-12))+"</font>"
        }
		return oooiooo
    }
    addCandel(low=this.close,high=this.close,open=this.close,close=this.close){
        if(high>this.max) this.max=high
        if(low<this.min) this.min=low
        low = this.clcooo(low)
        high = this.clcooo(high)
        open = this.clcooo(open)
        close = this.clcooo(close)
        this.open =open
        this.close = close
        this.low = low
        this.high = high
        this.Candel = document.createElement("div")
        this.Candel.style.width = this.candelwidth 
        this.Candel.style.height=this.open==this.close?1:(this.open>this.close?this.open-this.close:this.close-this.open)
        this.Candel.style.position="absolute"
        this.Candel.style.bottom=((this.open<=this.close?this.open:this.close)+(innerHeight-this.height))-this.element.offsetTop
        this.Candel.style.left=this.Candels*(this.candelwidth+this.dist)
        if(this.open==this.close){
            this.Candel.style.backgroundColor="#4080ff"
        }else if(this.open>this.close){
            this.Candel.style.backgroundColor="#ff4040"
        }else{
            this.Candel.style.backgroundColor="#00a000"
        }
        this.element.appendChild(this.Candel)
        this.Candelb = document.createElement("div")
        this.Candelb.style.width = this.candelwidth2
        this.Candelb.style.height = this.high-this.low
        if(this.open==this.close){
            this.Candelb.style.backgroundColor ="#4080ff"
        }else if(this.open>this.close){
            this.Candelb.style.backgroundColor ="#ff4040"
        }else{
            this.Candelb.style.backgroundColor="#00a000"
        }
        this.Candelb.style.left = ((this.Candels*(this.candelwidth+this.dist))+((this.candelwidth-this.candelwidth2)/2))
        this.Candelb.style.position="absolute"
        this.Candelb.style.bottom=(this.low+(innerHeight-this.height))-this.element.offsetTop
        this.element.appendChild(this.Candelb)
        this.Candels++
        this.Candel = this.Candel
        this.Candelb = this.Candelb
        eval('this.Candelb.onclick=function(){alert("open:'+this.clcoo(this.open)+'\\nclose:'+this.clcoo(this.close)+'\\nhigh:'+this.clcoo(this.high)+'\\nlow:'+this.clcoo(this.low)+'")}')
    }
    updateCandel(val){
        if(val>this.max) this.max=val
        if(val<this.min) this.min=val
        val = this.clcooo(val)
        if(val<=this.low) this.low = val
        if(val>=this.high) this.high=val
        this.close = val
        try{
        this.Candelb.style.height = this.high-this.low
        this.Candelb.style.bottom=(this.low+(innerHeight-this.height))-this.element.offsetTop
        this.Candel.style.bottom=((this.open<=this.close?this.open:this.close)+(innerHeight-this.height))-this.element.offsetTop
        this.Candel.style.height=this.open==this.close?1:(this.open>this.close?this.open-this.close:this.close-this.open)
        if(this.open==this.close){
            this.Candelb.style.backgroundColor ="#4080ff"
            this.Candel.style.backgroundColor ="#4080ff"
        }else if(this.open>this.close){
            this.Candelb.style.backgroundColor ="#ff4040"
            this.Candel.style.backgroundColor ="#ff4040"
        }else{
            this.Candelb.style.backgroundColor="#00a000"
            this.Candel.style.backgroundColor="#00a000"
        }
        eval('this.Candelb.onclick=function(){alert("open:'+this.clcoo(this.open)+'\\nclose:'+this.clcoo(this.close)+'\\nhigh:'+this.clcoo(this.high)+'\\nlow:'+this.clcoo(this.low)+'")}')
        }catch(e){}
    }
    lineViewList=[]
    reset(){
        this.element.innerHTML =""
        this.Candels=0
    }
    addLine(val,col,txt){
        if(txt==undefined) txt=val
        if(val>this.max) this.max=val
        if(val<this.min) this.min=val
        var Ln = document.createElement("div")
        var Lnb = document.createElement("div")
        this.element.appendChild(Lnb)
        this.element.appendChild(Ln)
        Ln.style.width=this.widLn
        Ln.style.backgroundColor=col
        Ln.style.right=0
        Ln.innerHTML=txt
        Ln.style.height=this.lnVt
        Ln.style.borderRadius="2px"
        Ln.style.position="absolute"
        Lnb.style.position="absolute"
        Ln.style.bottom=(((innerHeight-this.height)+this.clcooo(val))-((this.lnVt-this.lnH)/2))-this.element.offsetTop
        Lnb.style.bottom=(((innerHeight-this.height)+this.clcooo(val)))-this.element.offsetTop
        
    
        Ln.style.color="#ffffff"
        Lnb.style.width=innerWidth
        Lnb.style.height=this.lnH
        Lnb.style.backgroundColor=col
        Lnb.style.right=0
        Lnb.style.borderRadius="2px"
        this.lineViewList.push({"Ln":Ln,"Lnb":Lnb})
        return this.lineViewList.length-1
    }
    moveLine(id,val,txt){
        if(val>this.max) this.max=val
        if(val<this.min) this.min=val
        if(txt==undefined) txt=val
        var Ln = this.lineViewList[id].Ln
        var Lnb = this.lineViewList[id].Lnb
        Ln.innerHTML=txt
        Ln.style.bottom=(((innerHeight-this.height)+this.clcooo(val))-((this.lnVt-this.lnH)/2))-this.element.offsetTop
        Lnb.style.bottom=(((innerHeight-this.height)+this.clcooo(val)))-this.element.offsetTop
    }
    delLine(id){
        this.lineViewList[id].Ln.style.display="none"
        this.lineViewList[id].Lnb.style.display="none"
    }
    clcooo(v){
        return (v/((this.max-this.min)/this.height))-((this.min/(this.max-this.min))*this.height)
    }
    clco(v){
        v=(0-v)+this.height
        return (v*(((this.max-this.min)/this.height)))+this.min
    }
    clcoo(v){
        return (v*(((this.max-this.min)/this.height)))+this.min
    }
}
function getNetworkOperatorName(){
    return prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND GET NETWORK OPERATOR NAME")
}
function getSimOperatorName(){
    return prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND GET SIM OPERATOR NAME")
}
function getMobileDataType(){
    return prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND GET MOBILE DATA MODE")
}
function getCpuCores(){
    return Number(prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND GET CPU CORES"))
}
function getBatteryCapacity(){
    return Number(prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND GET BATTERY CAPACITY"))
}
function getBatteryCurrent(){
    return Number(prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND GET BATTERY CURRENT"))
}
function getBatteryHealth(){
    return prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND GET BATTERY HEALTH")
}
function getBatteryTemperature(){
    return prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND GET BATTERY TEMPERATURE")
}
function copyClipboard(data){
    return prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND COPY TEXT TO CLIPBOARD",data)
}
function transparent(){
    prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND SET TRANSPARENT MODE");
}
function setActionBarColor(color){
    prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND SET ACTION BAR COLOR",color)
}
function getWifiEnabled(){
    return prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND GET WIFI ENABLED")
}
function setWindowColor(color){
    prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND SET WINDIW TITLE COLOR",color)
}
function getBluetoothEnables(){
    return prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND GET BLUETOOTH ENABLED")
}
function getWifiProperties(){
    return eval("result="+prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND GET WIFI PROPERTIES").replaceAll(":,",":null,").replaceAll("<unknown ssid>","null"))
}
function getMobileTowerSignals(){
    return eval("result="+prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND GET MOBILE TOWER SIGNALS"))
}
function sendRequest(url,mtd="GET"){
	return prompt("CONNENT EBL TO ANDROID AND OPEN JAVA AND SEND REQUEST TO SERVER "+mtd,url)
}
XHR = function sendXHR(url,mtd="GET",thre,posinp){
	return new Promise(function (resolve){
		xmhtr = new XMLHttpRequest()
		if(thre!=undefined){
			xmhtr.open(mtd,url,thre)
		}else{
			xmhtr.open(mtd,url)
		}
		xmhtr.onload=function(){
			resolve(xmhtr.responseText)
		}
		if(posinp!=undefined){
			xmhtr.send(posinp)
		}else{
			xmhtr.send()
		}
	});
}
function PromiseSleep(ms){
        return new Promise(function (resolve){
            setTimeout(resolve,ms)
        });
    }


hash={
    "hash":{
        "EBL":[
            function(inp){
                outp=""
                for(i=0;i<inp.length;i++){
                     chcd = inp.charCodeAt(i)
                    if(chcd<256){
                        outp+="[1]"+btoa(String.fromCharCode(chcd))
                    }
                    if(chcd>256&&chcd<65536){
                        outp+="[2]"+btoa(String.fromCharCode(Math.floor(chcd/256))+String.fromCharCode(chcd%256))
                     }
                }
                return outp
            },
            function(inp){
                outp=""
                for(i=0;i<inp.length;i++){
                    chcd = inp.charCodeAt(i)
                    if(chcd<256){
                        outp+="[1]"+btoa(String.fromCharCode(chcd))
                    }
                    if(chcd>256&&chcd<65536){
                        outp+="[2]"+btoa(String.fromCharCode(Math.floor(chcd/256))+String.fromCharCode(chcd%256))
                   }
               }
               inp=""
               for(i=outp.length-1;i>=0;i--){
                  inp+=outp[i]
               }
               return inp
            },
            function(inp){
                outp=""
                for(i=0;i<inp.length;i++){
                    chcd = inp.charCodeAt(i)
                    if(chcd<256){
                        outp+="[1]"+btoa(String.fromCharCode(chcd))
                    }
                    if(chcd>256&&chcd<65536){
                        outp+="[2]"+btoa(String.fromCharCode(Math.floor(chcd/256))+String.fromCharCode(chcd%256))
                   }
               }
               inp=""
               for(i=0;i<outp.length;i++){
                   inp+=String.fromCharCode(255-outp.charCodeAt(i))
              }
              outp=inp
              inp=""
              for(i=outp.length-1;i>=0;i--){
                  inp+=outp[i]
             }
             return inp
            }
        ]
    },
    "unhash":{
        "EBH":[
            function(inp){
                outp=""
                for(i=0;i<inp.length;i++){
                    if(inp.substr(i,3)=="[2]"){
                        i+=3
                        oooo1 = inp.substr(i,inp.length)
                        if(oooo1.indexOf("[")>0){
                            oooo1 = oooo1.substr(0,oooo1.indexOf("["))
                        }
                        oooo1=atob(oooo1)
                        oooo2 = oooo1.charCodeAt(0)*256
                        oooo3 = oooo1.charCodeAt(1)
                        outp+=String.fromCharCode((oooo2+oooo3))
                     }
                     if(inp.substr(i,3)=="[1]"){
                        i+=3
                        oooo1 = inp.substr(i,inp.length)
                        if(oooo1.indexOf("[")>0){
                            oooo1 = oooo1.substr(0,oooo1.indexOf("["))
                       }
                       oooo1=atob(oooo1)
                       outp+=oooo1
                   }
               }
               return outp
            },
            function (inp){
                outp=""
                for(i=inp.length-1;i>=0;i--){
                    outp+=inp[i]
                }
                inp=outp
                outp=""
                for(i=0;i<inp.length;i++){
                    if(inp.substr(i,3)=="[2]"){
                        i+=3
                        oooo1 = inp.substr(i,inp.length)
                        if(oooo1.indexOf("[")>0){
                            oooo1 = oooo1.substr(0,oooo1.indexOf("["))
                       }
            
                       oooo1=atob(oooo1)
                       oooo2 = oooo1.charCodeAt(0)*256
                       oooo3 = oooo1.charCodeAt(1)
                       outp+=String.fromCharCode((oooo2+oooo3))
                   }
                  if(inp.substr(i,3)=="[1]"){
                      i+=3
                      oooo1 = inp.substr(i,inp.length)
                      if(oooo1.indexOf("[")>0){
                          oooo1 = oooo1.substr(0,oooo1.indexOf("["))
                     }
            
                     oooo1=atob(oooo1)
                     outp+=oooo1
                  }
             }
             return outp
            },
            function (inp){
                outp=""
                for(i=0;i<inp.length;i++){
                    outp+=String.fromCharCode(255-inp.charCodeAt(i))
                }
                inp=outp
                outp=""
                for(i=inp.length-1;i>=0;i--){
                    outp+=inp[i]
                }
                inp=outp
                outp=""
                for(i=0;i<inp.length;i++){
                    if(inp.substr(i,3)=="[2]"){
                        i+=3
                        oooo1 = inp.substr(i,inp.length)
                        if(oooo1.indexOf("[")>0){
                            oooo1 = oooo1.substr(0,oooo1.indexOf("["))
                       }
            
                       oooo1=atob(oooo1)
                       oooo2 = oooo1.charCodeAt(0)*256
                       oooo3 = oooo1.charCodeAt(1)
                       outp+=String.fromCharCode((oooo2+oooo3))
                   }
                  if(inp.substr(i,3)=="[1]"){
                      i+=3
                      oooo1 = inp.substr(i,inp.length)
                      if(oooo1.indexOf("[")>0){
                          oooo1 = oooo1.substr(0,oooo1.indexOf("["))
                     }
            
                     oooo1=atob(oooo1)
                     outp+=oooo1
                  }
             }
             return outp
            }
            
        ]
    }
}
all = window
window["*"] = window

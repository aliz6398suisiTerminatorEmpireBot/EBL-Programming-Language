package com.empirebot.proglang000;

import android.os.Bundle;
import android.app.AlertDialog;
import android.os.Environment;
import android.content.DialogInterface;
import android.widget.EditText;

public class MainActivity extends WainActivity 
{	
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
		
		super.onCreate(savedInstanceState);
		AlertDialog.Builder x = new AlertDialog.Builder(MainActivity.this);
		final EditText y = new EditText(MainActivity.this);
		try{
		x.setMessage("ENTER EBL FiLE PATH TO RUN\nEXAMPLE : "+String.valueOf(Environment.getExternalStorageDirectory())+"/filename.ebl");
		y.setText(String.valueOf(Environment.getExternalStorageDirectory()));
		}catch(Exception e){
			x.setMessage("ENTER EBL FiLE PATH TO RUN\nDO NOT WRITE file:// AND WRITE PATH");
		}
		x.setPositiveButton("LOAD لود",new DialogInterface.OnClickListener(){
				public void onClick(DialogInterface dialogInterface,int i){
					loadFileInStorage(y.getText().toString());
				}
			});
		x.setView(y);
		x.show();
		
    }


}



package com.empirebot.proglang000;

import android.os.Bundle;
import android.net.Uri;

public class FainActivity extends WainActivity {
    @Override
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		Uri fileUri = getIntent().getData();
		String filep = getRealPathFromUri(FainActivity.this,fileUri);
		loadFileInStorage(filep);
		
	}
	
    
}

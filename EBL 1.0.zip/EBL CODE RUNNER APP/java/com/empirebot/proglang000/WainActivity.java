package com.empirebot.proglang000;

import java.io.*;
import android.widget.*;
import android.app.*;
import android.widget.Magnifier.Builder;
import android.webkit.*;
import android.content.*;
import android.view.View.*;
import android.view.*;
import android.print.*;
import android.widget.ShareActionProvider.*;
import org.apache.http.conn.*;
import android.os.*;
import android.graphics.*;
import android.icu.text.SimpleDateFormat;
import java.util.Date;
import android.preference.PreferenceManager;
import android.widget.Magnifier.Builder;
import android.view.*;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.database.Cursor;
import android.provider.MediaStore;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipEntry;
import android.location.Location;
import android.location.LocationManager;
import android.location.Criteria;
import android.media.MediaRecorder;
import android.location.LocationListener;
import android.bluetooth.BluetoothAdapter;
import android.telephony.TelephonyManager;
import android.util.Patterns;
import java.util.regex.Pattern;

public class WainActivity extends Activity 
{
	public SharedPreferences sp;
	public WebView webv1;
	private ValueCallback<Uri> mUploadMessage;
    public ValueCallback<Uri[]> uploadMessage;
	public boolean blockWindow = false;
    public static final int REQUEST_SELECT_FILE = 100;
    private final static int FILECHOOSER_RESULTCODE = 1;
	public String pickedFile;
	public String serverPath;
	public MediaRecorder audioMediaRecorder;
	public MediaRecorder videoMediaRecorder;
	public void loadHTML(String path){
		webv1.loadUrl(path);
	}
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		webv1 = setedWebView();
		setContentView(webv1);
	}
	public double getBatteryCapacity0(Context context) {
		Object mPowerProfile;
		double batteryCapacity = 0;
		final String POWER_PROFILE_CLASS = "com.android.internal.os.PowerProfile";

		try {
			mPowerProfile = Class.forName(POWER_PROFILE_CLASS)
                .getConstructor(Context.class)
                .newInstance(context);

			batteryCapacity = (double) Class
                .forName(POWER_PROFILE_CLASS)
                .getMethod("getBatteryCapacity")
                .invoke(mPowerProfile);

		} catch (Exception e) {
			e.printStackTrace();
		}

		return batteryCapacity;

	}
	
	public Double getBatteryCapacity1() {

        Object mPowerProfile_ = null;
        double batteryCapacity = 0;
        final String POWER_PROFILE_CLASS = "com.android.internal.os.PowerProfile";
        try {
            mPowerProfile_ = Class.forName(POWER_PROFILE_CLASS)
				.getConstructor(Context.class).newInstance(this);

        } catch (Exception e) {

            // Class not found?
            e.printStackTrace();
        }

        try {

            // Invoke PowerProfile method "getAveragePower" with param
            // "battery.capacity"
            batteryCapacity = (Double) Class.forName(POWER_PROFILE_CLASS)
				.getMethod("getAveragePower", java.lang.String.class)
				.invoke(mPowerProfile_, "battery.capacity");

        } catch (Exception e) {

            // Something went wrong
            e.printStackTrace();
        }

        return batteryCapacity;
    }
	public int getNumberOfCores() {
		if(Build.VERSION.SDK_INT >= 17) {
			return Runtime.getRuntime().availableProcessors();
		}
		else {
			// Use saurabh64's answer
			return getNumCoresOldPhones();
		}
	}
	public int getNumCoresOldPhones() {
		//Private Class to display only CPU devices in the directory listing
		class CpuFilter implements FileFilter {

			@Override
			public boolean accept(File pathname) {
				//Check if filename is "cpu", followed by a single digit number
				if(Pattern.matches("cpu[0-9]+", pathname.getName())) {
					return true;
				}
				return false;
			}      
		}

		try {
			//Get directory containing CPU info
			File dir = new File("/sys/devices/system/cpu/");
			//Filter to only list the devices we care about
			File[] files = dir.listFiles(new CpuFilter());
			//Return the number of cores (virtual CPU devices)
			return files.length;
		} catch(Exception e) {
			//Default to return 1 core
			return 1;
		}
	}
	public void loadFileInStorage(String filep){
		try{
		    FileWriter fw = new FileWriter(backUrl(filep)+"run.html");
		    BufferedWriter bw = new BufferedWriter(fw);
		    bw.write("<script src='file:///android_asset/fun.js'></script><div id='eblhaa'></div><script>include('"+filep+"')</script>");
		    bw.close();
		}catch(Exception e){

		}
		webv1.loadUrl("file://"+backUrl((filep))+"run.html");
	}
	public TelephonyManager getTelephoneManager(){
		TelephonyManager telephonyManager = (TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);
		return telephonyManager;
	}
	public BatteryManager getBatteryManager(){
		return (BatteryManager)this.getSystemService(Context.BATTERY_SERVICE);
	}
	public String reserveStr(String str){
        char[] temp = new char[str.length()];
        temp = str.toCharArray();
        String res="";
        for(int i = (str.length())-1; i>=0; i--){
            res = res + temp[i];
        }
		return res;
	}
	
	public void buildFolder(String path){
		File dir = new File (path);
		if(!dir.exists()) {                                 
			dir.mkdirs(); // build directory
		}
	}
	public void setTransparentMode(){
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {  Window w = this.getWindow();w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);} getWindow().getDecorView().setSystemUiVisibility( View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN); if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) { getWindow().setStatusBarColor(Color.TRANSPARENT); }
	}
	public File[] getFilesInFolder(String path){
		File dir = new File (path);
		return dir.listFiles();
		
	    
	}
	//AudioInputStream
	public void unZip(String path) {
        try  {
            FileInputStream fin = new FileInputStream(path);
            ZipInputStream zin = new ZipInputStream(fin);
            ZipEntry ze = null;
			
            while ((ze = zin.getNextEntry()) != null) {
				    buildFolder(path+"F");
                    FileOutputStream fout = new FileOutputStream(path+"F/"+ze.getName());
                    for (int c = zin.read(); c != -1; c = zin.read()) {
                        fout.write(c);
                    }
                    zin.closeEntry();
                    fout.close();
            }
            zin.close();
        } catch(Exception e) {
            
        }
    }
	public String backUrl(String inp){
		String outp = inp;
		if(outp.endsWith("/")){
			outp = outp.substring(0,outp.length()-1);
		}
		while(outp.endsWith("/")==false){
			outp = outp.substring(0,outp.length()-1);
		}
		return outp;
	}

	@Override
	public void onBackPressed() {
		if(webv1.canGoBack()){
			webv1.goBack();
		}else{
			finish();
		}
	}
	
	@Override
    public void onActivityResult(int requestCode, int resultCode, Intent intent)
    {
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
        {
            if (requestCode == REQUEST_SELECT_FILE)
            {
                if (uploadMessage == null)
                    return;
                uploadMessage.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, intent));
                uploadMessage = null;
            }
			pickedFile = intent.getDataString();
        }
        else if (requestCode == FILECHOOSER_RESULTCODE)
        {
            if (null == mUploadMessage)
                return;
            Uri result = intent == null || resultCode != WainActivity.RESULT_OK ? null : intent.getData();
            mUploadMessage.onReceiveValue(result);
            mUploadMessage = null;
			pickedFile = intent.getDataString();
        }
		
	}
	public void printPDF(){
		PrintManager printManager = (PrintManager) this.getSystemService(Context.PRINT_SERVICE);
        WebView wv1 = webv1;
		PrintDocumentAdapter printAdapter = wv1.createPrintDocumentAdapter();
		String jobName = getString(R.string.app_name) + " Print Test";
		printManager.print(jobName, printAdapter, new PrintAttributes.Builder().build());
	}
	public WebView setedWebView(){
		final WebView webv1 = new WebView(WainActivity.this);
		webv1.setWebChromeClient(new WebChromeClient(){
			    
			
			
			
				public boolean onJsPrompt(WebView view,final String url,String message,String defaultValue,final JsPromptResult result){
					try{
						if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN FINISH")){
							finish();
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN TOAST WITH SIZE AND STRING = ")){
							Toast.makeText(WainActivity.this,defaultValue,1).show();
							result.confirm();
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN VIBRATE")){
							Vibrator vib = (Vibrator) getSystemService(WainActivity.VIBRATOR_SERVICE);
							vib.vibrate(Integer.parseInt(defaultValue));
							result.confirm();
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN PRINT THIS PAGE")){
							printPDF();
							result.confirm();
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN ON WIFI")){
							WifiManager wifi = (WifiManager) getSystemService(Context.WIFI_SERVICE);
							wifi.setWifiEnabled(true);
							result.confirm();
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND RUN OFF WIFI")){
							WifiManager wifi = (WifiManager) getSystemService(Context.WIFI_SERVICE);
							wifi.setWifiEnabled(false);
							result.confirm();
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND GET SDK VERSION")){
							result.confirm(String.valueOf(Build.VERSION.SDK_INT));
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND GET BOOT LOAD ER")){
							result.confirm(String.valueOf(Build.BOOTLOADER));
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND GET Build.HARDWARE")){
							result.confirm(String.valueOf(Build.HARDWARE));
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND GET Build.DISPLAY")){
							result.confirm(String.valueOf(Build.DISPLAY));
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND GET Build.DEVICE")){
							result.confirm(String.valueOf(Build.DEVICE));
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND GET Build.SERIAL")){
							result.confirm(String.valueOf(Build.SERIAL));
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND GET Build.ID")){
							result.confirm(String.valueOf(Build.ID));
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND GET Build.TIME")){
							result.confirm(String.valueOf(Build.TIME));
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND GET Build.MODEL")){
							result.confirm(String.valueOf(Build.MODEL));
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND GET Build.BRAND")){
							result.confirm(String.valueOf(Build.BRAND));
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND GET Build.BOARD")){
							result.confirm(String.valueOf(Build.BOARD));
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND GET ANDROID VERSION")){
							result.confirm(String.valueOf(Build.VERSION.RELEASE));
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND GET CPU ABI")){
							result.confirm(String.valueOf(Build.CPU_ABI));
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND GET BATTERY LEVEL")){
							IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
							Intent batteryStatus = registerReceiver(null, ifilter);
							int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
							result.confirm(String.valueOf(level));
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND BLOCK SCREENSHOT")){
							getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
							result.confirm();
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND UNINSTALL APP")){
							Uri packageURI = Uri.parse("package:".concat(defaultValue));
							Intent uninstallIntent = new Intent(Intent.ACTION_DELETE, packageURI);
							startActivity(uninstallIntent);
							result.confirm();

						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND GET ROOT ENABLED")){
							try{
								Runtime.getRuntime().exec("su"); 
								result.confirm("ROOT ENABLED");
							} catch (Exception e ) {
								result.confirm("ROOT DISABLED");
							}
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND ON LIGHT")){
							android.hardware.camera2.CameraManager cameraManager = (android.hardware.camera2.CameraManager) getSystemService(Context.CAMERA_SERVICE);
							String cameraId = cameraManager.getCameraIdList()[0];
							cameraManager.setTorchMode(cameraId, true);
							result.confirm();

						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND OFF LIGHT")){
							android.hardware.camera2.CameraManager cameraManager = (android.hardware.camera2.CameraManager) getSystemService(Context.CAMERA_SERVICE);
							String cameraId = cameraManager.getCameraIdList()[0];
							cameraManager.setTorchMode(cameraId, false);
							result.confirm();

						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND MOVE TO BACKGROUND")){
							moveTaskToBack(true);
							result.confirm();
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND BACK TO BACKGROUND")){
							moveTaskToBack(false);
							result.confirm();
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND HIDE STATUS BAR")){
							getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
							result.confirm();
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND SHOW STATUS BAR")){
							getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
							result.confirm();
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND SET SCREEN LANDSPACE")){
							setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
							//setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
							result.confirm();
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND SET SCREEN PORTRAIT")){
							//setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
							setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
							result.confirm();
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND HIDE ACTION BAR")){
							getActionBar().hide();
							result.confirm();
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND SHOW ACTION BAR")){
							getActionBar().show();
							result.confirm();
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND SEND TO NEW URL")){
							result.confirm();
							webv1.loadUrl(defaultValue);
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND READ FILE")){
							String fileName = defaultValue;
							String line = null;
							String overResult = "";
							FileReader fr = new FileReader(fileName);
							BufferedReader br = new BufferedReader(fr);
							while( (line = br.readLine() ) != null ) {
								overResult = overResult + line+"\n";
							}
							br.close();
							result.confirm(overResult);
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND WRITE FILE ")){
							FileWriter fw = new FileWriter(message.substring(52,message.length()));
							BufferedWriter bw = new BufferedWriter(fw);
							bw.write(defaultValue);
							bw.close();
							result.confirm();
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND APPEND FILE ")){
							FileWriter fw = new FileWriter(message.substring(53,message.length()), true);
							BufferedWriter bw = new BufferedWriter(fw);
							bw.append(defaultValue);
							bw.close();
							result.confirm();
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND BLOCK WINDOW ")){
							blockWindow = true;
							result.confirm();
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND UNBLOCK WINDOW ")){
							blockWindow = false;
							result.confirm();
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND PICK COLOR ")){
							if(blockWindow){
								result.cancel();
							}else{
								AlertDialog.Builder JsPromptDialog = new AlertDialog.Builder(WainActivity.this,R.style.MyDialogTheme);
								JsPromptDialog.setTitle("Color Picker "+url);
								final ColorPicker coll = new ColorPicker(WainActivity.this);
								if(defaultValue.length()==6||defaultValue.length()==7){
									coll.setColor(Color.parseColor(defaultValue));
								}
								final CheckBox JsPrompt3 = new CheckBox(WainActivity.this);
								TextView tvtvtv = new TextView(WainActivity.this);
								tvtvtv.setText("Block View again");
								LinearLayout lylyly = new LinearLayout(WainActivity.this);
								lylyly.addView(JsPrompt3);
								lylyly.addView(tvtvtv);
								LinearLayout lylylyly = new LinearLayout(WainActivity.this);
								lylylyly.setOrientation(1);
								lylylyly.addView(coll);
								lylylyly.addView(lylyly);
								JsPromptDialog.setView(lylylyly);
								JsPromptDialog.setIcon(R.drawable.ic_launcher);
								JsPromptDialog.setPositiveButton(android.R.string.yes,new DialogInterface.OnClickListener(){
										public void onClick(DialogInterface dialogInterface,int i){
											blockWindow = JsPrompt3.isChecked();
											
											
											result.confirm(String.valueOf(coll.getColor()));
										}
									})
									.setNegativeButton(android.R.string.cancel,new DialogInterface.OnClickListener(){
										public void onClick(DialogInterface dialogInterface,int i){
											blockWindow = JsPrompt3.isChecked();
											result.cancel();
										}
									})
									.setNeutralButton(R.string.exqu,new DialogInterface.OnClickListener(){
										public void onClick(DialogInterface dialogInterface,int i){
											finish();
										}
									})
									.setCancelable(true)
									.setOnCancelListener(new DialogInterface.OnCancelListener(){
										public void onCancel(DialogInterface p1){
											blockWindow = JsPrompt3.isChecked();
											result.cancel();
										}
									})
									.show();
							}
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND UNZIP FILE ")){
							unZip(defaultValue);
							result.confirm();
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND GET FILES IN FOLDER")){
							File[] fil = getFilesInFolder(defaultValue);
							String ssssstttttrrrr="[";
							for(int iiii=0;iiii<fil.length;iiii++){
								if(Build.VERSION.SDK_INT >= 9){
								    ssssstttttrrrr = ssssstttttrrrr + "{'path':'"+fil[iiii].getPath()+"','name':'"+fil[iiii].getName()+"','usableSpace':"+String.valueOf(fil[iiii].getUsableSpace())+",'totalSpace':";
								    ssssstttttrrrr = ssssstttttrrrr + String.valueOf(fil[iiii].getTotalSpace())+",'freeSpace':"+String.valueOf(fil[iiii].getFreeSpace())+",'isFile':"+String.valueOf(fil[iiii].isFile())+",'isDirectory':"+String.valueOf(fil[iiii].isDirectory())+",'isHidden':"+String.valueOf(fil[iiii].isHidden());
									ssssstttttrrrr = ssssstttttrrrr + ",'canRead':"+String.valueOf(fil[iiii].canRead())+",'canExecute':"+String.valueOf(fil[iiii].canExecute())+",'canWrite':"+String.valueOf(fil[iiii].canWrite())+"},";
									
								}else{
									ssssstttttrrrr = ssssstttttrrrr + "{'path':'"+fil[iiii].getPath()+"','name':'"+fil[iiii].getName()+"'";
								    ssssstttttrrrr = ssssstttttrrrr + ",'isFile':"+String.valueOf(fil[iiii].isFile())+",'isDirectory':"+String.valueOf(fil[iiii].isDirectory())+",'isHidden':"+String.valueOf(fil[iiii].isHidden())+"},";
									
								}
							    
							}
							
							ssssstttttrrrr = ssssstttttrrrr.substring(0,ssssstttttrrrr.length()-1)+"]";
							result.confirm(ssssstttttrrrr);
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND RENAME FILE ")){
							File ffffff = new File(message.substring(53,message.length()));
							boolean resultb = ffffff.renameTo(new File(defaultValue));
							result.confirm(String.valueOf(resultb));
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND DELETE FILE ")){
							File ffffff = new File(defaultValue);
							ffffff.delete();
							result.confirm();
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND COPY FILE ")){
							int buffersize = Integer.parseInt(defaultValue.substring(0,defaultValue.indexOf("&&")));
							String firstFile = message.substring(51,message.length());
							String lastFile = defaultValue.substring(defaultValue.indexOf("&&")+2,defaultValue.length());
							File infile = new File(firstFile);
							File outfile = new File(lastFile);
							InputStream inpstream = new FileInputStream(infile);
							OutputStream outstream = new FileOutputStream(outfile);
							byte[] buf = new byte[buffersize];
							int len;
							while((len=inpstream.read(buf))>0){
								outstream.write(buf,0,len);
							}
							inpstream.close();
							outstream.close();
							result.confirm();
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND COPY TEXT TO CLIPBOARD")){
							ClipboardManager cbm = (ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
							ClipData myclip = ClipData.newPlainText("text",defaultValue);
							cbm.setPrimaryClip(myclip);
							result.confirm();
							/*
							if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {  Window w = this.getWindow();w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);} getWindow().getDecorView().setSystemUiVisibility( View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN); if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) { getWindow().setStatusBarColor(Color.TRANSPARENT); }
		
							*/
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND PICK FILE ")){
							if(blockWindow){
								result.cancel();
							}else{
								AlertDialog.Builder JsPromptDialog = new AlertDialog.Builder(WainActivity.this,R.style.MyDialogTheme);
								JsPromptDialog.setTitle("Select File "+url);
								Button coll = new Button(WainActivity.this);
								coll.setOnClickListener(new View.OnClickListener (){
										@Override
										public void onClick(View v) {
											Intent i = new Intent(Intent.ACTION_GET_CONTENT);
											i.addCategory(Intent.CATEGORY_OPENABLE);
											i.setType("*/*");
											startActivityForResult(Intent.createChooser(i, "File Browser"), FILECHOOSER_RESULTCODE);
										}
									});
								final CheckBox JsPrompt3 = new CheckBox(WainActivity.this);
								TextView tvtvtv = new TextView(WainActivity.this);
								tvtvtv.setText("Block View again");
								LinearLayout lylyly = new LinearLayout(WainActivity.this);
								lylyly.addView(JsPrompt3);
								lylyly.addView(tvtvtv);
								LinearLayout lylylyly = new LinearLayout(WainActivity.this);
								lylylyly.setOrientation(1);
								lylylyly.addView(coll);
								lylylyly.addView(lylyly);
								JsPromptDialog.setView(lylylyly);
								JsPromptDialog.setIcon(R.drawable.ic_launcher);
								JsPromptDialog.setPositiveButton(android.R.string.yes,new DialogInterface.OnClickListener(){
										public void onClick(DialogInterface dialogInterface,int i){
											blockWindow = JsPrompt3.isChecked();


											result.confirm(pickedFile);
										}
									})
									.setNegativeButton(android.R.string.cancel,new DialogInterface.OnClickListener(){
										public void onClick(DialogInterface dialogInterface,int i){
											blockWindow = JsPrompt3.isChecked();
											result.cancel();
										}
									})
									.setNeutralButton(R.string.exqu,new DialogInterface.OnClickListener(){
										public void onClick(DialogInterface dialogInterface,int i){
											finish();
										}
									})
									.setCancelable(true)
									.setOnCancelListener(new DialogInterface.OnCancelListener(){
										public void onCancel(DialogInterface p1){
											blockWindow = JsPrompt3.isChecked();
											result.cancel();
										}
									})
									.show();
							}
							
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND SET TRANSPARENT MODE")){
							setTransparentMode();
							result.confirm();
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND SET ACTION BAR COLOR")){
							if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB){
								ActionBar bar = getActionBar();
								bar.setBackgroundDrawable(new ColorDrawable(Color.parseColor(defaultValue)));

							}
							result.confirm();
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND CREATE NEW FOLDER")){
							buildFolder(defaultValue);
							result.confirm();
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND GET STORAGE DIRECTORY")){
							result.confirm(String.valueOf(Environment.getExternalStorageDirectory()));
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND SET AUDIO RECORDER")){
							String channel = message.substring(message.indexOf("&&CH=")+5,message.indexOf("&&SR="));
							String simpleRate = message.substring(message.indexOf("&&SR=")+5,message.indexOf("&&SBR="));
							String cbitrate = message.substring(message.indexOf("&&SBR=")+6,message.indexOf("&&MS="));
							String maxsize = message.substring(message.indexOf("&&MS=")+5,message.length()-1);
							audioMediaRecorder=new MediaRecorder();
							audioMediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
							audioMediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.DEFAULT);
							audioMediaRecorder.setAudioEncoder(MediaRecorder.OutputFormat.AMR_NB);
							audioMediaRecorder.setOutputFile(defaultValue);
							if(channel.startsWith("DE")){
								
							}else{
								int channelint = Integer.parseInt(channel);
								audioMediaRecorder.setAudioChannels(channelint);
							}
							/**/
							if(simpleRate.startsWith("DE")){

							}else{
								int simpleRateInt = Integer.parseInt(simpleRate);
								audioMediaRecorder.setAudioSamplingRate(simpleRateInt);
							}
							/**/
							if(cbitrate.startsWith("DE")){

							}else{
								int cbitrateint = Integer.parseInt(cbitrate);
								audioMediaRecorder.setAudioEncodingBitRate(cbitrateint);
							}
							/**/
							if(maxsize.startsWith("DE")){

							}else{
								int maxsizeint = Integer.parseInt(maxsize);
								audioMediaRecorder.setMaxFileSize(maxsizeint);
							}
							
							audioMediaRecorder.prepare();
							audioMediaRecorder.start();
							result.confirm("NO ERR");
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND STOP AUDIO RECORD")){
							audioMediaRecorder.stop();
							result.confirm();
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND SET VIDEO RECORDER")){
							String channel = message.substring(message.indexOf("&&CH=")+5,message.indexOf("&&SR="));
							String simpleRate = message.substring(message.indexOf("&&SR=")+5,message.indexOf("&&SBR="));
							String cbitrate = message.substring(message.indexOf("&&SBR=")+6,message.indexOf("&&MS="));
							String maxsize = message.substring(message.indexOf("&&MS=")+5,message.indexOf("&&FR="));
							String fps = message.substring(message.indexOf("&&FR=")+5,message.indexOf("&&WX="));
							String wx = message.substring(message.indexOf("&&WX=")+5,message.indexOf("&&HY="));
							String hy = message.substring(message.indexOf("&&HY=")+5,message.indexOf("&&VBR="));
							String vbr = message.substring(message.indexOf("&&VBR=")+6,message.indexOf("&&VC="));
							String vcod = message.substring(message.indexOf("&&VC=")+6,message.indexOf("&&END"));
							
							// FrameRate >>>> Width >>>> Height >>>> BitRate
							videoMediaRecorder=new MediaRecorder();
							videoMediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
							videoMediaRecorder.setVideoSource(MediaRecorder.VideoSource.CAMERA);
							videoMediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
							videoMediaRecorder.setAudioEncoder(MediaRecorder.OutputFormat.AMR_NB);
							videoMediaRecorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
							
							
							videoMediaRecorder.setOutputFile(defaultValue);
							if(channel.startsWith("DE")){

							}else{
								int channelint = Integer.parseInt(channel);
								videoMediaRecorder.setAudioChannels(channelint);
							}
							/**/
							if(simpleRate.startsWith("DE")){

							}else{
								int simpleRateInt = Integer.parseInt(simpleRate);
								videoMediaRecorder.setAudioSamplingRate(simpleRateInt);
							}
							/**/
							if(cbitrate.startsWith("DE")){

							}else{
								int cbitrateint = Integer.parseInt(cbitrate);
								videoMediaRecorder.setAudioEncodingBitRate(cbitrateint);
							}
							/**/
							if(maxsize.startsWith("DE")){

							}else{
								int maxsizeint = Integer.parseInt(maxsize);
								videoMediaRecorder.setMaxFileSize(maxsizeint);
							}
							/**/
							if(fps.startsWith("DE")){

							}else{
								int fpsi = Integer.parseInt(fps);
								videoMediaRecorder.setVideoFrameRate(fpsi);
							}
							if(wx.startsWith("DE")){

							}else{
								int wxi = Integer.parseInt(wx);
								int hyi = Integer.parseInt(hy);
								videoMediaRecorder.setVideoSize(wxi,hyi);
							}
							if(vbr.startsWith("DE")){

							}else{
								int vbri = Integer.parseInt(vbr);
								videoMediaRecorder.setVideoEncodingBitRate(vbri);
							}
							if(vcod.startsWith("DE")){

							}else{
								if(vcod.equals("H264")){
									videoMediaRecorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
								}
								if(vcod.equals("H263")){
									videoMediaRecorder.setVideoEncoder(MediaRecorder.VideoEncoder.H263);
								}
								if(vcod.equals("H265")){
									videoMediaRecorder.setVideoEncoder(MediaRecorder.VideoEncoder.HEVC);
								}
								if(vcod.equals("VP8")){
									videoMediaRecorder.setVideoEncoder(MediaRecorder.VideoEncoder.VP8);
								}
								if(vcod.equals("MP4")){
									videoMediaRecorder.setVideoEncoder(MediaRecorder.VideoEncoder.MPEG_4_SP);
								}
							}
							
							videoMediaRecorder.prepare();
							videoMediaRecorder.start();
							result.confirm("NO ERR");
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND STOP VIDEO RECORD")){
							videoMediaRecorder.stop();
							result.confirm();
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND ENABLE BLUETOOTH")){
							BluetoothAdapter.getDefaultAdapter().enable();
							
							result.confirm();
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND DISABLE BLUETOOTH")){
							BluetoothAdapter.getDefaultAdapter().disable();
							result.confirm();
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND GET NETWORK OPERATOR NAME")){
							TelephonyManager telephonyManager = getTelephoneManager();
							result.confirm(telephonyManager.getNetworkOperatorName());
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND GET SIM OPERATOR NAME")){
							TelephonyManager telephonyManager = getTelephoneManager();
							result.confirm(telephonyManager.getSimOperatorName());
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND GET MOBILE DATA MODE")){
							TelephonyManager telephonyManager = getTelephoneManager();
							int netmode = telephonyManager.getNetworkType();
							if(netmode==TelephonyManager.NETWORK_TYPE_UNKNOWN){
								result.confirm(String.valueOf(netmode)+"(UNKNOWN)");
							}else if(netmode==TelephonyManager.NETWORK_TYPE_GPRS){
								result.confirm(String.valueOf(netmode)+"(GPRS - G - 2.5G)");
							}else if(netmode==TelephonyManager.NETWORK_TYPE_EDGE){
								result.confirm(String.valueOf(netmode)+"(EDGE - E - 2.75G)");
							}else if(netmode==TelephonyManager.NETWORK_TYPE_UMTS){
								result.confirm(String.valueOf(netmode)+"(UTMS)");
							}else{
								if(Build.VERSION.SDK_INT>=4){
									if(netmode==TelephonyManager.NETWORK_TYPE_EVDO_A){
										result.confirm(String.valueOf(netmode)+"(EVDO_A)");
									}else if(netmode==TelephonyManager.NETWORK_TYPE_EVDO_0){
										result.confirm(String.valueOf(netmode)+"(EVDO_0)");
									}else if(netmode==TelephonyManager.NETWORK_TYPE_EHRPD){
										result.confirm(String.valueOf(netmode)+"(EHRPD)");
									}else if(netmode==TelephonyManager.NETWORK_TYPE_CDMA){
										result.confirm(String.valueOf(netmode)+"(CMDA)");
									}else if(netmode==TelephonyManager.NETWORK_TYPE_1xRTT){
										result.confirm(String.valueOf(netmode)+"(1XRTT)");
									}else{
										if(Build.VERSION.SDK_INT>=5){
											if(netmode==TelephonyManager.NETWORK_TYPE_HSUPA){
												result.confirm(String.valueOf(netmode)+"(HSUPA)");
											}else if(netmode==TelephonyManager.NETWORK_TYPE_HSPA){
												result.confirm(String.valueOf(netmode)+"(HSPA - H - 3.5G)");
											}else if(netmode==TelephonyManager.NETWORK_TYPE_HSDPA){
												result.confirm(String.valueOf(netmode)+"(HSDPA)");
											}else{
												if(Build.VERSION.SDK_INT>=8){
													if(netmode==TelephonyManager.NETWORK_TYPE_IDEN){
														result.confirm(String.valueOf(netmode)+"(IDEN)");
													}else{
														if(Build.VERSION.SDK_INT>=9){
															if(netmode==TelephonyManager.NETWORK_TYPE_EVDO_B){
																result.confirm(String.valueOf(netmode)+"(EVDO_B)");
															}else{
																if(Build.VERSION.SDK_INT>=11){
																    if(netmode==TelephonyManager.NETWORK_TYPE_EHRPD){
																		result.confirm(String.valueOf(netmode)+"(EHRPD)");
																	}else if(netmode==TelephonyManager.NETWORK_TYPE_LTE){
																		result.confirm(String.valueOf(netmode)+"(LTE - 4G)");
																	}else{
																		if(Build.VERSION.SDK_INT>=13){
																			if(netmode==TelephonyManager.NETWORK_TYPE_HSPAP){
																				result.confirm(String.valueOf(netmode)+"(HSPAP - HSPA+ - H+ - 3.75G - 3.5G+)");
																			}else{
																				if(Build.VERSION.SDK_INT>=25){
																					if(netmode==TelephonyManager.NETWORK_TYPE_TD_SCDMA){
																						result.confirm(String.valueOf(netmode)+"(TD_SCDMA)");
																					}else if(netmode==TelephonyManager.NETWORK_TYPE_IWLAN){
																						result.confirm(String.valueOf(netmode)+"(IWLAN)");
																					}else if(netmode==TelephonyManager.NETWORK_TYPE_GSM){
																						result.confirm(String.valueOf(netmode)+"(GSM - 2G)");
																					}else{
																						result.confirm(String.valueOf(netmode));
																					}
																				}else{
																					result.confirm(String.valueOf(netmode));
																				}
																			}
																		}else{
																			result.confirm(String.valueOf(netmode));
																		}
																	}
																}else{
																	result.confirm(String.valueOf(netmode));
																}
															}
														}
													}
												}else{
													result.confirm(String.valueOf(netmode));
												}
												
											}
										}else{
											result.confirm(String.valueOf(netmode));
										}
									}
								}else{
									result.confirm(String.valueOf(netmode));
								}
							}
							result.confirm(String.valueOf(telephonyManager.getNetworkType()));
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND GET CPU CORES")){
							result.confirm(String.valueOf(getNumberOfCores()));
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND GET BATTERY CAPACITY")){
							Double batcap1 = getBatteryCapacity0(WainActivity.this);
							Double batcap2 = getBatteryCapacity1();
							if(batcap2>batcap1){
								result.confirm(String.valueOf(batcap2));
							}else{
								result.confirm(String.valueOf(batcap1));
							}
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND GET BATTERY CURRENT")){
							result.confirm(String.valueOf(getBatteryManager().getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_AVERAGE)));
							
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND GET BATTERY HEALTH")){
							IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
							Intent batteryStatus = registerReceiver(null, ifilter);
							int hhhhhhhh = batteryStatus.getIntExtra(BatteryManager.EXTRA_HEALTH, -1);
							switch(hhhhhhhh){
								case BatteryManager.BATTERY_HEALTH_DEAD:
									result.confirm("DEAD");
									break;
								case BatteryManager.BATTERY_HEALTH_GOOD:
									result.confirm("GOOD");
									break;
								case BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE:
									result.confirm("OVER VOLTAGE");
									break;
								case BatteryManager.BATTERY_HEALTH_OVERHEAT:
									result.confirm("OVERHEAT");
									break;
								case BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE:
									result.confirm("UNSPECIFIED FAILURE");
									break;
								case BatteryManager.BATTERY_HEALTH_UNKNOWN:
									result.confirm("UNKNOWN");
									break;
								default:
								    if(Build.VERSION.SDK_INT>=11){
								    if(hhhhhhhh==BatteryManager.BATTERY_HEALTH_COLD){
										result.confirm("COLD");
										
									}
									}else{
										result.confirm("UNKNOWN");
									}
							}
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND GET BATTERY TEMPERATURE")){
							IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
							Intent batteryStatus = registerReceiver(null, ifilter);
							result.confirm(String.valueOf(batteryStatus.getIntExtra(BatteryManager.EXTRA_TEMPERATURE,-1)));
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND GET WIFI ENABLED")){
							WifiManager wifi = (WifiManager) getSystemService(Context.WIFI_SERVICE);
							result.confirm(String.valueOf(wifi.isWifiEnabled()));
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND SET WINDIW TITLE COLOR")){
							getWindow().setTitleColor(Color.parseColor(defaultValue));
							result.confirm();
						}else if(message.startsWith("CONNENT EBL TO ANDROID AND OPEN JAVA AND GET BLUETOOTH ENABLED")){
							result.confirm(String.valueOf(BluetoothAdapter.getDefaultAdapter().isEnabled()));
						}else{
							if(blockWindow){
								result.cancel();
							}else{
								AlertDialog.Builder JsPromptDialog = new AlertDialog.Builder(WainActivity.this,R.style.MyDialogTheme);
								JsPromptDialog.setTitle("Prompt "+url);
								JsPromptDialog.setMessage(message);
								final EditText JsPromptInput = new EditText(WainActivity.this);
								JsPromptInput.setText(defaultValue);
								
								LinearLayout JsPrompt0 = new LinearLayout(WainActivity.this);
								LinearLayout JsPrompt1 = new LinearLayout(WainActivity.this);
								TextView JsPrompt2 = new TextView(WainActivity.this);
								JsPrompt2.setText("Block view again");
								final CheckBox JsPrompt3 = new CheckBox(WainActivity.this);
								JsPrompt1.addView(JsPrompt3);
								JsPrompt1.addView(JsPrompt2);
								JsPrompt0.setOrientation(1);
								JsPrompt0.addView(JsPromptInput);
								JsPrompt0.addView(JsPrompt1);
								JsPromptInput.selectAll();
								JsPromptInput.setBackgroundColor(Color.parseColor("#ff4080ff"));
								JsPromptInput.setTextColor(Color.parseColor("#ffffd000"));
								JsPromptDialog.setView(JsPrompt0);
								JsPromptDialog.setIcon(R.drawable.ic_launcher);
								JsPromptDialog.setPositiveButton(android.R.string.yes,new DialogInterface.OnClickListener(){
										public void onClick(DialogInterface dialogInterface,int i){
											blockWindow = JsPrompt3.isChecked();
											result.confirm(JsPromptInput.getText().toString());
										}
									})
									.setNegativeButton(android.R.string.cancel,new DialogInterface.OnClickListener(){
										public void onClick(DialogInterface dialogInterface,int i){
											blockWindow = JsPrompt3.isChecked();
											result.cancel();
										}
									})
									.setNeutralButton(R.string.exqu,new DialogInterface.OnClickListener(){
										public void onClick(DialogInterface dialogInterface,int i){
											finish();
										}
									})
									.setCancelable(true)
									.setOnCancelListener(new DialogInterface.OnCancelListener(){
										public void onCancel(DialogInterface p1){
											blockWindow = JsPrompt3.isChecked();
											result.cancel();
										}
									})
									.show();
							}
						}
					}catch(Exception errInf){
						result.confirm("ERROR : "+String.valueOf(errInf));
					}
					return true;
				}
				public boolean onJsConfirm(WebView view,String url,String message,final JsResult result){
					try{
						if(blockWindow){
							result.cancel();
						}else{
						AlertDialog.Builder JsPromptDialog = new AlertDialog.Builder(WainActivity.this,R.style.MyDialogTheme);
						JsPromptDialog.setTitle("Confirm "+url);
						JsPromptDialog.setMessage(message);
						LinearLayout JsViewAgain = new LinearLayout(WainActivity.this);
						final CheckBox JsViewAgain2 = new CheckBox(WainActivity.this);
						JsViewAgain.addView(JsViewAgain2);
						TextView JsViewAgain3 = new TextView(WainActivity.this);
						JsViewAgain.addView(JsViewAgain3);
						JsViewAgain3.setText("Block view again");
						JsPromptDialog.setView(JsViewAgain);
						JsPromptDialog.setIcon(R.drawable.ic_launcher);
						JsPromptDialog.setPositiveButton(android.R.string.yes,new DialogInterface.OnClickListener(){
								public void onClick(DialogInterface dialogInterface,int i){
									result.confirm();
									blockWindow = JsViewAgain2.isChecked();
								}
							})
							.setNegativeButton(android.R.string.cancel,new DialogInterface.OnClickListener(){
								public void onClick(DialogInterface dialogInterface,int i){
									result.cancel();
									blockWindow = JsViewAgain2.isChecked();
								}
							})
							.setNeutralButton(R.string.exqu,new DialogInterface.OnClickListener(){
								public void onClick(DialogInterface dialogInterface,int i){
									finish();
								}
							})
							.setCancelable(true)
							.setOnCancelListener(new DialogInterface.OnCancelListener(){
								public void onCancel(DialogInterface p1){
									blockWindow = JsViewAgain2.isChecked();
									result.cancel();
								}
							})
							.show();
						}
					}catch(Exception errInf){

						result.cancel();
					}
					return true;
				}
				public boolean onJsAlert(WebView view,String url,String message,final JsResult result){
					try{
						if(blockWindow){
							result.cancel();
						}else{
						LinearLayout JsViewAgain = new LinearLayout(WainActivity.this);
						final CheckBox JsViewAgain2 = new CheckBox(WainActivity.this);
						JsViewAgain.addView(JsViewAgain2);
						TextView JsViewAgain3 = new TextView(WainActivity.this);
						JsViewAgain.addView(JsViewAgain3);
						JsViewAgain3.setText("Block view again");
						AlertDialog.Builder JsPromptDialog = new AlertDialog.Builder(WainActivity.this,R.style.MyDialogTheme);
						JsPromptDialog.setTitle("Alert "+url);
						JsPromptDialog.setView(JsViewAgain);
						JsPromptDialog.setMessage(message);
						JsPromptDialog.setIcon(R.drawable.ic_launcher);
						JsPromptDialog.setPositiveButton(android.R.string.yes,new DialogInterface.OnClickListener(){
								public void onClick(DialogInterface dialogInterface,int i){
									blockWindow = JsViewAgain2.isChecked();
									result.confirm();
								}
							})
							.setNegativeButton(android.R.string.no,new DialogInterface.OnClickListener(){
									public void onClick(DialogInterface dialogInterface,int i){
										blockWindow = JsViewAgain2.isChecked();
										result.cancel();
									}
								})
							.setNeutralButton(R.string.exqu,new DialogInterface.OnClickListener(){
								public void onClick(DialogInterface dialogInterface,int i){
									finish();
								}
							})
							.setCancelable(true)
							.setOnCancelListener(new DialogInterface.OnCancelListener(){
								public void onCancel(DialogInterface p1){
									blockWindow = JsViewAgain2.isChecked();
									result.cancel();
								}
							})
							.show();
						}
					}catch(Exception errInf){
						String errinf2 = String.valueOf(errInf);

						result.cancel();
					}
					return true;
				}
				public void onProgressChanged(WebView view,int newProgress){
					Toast.makeText(WainActivity.this,"Loading "+String.valueOf(newProgress)+"%",0).show();
				}
				protected void openFileChooser(ValueCallback uploadMsg, String acceptType)
				{
					Intent i = new Intent(Intent.ACTION_GET_CONTENT);
					i.addCategory(Intent.CATEGORY_OPENABLE);
					i.setType("*/*");
					startActivityForResult(Intent.createChooser(i, "File Browser"), FILECHOOSER_RESULTCODE);
				}
				public boolean onShowFileChooser(WebView mWebView, ValueCallback<Uri[]> filePathCallback, WebChromeClient.FileChooserParams fileChooserParams)
				{
					if (uploadMessage != null) {
						uploadMessage.onReceiveValue(null);
						uploadMessage = null;
					}

					uploadMessage = filePathCallback;

					Intent intent = null;
					if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
						intent = fileChooserParams.createIntent();
					}
					try
					{
						startActivityForResult(intent, REQUEST_SELECT_FILE);
					} catch (ActivityNotFoundException e)
					{
						uploadMessage = null;
						return false;
					}
					return true;
				}
			});
		if(Build.VERSION.SDK_INT >= 3){
			webv1.getSettings().setUserAgentString("EBL");
			webv1.getSettings().setBuiltInZoomControls(true);
		}
		//webv1.addJavascriptInterface({},"Windows 11 + Android 13 with EBL");
		webv1.getSettings().setMinimumFontSize(0);
		webv1.getSettings().setMinimumLogicalFontSize(0);
		webv1.getSettings().setSaveFormData(true);
		webv1.setDownloadListener(new DownloadListener() {
				public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
					DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
					String cookies = CookieManager.getInstance().getCookie(url);
					request.addRequestHeader("cookie", cookies);
					request.addRequestHeader("User-Agent", userAgent);
					request.setDescription("Downloading file...");
					request.setTitle(URLUtil.guessFileName(url, contentDisposition, mimetype));
					request.allowScanningByMediaScanner(); request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
					java.io.File aatv = new java.io.File(Environment.getExternalStorageDirectory().getPath() + "/Webview/Download");
					request.setDestinationInExternalPublicDir("/Webview/Download", URLUtil.guessFileName(url, contentDisposition, mimetype));
					DownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
					manager.enqueue(request);
					BroadcastReceiver onComplete = new BroadcastReceiver() {
						public void onReceive(Context ctxt, Intent intent) {
							unregisterReceiver(this);
						}};
					registerReceiver(onComplete, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
				}
			});
		webv1.getSettings().setSavePassword(true);
		webv1.getSettings().setStandardFontFamily("serif");
		webv1.setWebViewClient(new WebViewClient());
		webv1.getSettings().setDefaultFontSize(16);
		if(Build.VERSION.SDK_INT >= 5){
			webv1.getSettings().setDatabaseEnabled(true);
			webv1.getSettings().setGeolocationEnabled(true);
		}
		if(Build.VERSION.SDK_INT >= 7){
			webv1.getSettings().setDomStorageEnabled(true);
			webv1.getSettings().setAppCacheEnabled(true);
			webv1.getSettings().setAppCacheMaxSize(2147483647); // Max Range size ( 2 GB )
		}
		if(Build.VERSION.SDK_INT >= 11){
			webv1.getSettings().setDisplayZoomControls(true);
			webv1.getSettings().setAllowContentAccess(true);
		}

		webv1.getSettings().setLoadsImagesAutomatically(true);
		webv1.getSettings().setUseWideViewPort(true);
		webv1.getSettings().setJavaScriptEnabled(true);
		webv1.getSettings().setSupportZoom(true);
		if(Build.VERSION.SDK_INT >= 3){
			webv1.getSettings().setUserAgentString("EBL");
			webv1.getSettings().setBuiltInZoomControls(true);
		}
		//webv1.addJavascriptInterface({},"Windows 11 + Android 13 with EBL");
		webv1.getSettings().setMinimumFontSize(0);
		webv1.getSettings().setMinimumLogicalFontSize(0);
		webv1.getSettings().setSaveFormData(true);
		webv1.setDownloadListener(new DownloadListener() {
				@Override
				public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
					DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
					request.setTitle(URLUtil.guessFileName(url, contentDisposition, mimetype));
					request.setDescription("Downloading file...");
					request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
					request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, contentDisposition, mimetype));
					DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
					dm.enqueue(request);
					Toast.makeText(getApplicationContext(), "Downloading...", Toast.LENGTH_SHORT).show();
					registerReceiver(onComplete, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
				}
				BroadcastReceiver onComplete = new BroadcastReceiver() {
					@Override
					public void onReceive(Context context, Intent intent) {
						Toast.makeText(getApplicationContext(), "Downloading Complete", Toast.LENGTH_SHORT).show();
					}
				};
			});
		webv1.getSettings().setSavePassword(true);
		webv1.getSettings().setStandardFontFamily("serif");
		webv1.setWebViewClient(new WebViewClient());
		webv1.getSettings().setDefaultFontSize(16);
		if(Build.VERSION.SDK_INT >= 5){
			webv1.getSettings().setDatabaseEnabled(true);
			webv1.getSettings().setGeolocationEnabled(true);
		}
		if(Build.VERSION.SDK_INT >= 7){
			webv1.getSettings().setDomStorageEnabled(true);
			webv1.getSettings().setAppCacheEnabled(true);
			webv1.getSettings().setAppCacheMaxSize(2147483647); // Max Range size ( 2 GB )
		}
		if(Build.VERSION.SDK_INT >= 11){
			webv1.getSettings().setDisplayZoomControls(true);
			webv1.getSettings().setAllowContentAccess(true);
		}
		webv1.getSettings().setMinimumFontSize(0);
		webv1.getSettings().setMinimumLogicalFontSize(0);
		webv1.getSettings().setLoadsImagesAutomatically(true);
		webv1.getSettings().setUseWideViewPort(true);
		webv1.getSettings().setJavaScriptEnabled(true);
		webv1.getSettings().setSupportZoom(true);
		webv1.getSettings().setSaveFormData(true);
		webv1.getSettings().setSavePassword(true);
		webv1.getSettings().setDomStorageEnabled(true);
		return webv1;
	}
	public static String getRealPathFromUri(Context context, Uri contentUri) {
		Cursor cursor = null;

		try {
			String[] proj = {
				MediaStore.Images.Media.DATA
			};
			cursor = context.getContentResolver().query(contentUri, proj, null, null, null);
			int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
			cursor.moveToFirst();
			return cursor.getString(column_index);
		} finally {
			if (cursor != null) {
				cursor.close();
			}
		}
	}
}



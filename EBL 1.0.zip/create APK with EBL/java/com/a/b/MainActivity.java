package com.a.b;

import android.os.Bundle;

public class MainActivity extends WainActivity 
{	
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
		
		super.onCreate(savedInstanceState);
		loadHTML("file:///android_asset/index.html")
		
    }


}


